import { AppProviders } from "./components/AppProviders";
import { AppLayout } from "./components/AppLayout";

export default function App() {
  return (
    <AppProviders>
      <AppLayout />
    </AppProviders>
  );
}
