import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import type { Burger } from "./burger-data";

export type CartItem = { burger: Burger; quantity: number };

type CartContextValue = {
  items: CartItem[];
  count: number;
  subtotal: number;
  add: (b: Burger) => void;
  remove: (id: string) => void;
  setQuantity: (id: string, qty: number) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const value = useMemo<CartContextValue>(() => {
    const count = items.reduce((s, i) => s + i.quantity, 0);
    const subtotal = items.reduce((s, i) => s + i.quantity * i.burger.price, 0);
    return {
      items,
      count,
      subtotal,
      add: (b) =>
        setItems((prev) => {
          const existing = prev.find((i) => i.burger.id === b.id);
          if (existing) {
            return prev.map((i) =>
              i.burger.id === b.id ? { ...i, quantity: i.quantity + 1 } : i,
            );
          }
          return [...prev, { burger: b, quantity: 1 }];
        }),
      remove: (id) => setItems((prev) => prev.filter((i) => i.burger.id !== id)),
      setQuantity: (id, qty) =>
        setItems((prev) =>
          qty <= 0
            ? prev.filter((i) => i.burger.id !== id)
            : prev.map((i) => (i.burger.id === id ? { ...i, quantity: qty } : i)),
        ),
      clear: () => setItems([]),
    };
  }, [items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
