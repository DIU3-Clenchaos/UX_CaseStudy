import { BurgerCard } from "./BurgerCard";
import { CartaFilters } from "./CartaFilters";
import { useFilters } from "./FiltersContext";

export function CartaSection() {
  const { filtered } = useFilters();

  return (
    <section id="carta" className="max-w-7xl mx-auto px-6 py-10">
      <div className="flex items-end justify-between mb-6">
        <h2 className="text-zinc-100">Nuestra carta</h2>
        <span className="text-zinc-500 text-sm">
          {filtered.length} {filtered.length === 1 ? "hamburguesa" : "hamburguesas"}
        </span>
      </div>

      <CartaFilters />

      <div className="flex flex-col gap-4">
        {filtered.length === 0 ? (
          <div className="text-center py-16 text-zinc-500 ring-1 ring-zinc-800 rounded-2xl">
            Ninguna hamburguesa coincide con tus filtros.
          </div>
        ) : (
          filtered.map((b) => <BurgerCard key={b.id} burger={b} />)
        )}
      </div>
    </section>
  );
}
