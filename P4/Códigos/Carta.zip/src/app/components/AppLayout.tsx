import { Toaster } from "./ui/sonner";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { Router } from "./Router";

export function AppLayout() {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <Toaster position="top-right" richColors />
      <Header />
      <Router />
      <Footer />
    </div>
  );
}
