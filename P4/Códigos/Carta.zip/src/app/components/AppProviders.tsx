import type { ReactNode } from "react";
import { CartProvider } from "./CartContext";
import { ViewProvider } from "./ViewContext";
import { FiltersProvider } from "./FiltersContext";

export function AppProviders({ children }: { children: ReactNode }) {
  return (
    <CartProvider>
      <ViewProvider>
        <FiltersProvider>{children}</FiltersProvider>
      </ViewProvider>
    </CartProvider>
  );
}
