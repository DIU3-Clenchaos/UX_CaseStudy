import { HomePage } from "./HomePage";
import { CartPage } from "./CartPage";
import { useView } from "./ViewContext";

export function Router() {
  const { view } = useView();
  return view === "cart" ? <CartPage /> : <HomePage />;
}
