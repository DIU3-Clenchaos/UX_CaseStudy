import { Search, Beef, ShoppingCart, User } from "lucide-react";
import { Input } from "./ui/input";
import { useCart } from "./CartContext";
import { useView } from "./ViewContext";
import { useFilters } from "./FiltersContext";

export const NAV_LINKS = [
  { id: "carta", label: "Carta" },
  { id: "sobre", label: "Sobre nosotros" },
  { id: "foodtruck", label: "Foodtruck" },
  { id: "faq", label: "FAQ" },
];

export function Header() {
  const { count } = useCart();
  const { goCart, goHome, navigateTo } = useView();
  const { query, setQuery } = useFilters();

  return (
    <header className="sticky top-0 z-40 bg-zinc-950/90 backdrop-blur border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-6 h-[76px] flex items-center gap-6">
        <div className="flex items-center gap-3">
          <a
            href="https://www.figma.com/make/qb3R4W4QMBYFErtPn7tJvK/Landing-Page?code-node-id=0-9&p=f&t=QR1GaE4ohgzf0xLO-0&fullscreen=1"
            target="_blank"
            rel="noopener noreferrer"
            className="size-11 rounded-xl bg-amber-400/10 ring-1 ring-amber-400/30 flex items-center justify-center hover:ring-amber-400 transition"
            aria-label="Ir a la landing page de Figma"
          >
            <Beef className="w-6 h-6 text-amber-400" />
          </a>
          <button onClick={goHome} className="hidden sm:block leading-tight text-left">
            <div className="text-amber-400">Remake</div>
            <div className="text-zinc-400 text-sm">Champions Burguer</div>
          </button>
        </div>

        <nav className="hidden md:flex items-center gap-6 ml-4">
          {NAV_LINKS.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              onClick={navigateTo(l.id)}
              className="text-zinc-400 hover:text-amber-400 transition-colors text-sm"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex-1" />

        <div className="hidden md:flex items-center gap-2 bg-white rounded-lg pl-2 pr-2 h-9 ring-1 ring-zinc-700 focus-within:ring-amber-400">
          <Search className="w-4 h-4 text-zinc-500" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar Hamburguesa..."
            className="border-0 shadow-none bg-transparent text-zinc-900 placeholder:text-zinc-500 h-7 w-56 focus-visible:ring-0"
          />
        </div>

        <button
          onClick={goCart}
          className="relative size-10 rounded-xl bg-zinc-900 ring-1 ring-zinc-800 flex items-center justify-center hover:ring-amber-400/40"
          aria-label="Abrir carrito"
        >
          <ShoppingCart className="w-5 h-5 text-amber-400" />
          {count > 0 && (
            <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-amber-400 text-zinc-950 text-xs flex items-center justify-center">
              {count}
            </span>
          )}
        </button>
        <button className="size-10 rounded-xl bg-zinc-900 ring-1 ring-zinc-800 flex items-center justify-center hover:ring-amber-400/40">
          <User className="w-5 h-5 text-zinc-300" />
        </button>
      </div>
    </header>
  );
}
