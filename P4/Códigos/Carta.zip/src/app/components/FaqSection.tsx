import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";

const FAQS = [
  {
    q: "¿Cuál es el tiempo de espera medio?",
    a: "El tiempo medio en horario punta es de 6 a 8 minutos. Fuera de horario punta servimos en 4-5 minutos. Puedes ver la cola actual en tiempo real en la cabecera de la página.",
  },
  {
    q: "¿Hacéis envíos a domicilio?",
    a: "Sí, trabajamos con Glovo, Uber Eats y Just Eat en un radio de 5 km alrededor de Plaza Mayor, 3. Pide desde tu app favorita o llámanos al 600 123 456.",
  },
  {
    q: "¿Tenéis opciones sin gluten o veganas?",
    a: "Por supuesto. Disponemos de pan artesano sin gluten certificado y una hamburguesa 100% vegetal de garbanzo y remolacha. Usa los filtros de la carta para verlas.",
  },
  {
    q: "¿De dónde proviene la carne?",
    a: "Trabajamos exclusivamente con ternera Black Angus madurada 30 días, suministrada por ganaderías locales de la sierra de Granada con bienestar animal certificado.",
  },
  {
    q: "¿Puedo reservar para grupos?",
    a: "Para grupos de más de 8 personas ofrecemos servicio privado de foodtruck. Escríbenos a eventos@championsburgerremake.es con fecha y número de comensales.",
  },
  {
    q: "¿Aceptáis pago con tarjeta?",
    a: "Aceptamos tarjeta (Visa, MasterCard, Amex), Apple Pay, Google Pay, Bizum y efectivo. También puedes pagar por adelantado desde la web al hacer tu pedido.",
  },
];

export function FaqSection() {
  return (
    <section id="faq" className="max-w-3xl mx-auto px-6 py-12">
      <h2 className="text-zinc-100 mb-6">Preguntas frecuentes</h2>
      <Accordion type="single" collapsible className="space-y-2">
        {FAQS.map((f, i) => (
          <AccordionItem
            key={i}
            value={`item-${i}`}
            className="bg-zinc-900/50 ring-1 ring-zinc-800 rounded-xl px-4 border-none"
          >
            <AccordionTrigger className="text-zinc-200 hover:text-amber-400 hover:no-underline">
              {f.q}
            </AccordionTrigger>
            <AccordionContent className="text-zinc-400">{f.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}
