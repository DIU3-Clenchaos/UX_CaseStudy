import { useState } from "react";
import { ArrowLeft, Minus, Plus, Trash2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useCart } from "./CartContext";
import { useView } from "./ViewContext";

const TAX_RATE = 0.1;
const DELIVERY_FEE = 1.5;

export function CartPage() {
  const { items, subtotal, setQuantity, remove, clear } = useCart();
  const { goHome: onBack } = useView();
  const [confirmed, setConfirmed] = useState<null | { id: string; total: number }>(null);

  const tax = subtotal * TAX_RATE;
  const delivery = items.length > 0 ? DELIVERY_FEE : 0;
  const total = subtotal + tax + delivery;

  const handleCheckout = () => {
    const orderId = `RB-${Date.now().toString().slice(-6)}`;
    setConfirmed({ id: orderId, total });
    toast.success("Pedido finalizado", {
      description: `Pedido ${orderId} confirmado. Tiempo estimado 6-8 min.`,
    });
    clear();
  };

  if (confirmed) {
    return (
      <main className="max-w-2xl mx-auto px-6 py-16 text-center">
        <div className="rounded-2xl ring-1 ring-amber-400/40 bg-zinc-900/60 p-10">
          <CheckCircle2 className="w-16 h-16 text-amber-400 mx-auto mb-4" />
          <h1 className="text-zinc-100 mb-2">¡Pedido confirmado!</h1>
          <p className="text-zinc-400 mb-1">Nº de pedido: <span className="text-amber-400">{confirmed.id}</span></p>
          <p className="text-zinc-400 mb-6">Total cobrado: <span className="text-amber-400">{confirmed.total.toFixed(2)} €</span></p>
          <p className="text-zinc-500 text-sm mb-8">
            Recibirás un email con la factura. Tu pedido estará listo en aproximadamente 6-8 minutos en el foodtruck de Plaza Mayor, 3.
          </p>
          <Button
            onClick={onBack}
            className="bg-amber-400 text-zinc-950 hover:bg-amber-300 rounded-full"
          >
            Volver a la carta
          </Button>
        </div>
      </main>
    );
  }

  return (
    <main className="max-w-5xl mx-auto px-6 py-10">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-zinc-400 hover:text-amber-400 mb-6"
      >
        <ArrowLeft className="w-4 h-4" /> Seguir comprando
      </button>

      <h1 className="text-zinc-100 mb-6">Tu carrito</h1>

      {items.length === 0 ? (
        <div className="text-center py-20 ring-1 ring-zinc-800 rounded-2xl bg-zinc-900/40">
          <p className="text-zinc-400 mb-4">Tu carrito está vacío.</p>
          <Button
            onClick={onBack}
            className="bg-amber-400 text-zinc-950 hover:bg-amber-300 rounded-full"
          >
            Explorar la carta
          </Button>
        </div>
      ) : (
        <div className="grid lg:grid-cols-[1fr_360px] gap-6">
          <div className="flex flex-col gap-3">
            {items.map(({ burger, quantity }) => (
              <div
                key={burger.id}
                className="flex items-center gap-4 bg-zinc-900/50 ring-1 ring-zinc-800 rounded-xl p-3"
              >
                <div className="relative size-20 rounded-lg overflow-hidden shrink-0">
                  <ImageWithFallback
                    src={burger.image}
                    alt={burger.name}
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-zinc-100">{burger.name}</div>
                  <div className="text-zinc-500 text-sm">{burger.price.toFixed(2)} € / ud.</div>
                </div>

                <div className="flex items-center gap-2 bg-zinc-950 ring-1 ring-zinc-800 rounded-full p-1">
                  <button
                    onClick={() => setQuantity(burger.id, quantity - 1)}
                    className="size-7 rounded-full hover:bg-zinc-800 flex items-center justify-center"
                    aria-label="Disminuir"
                  >
                    <Minus className="w-3 h-3 text-zinc-300" />
                  </button>
                  <span className="w-6 text-center text-zinc-100 text-sm">{quantity}</span>
                  <button
                    onClick={() => setQuantity(burger.id, quantity + 1)}
                    className="size-7 rounded-full hover:bg-zinc-800 flex items-center justify-center"
                    aria-label="Aumentar"
                  >
                    <Plus className="w-3 h-3 text-zinc-300" />
                  </button>
                </div>

                <div className="w-20 text-right text-amber-400">
                  {(burger.price * quantity).toFixed(2)} €
                </div>

                <button
                  onClick={() => remove(burger.id)}
                  className="size-9 rounded-lg hover:bg-red-500/10 flex items-center justify-center text-zinc-500 hover:text-red-400"
                  aria-label="Eliminar"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          <aside className="bg-zinc-900/50 ring-1 ring-zinc-800 rounded-2xl p-5 h-fit lg:sticky lg:top-24">
            <h3 className="text-zinc-100 mb-4">Factura</h3>
            <dl className="space-y-2 text-sm">
              {items.map(({ burger, quantity }) => (
                <div key={burger.id} className="flex justify-between text-zinc-400">
                  <dt>
                    {burger.name} × {quantity}
                  </dt>
                  <dd>{(burger.price * quantity).toFixed(2)} €</dd>
                </div>
              ))}
              <div className="border-t border-zinc-800 my-3" />
              <div className="flex justify-between text-zinc-400">
                <dt>Subtotal</dt>
                <dd>{subtotal.toFixed(2)} €</dd>
              </div>
              <div className="flex justify-between text-zinc-400">
                <dt>IVA (10%)</dt>
                <dd>{tax.toFixed(2)} €</dd>
              </div>
              <div className="flex justify-between text-zinc-400">
                <dt>Servicio</dt>
                <dd>{delivery.toFixed(2)} €</dd>
              </div>
              <div className="border-t border-zinc-800 my-3" />
              <div className="flex justify-between text-zinc-100">
                <dt>Total</dt>
                <dd className="text-amber-400">{total.toFixed(2)} €</dd>
              </div>
            </dl>

            <Button
              onClick={handleCheckout}
              className="w-full mt-6 bg-amber-400 text-zinc-950 hover:bg-amber-300 rounded-full"
            >
              Finalizar pedido
            </Button>
            <button
              onClick={clear}
              className="w-full mt-3 text-zinc-500 hover:text-red-400 text-sm"
            >
              Vaciar carrito
            </button>
          </aside>
        </div>
      )}
    </main>
  );
}
