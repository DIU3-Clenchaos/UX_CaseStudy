import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

export type View = "home" | "cart";

type ViewContextValue = {
  view: View;
  goHome: () => void;
  goCart: () => void;
  navigateTo: (id: string) => (e: React.MouseEvent) => void;
};

const ViewContext = createContext<ViewContextValue | null>(null);

export function ViewProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<View>("home");

  const value = useMemo<ViewContextValue>(
    () => ({
      view,
      goHome: () => {
        setView("home");
        window.scrollTo({ top: 0, behavior: "smooth" });
      },
      goCart: () => setView("cart"),
      navigateTo: (id) => (e) => {
        e.preventDefault();
        const scroll = () => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
        if (view !== "home") {
          setView("home");
          setTimeout(scroll, 50);
        } else {
          scroll();
        }
      },
    }),
    [view],
  );

  return <ViewContext.Provider value={value}>{children}</ViewContext.Provider>;
}

export function useView() {
  const ctx = useContext(ViewContext);
  if (!ctx) throw new Error("useView must be used within ViewProvider");
  return ctx;
}
