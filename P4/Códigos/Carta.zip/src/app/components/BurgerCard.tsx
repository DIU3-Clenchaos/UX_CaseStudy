import { Star, Plus, Wheat, Milk, Egg, Bean, Leaf } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useCart } from "./CartContext";
import type { Burger } from "./burger-data";

const allergenIcon: Record<string, React.ComponentType<{ className?: string }>> = {
  Gluten: Wheat,
  Lactosa: Milk,
  Huevo: Egg,
  Soja: Bean,
  Sésamo: Leaf,
};

export function BurgerCard({ burger }: { burger: Burger }) {
  const { add } = useCart();

  const handleOrder = () => {
    add(burger);
    toast.success(`¡${burger.name} añadida al carrito!`, {
      description: `${burger.price.toFixed(2)} € · Revisa tu pedido en el carrito.`,
      duration: 3000,
    });
  };

  return (
    <div className="flex flex-col md:flex-row gap-0 bg-gradient-to-b from-zinc-900 to-zinc-950 rounded-2xl overflow-hidden ring-1 ring-zinc-800 hover:ring-amber-500/40 transition-all">
      <div className="relative md:w-[340px] h-[220px] md:h-auto shrink-0">
        <ImageWithFallback
          src={burger.image}
          alt={burger.name}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/20 to-transparent" />
        {burger.bestseller && (
          <Badge className="absolute top-3 left-3 bg-amber-400 text-zinc-950 hover:bg-amber-400">
            Bestseller
          </Badge>
        )}
        <div className="absolute top-3 right-3 flex items-center gap-1 bg-zinc-950/70 px-2 py-1 rounded-full">
          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
          <span className="text-amber-300 text-xs">{burger.rating}</span>
        </div>
      </div>

      <div className="flex-1 p-5 flex flex-col gap-3">
        <h3 className="text-zinc-100">{burger.name}</h3>
        <p className="text-zinc-400 text-sm">{burger.description}</p>

        <div className="flex flex-wrap gap-2">
          {burger.allergens.map((a) => {
            const Icon = allergenIcon[a] ?? Wheat;
            return (
              <span
                key={a}
                className="inline-flex items-center gap-1 bg-zinc-800/80 text-zinc-300 text-xs px-2 py-1 rounded-full"
              >
                <Icon className="w-3 h-3" />
                {a}
              </span>
            );
          })}
        </div>

        <div className="flex items-center justify-between mt-auto pt-3">
          <span className="text-amber-400">{burger.price.toFixed(2)} €</span>
          <Button
            onClick={handleOrder}
            className="bg-amber-400 text-zinc-950 hover:bg-amber-300 rounded-full"
          >
            <Plus className="w-4 h-4" /> PÍDELA
          </Button>
        </div>
      </div>
    </div>
  );
}
