import { Instagram, Facebook, Music2 } from "lucide-react";

const LEGAL_LINKS = [
  "Aviso legal",
  "Política de privacidad",
  "Política de cookies",
  "Términos y condiciones",
  "Información nutricional",
  "Reclamaciones",
];

const SOCIALS = [
  { href: "https://instagram.com", icon: <Instagram className="w-4 h-4" />, label: "Instagram", sub: "@championsburgerremake" },
  { href: "https://facebook.com", icon: <Facebook className="w-4 h-4" />, label: "Facebook", sub: "/ChampionsBurgerRemake" },
  { href: "https://tiktok.com", icon: <Music2 className="w-4 h-4" />, label: "TikTok", sub: "@championsburgerremake" },
];

function SocialLink({ href, icon, label, sub }: { href: string; icon: React.ReactNode; label: string; sub: string }) {
  return (
    <li>
      <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 group">
        <span className="size-8 rounded-lg bg-zinc-900 ring-1 ring-zinc-800 flex items-center justify-center text-amber-400 group-hover:ring-amber-400/40">
          {icon}
        </span>
        <span className="leading-tight">
          <span className="block text-zinc-200 group-hover:text-amber-400 transition-colors">{label}</span>
          <span className="block text-zinc-500 text-xs">{sub}</span>
        </span>
      </a>
    </li>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-zinc-800 bg-black">
      <div className="max-w-7xl mx-auto px-6 py-12 grid md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-amber-400 mb-4">REDES SOCIALES</h3>
          <ul className="space-y-3">
            {SOCIALS.map((s) => (
              <SocialLink key={s.label} {...s} />
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-amber-400 mb-4">AVISOS LEGALES</h3>
          <ul className="space-y-2 text-zinc-400 text-sm">
            {LEGAL_LINKS.map((t) => (
              <li key={t}>
                <a href="#" className="hover:text-amber-400 transition-colors">{t}</a>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-amber-400 mb-4">CONTACTO</h3>
          <p className="text-zinc-400 text-sm">Plaza Mayor, 3 · Granada</p>
          <p className="text-zinc-400 text-sm">hola@championsburgerremake.es</p>
          <p className="text-zinc-400 text-sm">600 123 456</p>
        </div>
      </div>
      <div className="border-t border-zinc-800 px-6 py-6 max-w-7xl mx-auto flex flex-col sm:flex-row justify-between gap-2 text-zinc-500 text-xs">
        <span>© 2026 Remake Champions Burger — Todos los derechos reservados.</span>
        <span>Hecho con fuego en Granada</span>
      </div>
    </footer>
  );
}
