import { createContext, useContext, type ReactNode } from "react";
import { useBurgerFilters, type BurgerFilters } from "./useBurgerFilters";

const FiltersContext = createContext<BurgerFilters | null>(null);

export function FiltersProvider({ children }: { children: ReactNode }) {
  const filters = useBurgerFilters();
  return <FiltersContext.Provider value={filters}>{children}</FiltersContext.Provider>;
}

export function useFilters() {
  const ctx = useContext(FiltersContext);
  if (!ctx) throw new Error("useFilters must be used within FiltersProvider");
  return ctx;
}
