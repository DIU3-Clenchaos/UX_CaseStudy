import { useMemo, useState } from "react";
import { BURGERS, type Burger } from "./burger-data";

export type BurgerFilters = {
  query: string;
  setQuery: (q: string) => void;
  tags: string[];
  setTags: (t: string[]) => void;
  excludeAllergens: string[];
  setExcludeAllergens: (a: string[]) => void;
  filtered: Burger[];
  clear: () => void;
};

export function useBurgerFilters(): BurgerFilters {
  const [query, setQuery] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [excludeAllergens, setExcludeAllergens] = useState<string[]>([]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return BURGERS.filter((b) => {
      if (q && !b.name.toLowerCase().includes(q) && !b.description.toLowerCase().includes(q))
        return false;
      if (tags.length && !tags.some((t) => b.tags.includes(t as any))) return false;
      if (excludeAllergens.some((a) => b.allergens.includes(a as any))) return false;
      return true;
    });
  }, [query, tags, excludeAllergens]);

  const clear = () => {
    setQuery("");
    setTags([]);
    setExcludeAllergens([]);
  };

  return { query, setQuery, tags, setTags, excludeAllergens, setExcludeAllergens, filtered, clear };
}
