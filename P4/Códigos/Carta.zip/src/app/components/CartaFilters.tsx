import { Search } from "lucide-react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { ToggleGroup, ToggleGroupItem } from "./ui/toggle-group";
import { useFilters } from "./FiltersContext";

export const FILTERS = [
  { value: "clasica", label: "Clásica" },
  { value: "picante", label: "Picante" },
  { value: "vegana", label: "Vegana" },
  { value: "sin-gluten", label: "Sin gluten" },
];

export const ALLERGEN_FILTERS = ["Gluten", "Lactosa", "Huevo"] as const;

export function CartaFilters() {
  const { query, setQuery, tags, setTags, excludeAllergens, setExcludeAllergens, clear } = useFilters();
  const hasFilters = tags.length > 0 || excludeAllergens.length > 0 || query.length > 0;

  return (
    <div className="flex flex-col lg:flex-row gap-4 mb-6 p-4 rounded-2xl bg-zinc-900/50 ring-1 ring-zinc-800">
      <div className="flex items-center gap-2 bg-white rounded-lg px-3 h-10 lg:w-80 ring-1 ring-zinc-700 focus-within:ring-amber-400 md:hidden">
        <Search className="w-4 h-4 text-zinc-500" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar Hamburguesa..."
          className="border-0 shadow-none bg-transparent text-zinc-900 placeholder:text-zinc-500 h-8 focus-visible:ring-0"
        />
      </div>

      <div className="flex-1 flex flex-wrap items-center gap-3">
        <span className="text-zinc-400 text-sm">Tipo:</span>
        <ToggleGroup type="multiple" value={tags} onValueChange={setTags} className="flex-wrap">
          {FILTERS.map((f) => (
            <ToggleGroupItem
              key={f.value}
              value={f.value}
              className="rounded-full border border-zinc-700 data-[state=on]:bg-amber-400 data-[state=on]:text-zinc-950 data-[state=on]:border-amber-400 text-zinc-300"
            >
              {f.label}
            </ToggleGroupItem>
          ))}
        </ToggleGroup>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <span className="text-zinc-400 text-sm">Excluir:</span>
        <ToggleGroup type="multiple" value={excludeAllergens} onValueChange={setExcludeAllergens} className="flex-wrap">
          {ALLERGEN_FILTERS.map((a) => (
            <ToggleGroupItem
              key={a}
              value={a}
              className="rounded-full border border-zinc-700 data-[state=on]:bg-red-500/20 data-[state=on]:text-red-300 data-[state=on]:border-red-500/40 text-zinc-300"
            >
              {a}
            </ToggleGroupItem>
          ))}
        </ToggleGroup>
        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={clear} className="text-zinc-400 hover:text-amber-400">
            Limpiar
          </Button>
        )}
      </div>
    </div>
  );
}
