import { HeroSection } from "./HeroSection";
import { CartaSection } from "./CartaSection";
import { SobreSection } from "./SobreSection";
import { FaqSection } from "./FaqSection";

export function HomePage() {
  return (
    <>
      <HeroSection />
      <CartaSection />
      <SobreSection />
      <FaqSection />
    </>
  );
}
