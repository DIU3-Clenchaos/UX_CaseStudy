export function SobreSection() {
  return (
    <section id="sobre" className="border-t border-zinc-800 bg-zinc-900/30">
      <div className="max-w-7xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-zinc-100 mb-3">Sobre nosotros</h2>
          <p className="text-zinc-400">
            Somos un equipo apasionado por la brasa y los productos locales. Empezamos en 2021 con un foodtruck en la Plaza Mayor y hoy seguimos sirviendo hamburguesas con el mismo cariño del primer día.
          </p>
        </div>
        <div id="foodtruck" className="rounded-2xl ring-1 ring-zinc-800 p-6 bg-zinc-900/50">
          <h3 className="text-amber-400 mb-2">Foodtruck</h3>
          <p className="text-zinc-300">Plaza Mayor, 3 · Granada</p>
          <p className="text-zinc-500 text-sm mt-1">Mié - Dom · 13:00 - 23:30</p>
        </div>
      </div>
    </section>
  );
}
