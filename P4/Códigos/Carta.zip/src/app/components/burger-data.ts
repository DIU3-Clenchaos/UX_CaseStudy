export type Burger = {
  id: string;
  name: string;
  description: string;
  price: number;
  rating: number;
  bestseller?: boolean;
  image: string;
  allergens: ("Gluten" | "Lactosa" | "Huevo" | "Soja" | "Sésamo")[];
  tags: ("vegana" | "sin-gluten" | "picante" | "clasica")[];
};

export const BURGERS: Burger[] = [
  {
    id: "clasica",
    name: "La Clásica Brasa",
    description:
      "Ternera madurada 200g, cheddar curado, bacon ahumado, lechuga, tomate y salsa de la casa.",
    price: 11.5,
    rating: 4.8,
    bestseller: true,
    image:
      "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80",
    allergens: ["Gluten", "Lactosa", "Huevo"],
    tags: ["clasica"],
  },
  {
    id: "picantona",
    name: "La Picantona",
    description:
      "Smash de ternera, jalapeños encurtidos, cheddar fundido, cebolla crispy y salsa chipotle ahumada.",
    price: 12.9,
    rating: 4.7,
    image:
      "https://images.unsplash.com/photo-1550317138-10000687a72b?w=800&q=80",
    allergens: ["Gluten", "Lactosa"],
    tags: ["picante"],
  },
  {
    id: "vegana",
    name: "La Verde Brasa",
    description:
      "Hamburguesa 100% vegetal de garbanzo y remolacha, aguacate, rúcula y mayonesa vegana.",
    price: 11.9,
    rating: 4.6,
    image:
      "https://images.unsplash.com/photo-1525059696034-4967a729002e?w=800&q=80",
    allergens: ["Gluten", "Soja"],
    tags: ["vegana"],
  },
  {
    id: "sin-gluten",
    name: "La Libre",
    description:
      "Ternera madurada, pan sin gluten artesano, tomate raf, cebolla caramelizada y queso curado.",
    price: 13.5,
    rating: 4.5,
    image:
      "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=800&q=80",
    allergens: ["Lactosa", "Huevo"],
    tags: ["sin-gluten"],
  },
];
