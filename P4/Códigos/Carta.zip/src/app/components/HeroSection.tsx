import { Clock, MapPin, Beef } from "lucide-react";
import { Badge } from "./ui/badge";

function InfoChip({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 bg-black/60 ring-1 ring-zinc-800 rounded-2xl px-4 py-3">
      {icon}
      <div className="leading-tight">
        <div className="text-zinc-500 text-xs">{label}</div>
        <div className="text-zinc-200 text-sm">{value}</div>
      </div>
    </div>
  );
}

export function HeroSection() {
  return (
    <section id="top" className="border-b border-zinc-800 bg-gradient-to-b from-zinc-900 via-zinc-950 to-black">
      <div className="max-w-7xl mx-auto px-6 py-10 flex flex-col lg:flex-row gap-8 lg:items-end justify-between">
        <div className="max-w-xl">
          <Badge className="bg-black/30 text-amber-400 hover:bg-black/30 mb-3 tracking-widest">
            CARTA · TEMPORADA 2026
          </Badge>
          <h1 className="text-zinc-100">
            Hamburguesas hechas a la <span className="text-amber-400">brasa</span>, sabor de barrio.
          </h1>
          <p className="text-zinc-400 mt-3">
            Carne madurada, pan artesano del horno de la esquina y salsas caseras. Filtra la carta por alérgenos y descubre tu favorita.
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <InfoChip icon={<Clock className="w-5 h-5 text-amber-400" />} label="Cola actual" value="4 - 5 min" />
          <InfoChip icon={<MapPin className="w-5 h-5 text-amber-400" />} label="Foodtruck" value="Plaza Mayor, 3" />
          <InfoChip icon={<Beef className="w-5 h-5 text-amber-400" />} label="Calidad" value="100% Black Angus" />
        </div>
      </div>
    </section>
  );
}
