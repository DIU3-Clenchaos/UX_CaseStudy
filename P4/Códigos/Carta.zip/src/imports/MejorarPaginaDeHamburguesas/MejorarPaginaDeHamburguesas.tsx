import svgPaths from "./svg-0y7xteefj7";
import imgLogo from "./888653ba5fdb58cd59db834a97c5d661a63e415d.png";
import imgIconoCarrito from "./1df74ef80319357164713832750b9a766a816b46.png";
import imgIconoUsuario from "./077754a9eee4bde057697980832f386eb4e819fb.png";
import imgIconoFiltros from "./9b8fc4605dda6a620b613892a152c6e5a27276fd.png";
import imgContainer from "./9c6f794bf7a14a5985125eccc7bf8bf768d2a9f3.png";
import imgImageUbicacion from "./012d76821bab7234c50413159d1d0b64d1826cea.png";
import imgContainer1 from "./967609dd24c3957c61397826b1692acdf1ef50b7.png";

function Container1() {
  return (
    <div className="drop-shadow-[0px_10px_7.5px_rgba(254,154,0,0.2),0px_4px_3px_rgba(254,154,0,0.2)] relative rounded-[14px] shrink-0 size-[44px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[10px] relative size-full">
        <div className="h-[64px] relative shrink-0 w-[59px]" data-name="Logo">
          <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgLogo} />
          </div>
        </div>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[24px] min-w-px not-italic relative text-[#f5b301] text-[20px]">Remake</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#b4b6b7] text-[20px] top-[-3px] whitespace-nowrap">Champions Burguer</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="flex-[1_0_0] h-[36px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container3 />
        <Container4 />
      </div>
    </div>
  );
}

function Link() {
  return (
    <div className="absolute content-stretch flex gap-[22px] h-[44px] items-center left-[-85px] top-[16px] w-[264px]" data-name="Link">
      <Container1 />
      <Container2 />
    </div>
  );
}

function Link1() {
  return (
    <div className="h-[20px] relative shrink-0 w-[33.781px]" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#f5b301] text-[16px] top-0 whitespace-nowrap">Carta</p>
      </div>
    </div>
  );
}

function Link2() {
  return (
    <div className="flex-[1_0_0] h-[20px] min-w-px relative" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[-5.13px] not-italic text-[#b4b6b7] text-[16px] top-0 whitespace-nowrap">Sobre nosotros</p>
      </div>
    </div>
  );
}

function Link3() {
  return (
    <div className="h-[20px] relative shrink-0 w-[64.313px]" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[8.42px] not-italic text-[#b4b6b7] text-[16px] top-0 whitespace-nowrap">Foodtruck</p>
      </div>
    </div>
  );
}

function Link4() {
  return <div className="h-[20px] relative shrink-0 w-[26.688px]" data-name="Link" />;
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex gap-[24px] h-[20px] items-center left-[227.34px] top-[28px] w-[292.234px]" data-name="Navigation">
      <Link1 />
      <Link2 />
      <Link3 />
      <Link4 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#131718] content-stretch drop-shadow-[0px_0px_0px_#27272a] flex items-center justify-center left-[381.02px] px-[10px] rounded-[14px] size-[40px] top-0" data-name="Button">
      <div className="h-[40px] relative shrink-0 w-[30px]" data-name="Icono Carrito">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgIconoCarrito} />
        </div>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-[300px]">
      <div className="bg-white h-[30px] relative rounded-[8px] shrink-0 w-[33px]" data-name="Icono Filtros">
        <div className="absolute inset-[16.42%_25.4%_14.93%_11.11%] rounded-[8px]" data-name="Icono Filtros">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[8px] size-full" src={imgIconoFiltros} />
        </div>
        <div className="absolute bg-[#0b0e0f] inset-[0_-4.76%_0_82.54%]" />
      </div>
      <div className="bg-white h-[30px] overflow-clip relative rounded-[8px] shrink-0 w-[267px]" data-name="Barra Busqueda">
        <div className="absolute h-[34px] left-[-2px] top-[-3px] w-[17px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 34">
            <path d="M0 0H17V34H0V0Z" fill="var(--fill-0, #0B0E0F)" id="Rectangle 37" />
          </svg>
        </div>
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[25px] not-italic text-[#1b1f21] text-[16px] top-[3px] whitespace-nowrap">Buscar Hamburguesa...</p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute h-[40px] left-[908px] top-[18px] w-[469.016px]" data-name="Container">
      <Button />
      <div className="absolute h-[35px] left-[432.02px] top-px w-[33px]" data-name="Icono Usuario">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgIconoUsuario} />
      </div>
      <div className="absolute content-stretch flex items-center left-[34.02px] p-[8px] top-[-4px]" data-name="BusquedaFiltros">
        <Frame />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[76px] relative shrink-0 w-[1408px]" data-name="Container">
      <Link />
      <Navigation />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[511px] not-italic text-[#b4b6b7] text-[16px] top-[28px] whitespace-nowrap">FAQ</p>
      <Container5 />
    </div>
  );
}

function Header() {
  return (
    <div className="absolute bg-[rgba(9,9,11,0.9)] content-stretch flex flex-col h-[77px] items-start left-0 pb-px px-[128px] top-0 w-[1536px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#27272a] border-b border-solid inset-0 pointer-events-none" />
      <Container />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.2)] content-stretch flex h-[22px] items-start left-0 px-[12px] py-[4px] rounded-[33554400px] shadow-[0px_0px_0px_0px_rgba(254,154,0,0.3)] top-[2px] w-[197.5px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#f5b301] text-[12px] tracking-[1.2px] whitespace-nowrap">CARTA · TEMPORADA 2026</p>
    </div>
  );
}

function Heading() {
  return (
    <div className="absolute h-[36px] left-0 top-[40px] w-[576px]" data-name="Heading 1">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[0] left-0 not-italic text-[#f2e4e0] text-[0px] top-[-1px] whitespace-nowrap">
        <span className="leading-[32px] text-[25px]">{`Hamburguesas hechas a la `}</span>
        <span className="leading-[32px] text-[#f5b301] text-[25px]">brasa</span>
        <span className="leading-[32px] text-[25px]">, sabor de barrio.</span>
      </p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="absolute h-[48px] left-0 top-[88px] w-[576px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-0 not-italic text-[#909395] text-[16px] top-[-1px] w-[576px]">Carne madurada, pan artesano del horno de la esquina y salsas caseras. Filtra la carta por alérgenos y descubre tu favorita.</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="h-[136px] relative shrink-0 w-[576px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Text />
        <Heading />
        <Paragraph />
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_520)" id="Icon">
          <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 5V10L13.3333 11.6667" id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_520">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[0.08px] not-italic text-[#71717b] text-[13px] top-[-2px] whitespace-nowrap">Cola actual</p>
    </div>
  );
}

function Container12() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#e7e8e8] text-[13px] top-0 whitespace-nowrap">4 - 5 min</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="flex-[1_0_0] h-[36px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container11 />
        <Container12 />
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.7)] content-stretch flex gap-[12px] h-[62px] items-center left-0 px-[17px] py-[13px] rounded-[16px] top-0 w-[125.078px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#282e30] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Icon />
      <Container10 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p26ddc800} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p35ba4680} id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#71717b] text-[13px] top-[-4px] whitespace-nowrap">Foodtruck</p>
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#e7e8e8] text-[13px] top-0 whitespace-nowrap">Plaza Mayor, 3</p>
    </div>
  );
}

function Container14() {
  return (
    <div className="flex-[1_0_0] h-[36px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container15 />
        <Container16 />
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.7)] content-stretch flex gap-[12px] h-[62px] items-center left-[137.08px] px-[17px] py-[13px] rounded-[16px] top-0 w-[155.547px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#282e30] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Icon1 />
      <Container14 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p25fc4100} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p3e012060} id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[0.45px] not-italic text-[#71717b] text-[13px] top-[-2px] whitespace-nowrap">Calidad</p>
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#e7e8e8] text-[13px] top-0 whitespace-nowrap">100% Black Angus</p>
    </div>
  );
}

function Container18() {
  return (
    <div className="flex-[1_0_0] h-[36px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container19 />
        <Container20 />
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.7)] content-stretch flex gap-[12px] h-[62px] items-center left-[304.63px] px-[17px] py-[13px] rounded-[16px] top-0 w-[180.453px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#282e30] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Icon2 />
      <Container18 />
    </div>
  );
}

function Container8() {
  return (
    <div className="h-[62px] relative shrink-0 w-[485.078px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container9 />
        <Container13 />
        <Container17 />
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[216px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-end size-full">
        <div className="content-stretch flex items-end justify-between px-[24px] py-[40px] relative size-full">
          <Container7 />
          <Container8 />
        </div>
      </div>
    </div>
  );
}

function Section() {
  return (
    <div className="absolute content-stretch flex flex-col h-[217px] items-start left-0 pb-px px-[128px] top-[77px] w-[1536px]" style={{ backgroundImage: "linear-gradient(171.959deg, rgb(24, 24, 27) 0%, rgb(9, 9, 11) 50%, rgb(0, 0, 0) 100%)" }} data-name="Section">
      <div aria-hidden="true" className="absolute border-[#282e30] border-b border-solid inset-0 pointer-events-none" />
      <Container6 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[30px] relative shrink-0 w-[123.844px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#f4f4f5] text-[20px] top-0 whitespace-nowrap">Nuestra carta</p>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[20px] relative shrink-0 w-[102.984px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#71717b] text-[14px] top-0 whitespace-nowrap">4 hamburguesas</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="content-stretch flex h-[30px] items-end justify-between relative shrink-0 w-full" data-name="Container">
      <Heading1 />
      <Text1 />
    </div>
  );
}

function Text2() {
  return (
    <div className="absolute bg-[#f5b301] drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[20.5px] left-[12px] rounded-[33554400px] top-[6px] w-[71.766px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[5px] not-italic text-[#09090b] text-[13px] top-0 whitespace-nowrap">Bestseller</p>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_524)" id="Icon">
          <path d={svgPaths.p295e8380} fill="var(--fill-0, #FFB900)" id="Vector" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_524">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container24() {
  return (
    <button className="absolute bg-[rgba(9,9,11,0.7)] block cursor-pointer h-[20px] left-[375px] rounded-[33554400px] shadow-[0px_0px_0px_0px_rgba(254,154,0,0.4)] top-[6px] w-[48.5px]" data-name="Container">
      <Icon3 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[24px] not-italic text-[#ffd230] text-[12px] text-left top-[3px] whitespace-nowrap">4.8</p>
    </button>
  );
}

function Container23() {
  return (
    <div className="absolute h-[309px] left-[18px] overflow-clip top-[16px] w-[429px]" data-name="Container">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <img alt="" className="absolute max-w-none object-cover size-full" src={imgContainer} />
        <div className="absolute bg-gradient-to-t from-[rgba(9,9,11,0.9)] inset-0 to-[rgba(0,0,0,0)] via-1/2 via-[rgba(9,9,11,0.2)]" />
      </div>
      <Text2 />
      <Container24 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[27px] relative shrink-0 w-[129.688px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#f4f4f5] text-[20px] top-0 whitespace-nowrap">La Clásica Brasa</p>
      </div>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[27px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-between pr-[232.969px] relative size-full">
        <Heading2 />
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[38.5px] relative shrink-0 w-[362.656px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#9f9fa9] text-[13px] top-0 w-[363px]">Ternera madurada 200g, cheddar curado, bacon ahumado, lechuga, tomate y salsa de la casa.</p>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_496)" id="Icon">
          <path d="M1 11L8 4" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p150c3800} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p24072480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p30182400} id="Vector_4" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p38085540} id="Vector_5" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p396fad80} id="Vector_6" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc1eae00} id="Vector_7" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc429600} id="Vector_8" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_496">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function AllergenBadge() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-0 rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[65.125px]" data-name="AllergenBadge">
      <Icon4 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Gluten</p>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4 1H8" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p228e8780} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p193d7480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge1() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[71.13px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[69.547px]" data-name="AllergenBadge">
      <Icon5 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Lactosa</p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.p20bb7af0} id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge2() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[146.67px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[63.813px]" data-name="AllergenBadge">
      <Icon6 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Huevo</p>
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[20.5px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <AllergenBadge />
        <AllergenBadge1 />
        <AllergenBadge2 />
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[24px] relative shrink-0 w-[52.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#f5b301] text-[16px] top-[-1px] whitespace-nowrap">11.50 €</p>
      </div>
    </div>
  );
}

function Container28() {
  return (
    <div className="h-[44px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pt-[8px] relative size-full">
        <Text3 />
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#f5b301] h-[36px] relative rounded-[33554400px] shrink-0 w-[101.75px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon7 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[62px] not-italic text-[#09090b] text-[14px] text-center top-[8px] whitespace-nowrap">{` PÍDELA`}</p>
      </div>
    </div>
  );
}

function ImageUbicacion() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[60px]" data-name="Image (Ubicación)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImageUbicacion} />
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[62.875px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-0 not-italic text-[#e7e8e8] text-[13px] top-px whitespace-nowrap">Foodtruck</p>
      </div>
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[83.5px] items-center relative shrink-0 w-[62.875px]" data-name="Container">
      <ImageUbicacion />
      <Paragraph2 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="absolute h-[20px] left-[9.5px] top-[59.75px] w-[41px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-[-0.17px] not-italic text-[#e7e8e8] text-[13px] top-[1.5px] whitespace-nowrap">6-8min</p>
    </div>
  );
}

function Container31() {
  return (
    <div className="relative shrink-0 size-[60px]" data-name="Container">
      <img alt="" className="absolute inset-0 max-w-none object-contain pointer-events-none size-full" src={imgContainer1} />
      <Paragraph3 />
    </div>
  );
}

function Container29() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start justify-center relative size-full">
        <Container30 />
        <Container31 />
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[312px] items-start left-[462px] p-[16px] top-0 w-[724px]" data-name="Container">
      <Container26 />
      <Paragraph1 />
      <Container27 />
      <Container28 />
      <Button1 />
      <Container29 />
    </div>
  );
}

function BurgerCard() {
  return (
    <div className="absolute bg-gradient-to-b from-[#18181b] h-[345px] left-0 overflow-clip rounded-[16px] shadow-[0px_0px_0px_1px_#27272a] to-[#09090b] top-0 w-[1252px]" data-name="BurgerCard">
      <Container23 />
      <Container25 />
    </div>
  );
}

function Text4() {
  return (
    <div className="absolute bg-[#f5b301] drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[20.5px] left-[12px] rounded-[33554400px] top-[6px] w-[71.766px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[5px] not-italic text-[#09090b] text-[13px] top-0 whitespace-nowrap">Bestseller</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_524)" id="Icon">
          <path d={svgPaths.p295e8380} fill="var(--fill-0, #FFB900)" id="Vector" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_524">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container33() {
  return (
    <button className="absolute bg-[rgba(9,9,11,0.7)] block cursor-pointer h-[20px] left-[375px] rounded-[33554400px] shadow-[0px_0px_0px_0px_rgba(254,154,0,0.4)] top-[6px] w-[48.5px]" data-name="Container">
      <Icon8 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[24px] not-italic text-[#ffd230] text-[12px] text-left top-[3px] whitespace-nowrap">4.8</p>
    </button>
  );
}

function Container32() {
  return (
    <div className="absolute h-[309px] left-[18px] overflow-clip top-[16px] w-[429px]" data-name="Container">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <img alt="" className="absolute max-w-none object-cover size-full" src={imgContainer} />
        <div className="absolute bg-gradient-to-t from-[rgba(9,9,11,0.9)] inset-0 to-[rgba(0,0,0,0)] via-1/2 via-[rgba(9,9,11,0.2)]" />
      </div>
      <Text4 />
      <Container33 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[27px] relative shrink-0 w-[129.688px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#f4f4f5] text-[20px] top-0 whitespace-nowrap">La Clásica Brasa</p>
      </div>
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[27px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-between pr-[232.969px] relative size-full">
        <Heading3 />
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[38.5px] relative shrink-0 w-[362.656px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#9f9fa9] text-[13px] top-0 w-[363px]">Ternera madurada 200g, cheddar curado, bacon ahumado, lechuga, tomate y salsa de la casa.</p>
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_496)" id="Icon">
          <path d="M1 11L8 4" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p150c3800} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p24072480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p30182400} id="Vector_4" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p38085540} id="Vector_5" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p396fad80} id="Vector_6" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc1eae00} id="Vector_7" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc429600} id="Vector_8" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_496">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function AllergenBadge3() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-0 rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[65.125px]" data-name="AllergenBadge">
      <Icon9 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Gluten</p>
    </div>
  );
}

function Icon10() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4 1H8" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p228e8780} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p193d7480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge4() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[71.13px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[69.547px]" data-name="AllergenBadge">
      <Icon10 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Lactosa</p>
    </div>
  );
}

function Icon11() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.p20bb7af0} id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge5() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[146.67px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[63.813px]" data-name="AllergenBadge">
      <Icon11 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Huevo</p>
    </div>
  );
}

function Container36() {
  return (
    <div className="h-[20.5px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <AllergenBadge3 />
        <AllergenBadge4 />
        <AllergenBadge5 />
      </div>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[24px] relative shrink-0 w-[52.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#f5b301] text-[16px] top-[-1px] whitespace-nowrap">11.50 €</p>
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[44px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pt-[8px] relative size-full">
        <Text5 />
      </div>
    </div>
  );
}

function Icon12() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#f5b301] h-[36px] relative rounded-[33554400px] shrink-0 w-[101.75px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon12 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[62px] not-italic text-[#09090b] text-[14px] text-center top-[8px] whitespace-nowrap">{` PÍDELA`}</p>
      </div>
    </div>
  );
}

function ImageUbicacion1() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[60px]" data-name="Image (Ubicación)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImageUbicacion} />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[62.875px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-0 not-italic text-[#e7e8e8] text-[13px] top-px whitespace-nowrap">Foodtruck</p>
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[83.5px] items-center relative shrink-0 w-[62.875px]" data-name="Container">
      <ImageUbicacion1 />
      <Paragraph5 />
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="absolute h-[20px] left-[9.5px] top-[59.75px] w-[41px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-[-0.17px] not-italic text-[#e7e8e8] text-[13px] top-[1.5px] whitespace-nowrap">6-8min</p>
    </div>
  );
}

function Container40() {
  return (
    <div className="relative shrink-0 size-[60px]" data-name="Container">
      <img alt="" className="absolute inset-0 max-w-none object-contain pointer-events-none size-full" src={imgContainer1} />
      <Paragraph6 />
    </div>
  );
}

function Container38() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start justify-center relative size-full">
        <Container39 />
        <Container40 />
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[312px] items-start left-[462px] p-[16px] top-0 w-[724px]" data-name="Container">
      <Container35 />
      <Paragraph4 />
      <Container36 />
      <Container37 />
      <Button2 />
      <Container38 />
    </div>
  );
}

function BurgerCard1() {
  return (
    <div className="absolute bg-gradient-to-b from-[#18181b] h-[345px] left-0 overflow-clip rounded-[16px] shadow-[0px_0px_0px_1px_#27272a] to-[#09090b] top-[473px] w-[1252px]" data-name="BurgerCard">
      <Container32 />
      <Container34 />
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute bg-[#f5b301] drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[20.5px] left-[12px] rounded-[33554400px] top-[6px] w-[71.766px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[5px] not-italic text-[#09090b] text-[13px] top-0 whitespace-nowrap">Bestseller</p>
    </div>
  );
}

function Icon13() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_524)" id="Icon">
          <path d={svgPaths.p295e8380} fill="var(--fill-0, #FFB900)" id="Vector" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_524">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container42() {
  return (
    <button className="absolute bg-[rgba(9,9,11,0.7)] block cursor-pointer h-[20px] left-[375px] rounded-[33554400px] shadow-[0px_0px_0px_0px_rgba(254,154,0,0.4)] top-[6px] w-[48.5px]" data-name="Container">
      <Icon13 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[24px] not-italic text-[#ffd230] text-[12px] text-left top-[3px] whitespace-nowrap">4.8</p>
    </button>
  );
}

function Container41() {
  return (
    <div className="absolute h-[309px] left-[18px] overflow-clip top-[16px] w-[429px]" data-name="Container">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <img alt="" className="absolute max-w-none object-cover size-full" src={imgContainer} />
        <div className="absolute bg-gradient-to-t from-[rgba(9,9,11,0.9)] inset-0 to-[rgba(0,0,0,0)] via-1/2 via-[rgba(9,9,11,0.2)]" />
      </div>
      <Text6 />
      <Container42 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="h-[27px] relative shrink-0 w-[129.688px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#f4f4f5] text-[20px] top-0 whitespace-nowrap">La Clásica Brasa</p>
      </div>
    </div>
  );
}

function Container44() {
  return (
    <div className="h-[27px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-between pr-[232.969px] relative size-full">
        <Heading4 />
      </div>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[38.5px] relative shrink-0 w-[362.656px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#9f9fa9] text-[13px] top-0 w-[363px]">Ternera madurada 200g, cheddar curado, bacon ahumado, lechuga, tomate y salsa de la casa.</p>
      </div>
    </div>
  );
}

function Icon14() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_496)" id="Icon">
          <path d="M1 11L8 4" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p150c3800} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p24072480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p30182400} id="Vector_4" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p38085540} id="Vector_5" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p396fad80} id="Vector_6" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc1eae00} id="Vector_7" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc429600} id="Vector_8" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_496">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function AllergenBadge6() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-0 rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[65.125px]" data-name="AllergenBadge">
      <Icon14 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Gluten</p>
    </div>
  );
}

function Icon15() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4 1H8" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p228e8780} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p193d7480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge7() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[71.13px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[69.547px]" data-name="AllergenBadge">
      <Icon15 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Lactosa</p>
    </div>
  );
}

function Icon16() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.p20bb7af0} id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge8() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[146.67px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[63.813px]" data-name="AllergenBadge">
      <Icon16 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Huevo</p>
    </div>
  );
}

function Container45() {
  return (
    <div className="h-[20.5px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <AllergenBadge6 />
        <AllergenBadge7 />
        <AllergenBadge8 />
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[24px] relative shrink-0 w-[52.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#f5b301] text-[16px] top-[-1px] whitespace-nowrap">11.50 €</p>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="h-[44px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pt-[8px] relative size-full">
        <Text7 />
      </div>
    </div>
  );
}

function Icon17() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#f5b301] h-[36px] relative rounded-[33554400px] shrink-0 w-[101.75px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon17 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[62px] not-italic text-[#09090b] text-[14px] text-center top-[8px] whitespace-nowrap">{` PÍDELA`}</p>
      </div>
    </div>
  );
}

function ImageUbicacion2() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[60px]" data-name="Image (Ubicación)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImageUbicacion} />
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[62.875px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-0 not-italic text-[#e7e8e8] text-[13px] top-px whitespace-nowrap">Foodtruck</p>
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[83.5px] items-center relative shrink-0 w-[62.875px]" data-name="Container">
      <ImageUbicacion2 />
      <Paragraph8 />
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="absolute h-[20px] left-[9.5px] top-[59.75px] w-[41px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-[-0.17px] not-italic text-[#e7e8e8] text-[13px] top-[1.5px] whitespace-nowrap">6-8min</p>
    </div>
  );
}

function Container49() {
  return (
    <div className="relative shrink-0 size-[60px]" data-name="Container">
      <img alt="" className="absolute inset-0 max-w-none object-contain pointer-events-none size-full" src={imgContainer1} />
      <Paragraph9 />
    </div>
  );
}

function Container47() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start justify-center relative size-full">
        <Container48 />
        <Container49 />
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[312px] items-start left-[462px] p-[16px] top-0 w-[724px]" data-name="Container">
      <Container44 />
      <Paragraph7 />
      <Container45 />
      <Container46 />
      <Button3 />
      <Container47 />
    </div>
  );
}

function BurgerCard2() {
  return (
    <div className="absolute bg-gradient-to-b from-[#18181b] h-[345px] left-0 overflow-clip rounded-[16px] shadow-[0px_0px_0px_1px_#27272a] to-[#09090b] top-[946px] w-[1252px]" data-name="BurgerCard">
      <Container41 />
      <Container43 />
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute bg-[#f5b301] drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[20.5px] left-[12px] rounded-[33554400px] top-[6px] w-[71.766px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[5px] not-italic text-[#09090b] text-[13px] top-0 whitespace-nowrap">Bestseller</p>
    </div>
  );
}

function Icon18() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_524)" id="Icon">
          <path d={svgPaths.p295e8380} fill="var(--fill-0, #FFB900)" id="Vector" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_524">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container51() {
  return (
    <button className="absolute bg-[rgba(9,9,11,0.7)] block cursor-pointer h-[20px] left-[375px] rounded-[33554400px] shadow-[0px_0px_0px_0px_rgba(254,154,0,0.4)] top-[6px] w-[48.5px]" data-name="Container">
      <Icon18 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[24px] not-italic text-[#ffd230] text-[12px] text-left top-[3px] whitespace-nowrap">4.8</p>
    </button>
  );
}

function Container50() {
  return (
    <div className="absolute h-[309px] left-[18px] overflow-clip top-[16px] w-[429px]" data-name="Container">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <img alt="" className="absolute max-w-none object-cover size-full" src={imgContainer} />
        <div className="absolute bg-gradient-to-t from-[rgba(9,9,11,0.9)] inset-0 to-[rgba(0,0,0,0)] via-1/2 via-[rgba(9,9,11,0.2)]" />
      </div>
      <Text8 />
      <Container51 />
    </div>
  );
}

function Heading5() {
  return (
    <div className="h-[27px] relative shrink-0 w-[129.688px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#f4f4f5] text-[20px] top-0 whitespace-nowrap">La Clásica Brasa</p>
      </div>
    </div>
  );
}

function Container53() {
  return (
    <div className="h-[27px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-between pr-[232.969px] relative size-full">
        <Heading5 />
      </div>
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="h-[38.5px] relative shrink-0 w-[362.656px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#9f9fa9] text-[13px] top-0 w-[363px]">Ternera madurada 200g, cheddar curado, bacon ahumado, lechuga, tomate y salsa de la casa.</p>
      </div>
    </div>
  );
}

function Icon19() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_1_496)" id="Icon">
          <path d="M1 11L8 4" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p150c3800} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p24072480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p30182400} id="Vector_4" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p38085540} id="Vector_5" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p396fad80} id="Vector_6" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc1eae00} id="Vector_7" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc429600} id="Vector_8" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_496">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function AllergenBadge9() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-0 rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[65.125px]" data-name="AllergenBadge">
      <Icon19 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Gluten</p>
    </div>
  );
}

function Icon20() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4 1H8" id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p228e8780} id="Vector_2" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p193d7480} id="Vector_3" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge10() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[71.13px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[69.547px]" data-name="AllergenBadge">
      <Icon20 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Lactosa</p>
    </div>
  );
}

function Icon21() {
  return (
    <div className="absolute left-[8px] size-[12px] top-[4.25px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.p20bb7af0} id="Vector" stroke="var(--stroke-0, #D4D4D8)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function AllergenBadge11() {
  return (
    <div className="absolute bg-[rgba(39,39,42,0.8)] h-[20.5px] left-[146.67px] rounded-[33554400px] shadow-[0px_0px_0px_0px_#3f3f47] top-0 w-[63.813px]" data-name="AllergenBadge">
      <Icon21 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[24px] not-italic text-[#d4d4d8] text-[11px] top-[2px] whitespace-nowrap">Huevo</p>
    </div>
  );
}

function Container54() {
  return (
    <div className="h-[20.5px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <AllergenBadge9 />
        <AllergenBadge10 />
        <AllergenBadge11 />
      </div>
    </div>
  );
}

function Text9() {
  return (
    <div className="h-[24px] relative shrink-0 w-[52.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#f5b301] text-[16px] top-[-1px] whitespace-nowrap">11.50 €</p>
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div className="h-[44px] relative shrink-0 w-[362.656px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pt-[8px] relative size-full">
        <Text9 />
      </div>
    </div>
  );
}

function Icon22() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, #09090B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-[#f5b301] h-[36px] relative rounded-[33554400px] shrink-0 w-[101.75px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon22 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[62px] not-italic text-[#09090b] text-[14px] text-center top-[8px] whitespace-nowrap">{` PÍDELA`}</p>
      </div>
    </div>
  );
}

function ImageUbicacion3() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[60px]" data-name="Image (Ubicación)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImageUbicacion} />
    </div>
  );
}

function Paragraph11() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[62.875px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-0 not-italic text-[#e7e8e8] text-[13px] top-px whitespace-nowrap">Foodtruck</p>
      </div>
    </div>
  );
}

function Container57() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[83.5px] items-center relative shrink-0 w-[62.875px]" data-name="Container">
      <ImageUbicacion3 />
      <Paragraph11 />
    </div>
  );
}

function Paragraph12() {
  return (
    <div className="absolute h-[20px] left-[9.5px] top-[59.75px] w-[41px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-[-0.17px] not-italic text-[#e7e8e8] text-[13px] top-[1.5px] whitespace-nowrap">6-8min</p>
    </div>
  );
}

function Container58() {
  return (
    <div className="relative shrink-0 size-[60px]" data-name="Container">
      <img alt="" className="absolute inset-0 max-w-none object-contain pointer-events-none size-full" src={imgContainer1} />
      <Paragraph12 />
    </div>
  );
}

function Container56() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start justify-center relative size-full">
        <Container57 />
        <Container58 />
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[312px] items-start left-[462px] p-[16px] top-0 w-[724px]" data-name="Container">
      <Container53 />
      <Paragraph10 />
      <Container54 />
      <Container55 />
      <Button4 />
      <Container56 />
    </div>
  );
}

function BurgerCard3() {
  return (
    <div className="absolute bg-gradient-to-b from-[#18181b] h-[345px] left-0 overflow-clip rounded-[16px] shadow-[0px_0px_0px_1px_#27272a] to-[#09090b] top-[1442px] w-[1252px]" data-name="BurgerCard">
      <Container50 />
      <Container52 />
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[1787px] relative shrink-0 w-full" data-name="Container">
      <BurgerCard />
      <BurgerCard1 />
      <BurgerCard2 />
      <BurgerCard3 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[1881px] items-start left-[128px] pt-[40px] px-[24px] top-[294px] w-[1280px]" data-name="Main Content">
      <Container21 />
      <Container22 />
    </div>
  );
}

function Heading6() {
  return (
    <div className="h-[27px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[32px] left-0 not-italic text-[#f5b301] text-[25px] top-0 whitespace-nowrap">FAQ</p>
    </div>
  );
}

function Text10() {
  return (
    <div className="h-[24px] relative shrink-0 w-[262.297px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-[-1px] whitespace-nowrap">¿Cuál es el tiempo de espera medio?</p>
      </div>
    </div>
  );
}

function Icon23() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M5 7.5L10 12.5L15 7.5" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="content-stretch flex h-[56px] items-center justify-between py-[16px] relative shrink-0 w-full" data-name="Button">
      <Text10 />
      <Icon23 />
    </div>
  );
}

function FaqItem() {
  return (
    <div className="content-stretch flex flex-col h-[57px] items-start pb-px relative shrink-0 w-full" data-name="FaqItem">
      <div aria-hidden="true" className="absolute border-[#1b1f21] border-b border-solid inset-0 pointer-events-none" />
      <Button5 />
    </div>
  );
}

function Text11() {
  return (
    <div className="h-[24px] relative shrink-0 w-[193.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-[-1px] whitespace-nowrap">¿Hacéis envíos a domicilio?</p>
      </div>
    </div>
  );
}

function Icon24() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M5 7.5L10 12.5L15 7.5" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="content-stretch flex h-[56px] items-center justify-between py-[16px] relative shrink-0 w-full" data-name="Button">
      <Text11 />
      <Icon24 />
    </div>
  );
}

function FaqItem1() {
  return (
    <div className="content-stretch flex flex-col h-[57px] items-start pb-px relative shrink-0 w-full" data-name="FaqItem">
      <div aria-hidden="true" className="absolute border-[#1b1f21] border-b border-solid inset-0 pointer-events-none" />
      <Button6 />
    </div>
  );
}

function Text12() {
  return (
    <div className="h-[24px] relative shrink-0 w-[279.609px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-[-1px] whitespace-nowrap">¿Tenéis opciones sin gluten o veganas?</p>
      </div>
    </div>
  );
}

function Icon25() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M5 7.5L10 12.5L15 7.5" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="content-stretch flex h-[56px] items-center justify-between py-[16px] relative shrink-0 w-full" data-name="Button">
      <Text12 />
      <Icon25 />
    </div>
  );
}

function FaqItem2() {
  return (
    <div className="content-stretch flex flex-col h-[57px] items-start pb-px relative shrink-0 w-full" data-name="FaqItem">
      <div aria-hidden="true" className="absolute border-[#1b1f21] border-b border-solid inset-0 pointer-events-none" />
      <Button7 />
    </div>
  );
}

function Text13() {
  return (
    <div className="h-[24px] relative shrink-0 w-[212.641px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-[-1px] whitespace-nowrap">¿De dónde proviene la carne?</p>
      </div>
    </div>
  );
}

function Icon26() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M5 7.5L10 12.5L15 7.5" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="content-stretch flex h-[56px] items-center justify-between py-[16px] relative shrink-0 w-full" data-name="Button">
      <Text13 />
      <Icon26 />
    </div>
  );
}

function FaqItem3() {
  return (
    <div className="content-stretch flex flex-col h-[57px] items-start pb-px relative shrink-0 w-full" data-name="FaqItem">
      <div aria-hidden="true" className="absolute border-[#1b1f21] border-b border-solid inset-0 pointer-events-none" />
      <Button8 />
    </div>
  );
}

function Text14() {
  return (
    <div className="h-[24px] relative shrink-0 w-[215.141px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-[-1px] whitespace-nowrap">¿Puedo reservar para grupos?</p>
      </div>
    </div>
  );
}

function Icon27() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M5 7.5L10 12.5L15 7.5" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="content-stretch flex h-[56px] items-center justify-between py-[16px] relative shrink-0 w-full" data-name="Button">
      <Text14 />
      <Icon27 />
    </div>
  );
}

function FaqItem4() {
  return (
    <div className="content-stretch flex flex-col h-[57px] items-start pb-px relative shrink-0 w-full" data-name="FaqItem">
      <div aria-hidden="true" className="absolute border-[#1b1f21] border-b border-solid inset-0 pointer-events-none" />
      <Button9 />
    </div>
  );
}

function Text15() {
  return (
    <div className="h-[24px] relative shrink-0 w-[198.094px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-[-1px] whitespace-nowrap">¿Aceptáis pago con tarjeta?</p>
      </div>
    </div>
  );
}

function Icon28() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M5 7.5L10 12.5L15 7.5" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="content-stretch flex h-[56px] items-center justify-between py-[16px] relative shrink-0 w-full" data-name="Button">
      <Text15 />
      <Icon28 />
    </div>
  );
}

function Container60() {
  return (
    <div className="content-stretch flex flex-col h-[341px] items-start relative shrink-0 w-full" data-name="Container">
      <FaqItem />
      <FaqItem1 />
      <FaqItem2 />
      <FaqItem3 />
      <FaqItem4 />
      <Button10 />
    </div>
  );
}

function Section1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[384px] items-start left-[24px] top-[56px] w-[378.656px]" data-name="Section">
      <Heading6 />
      <Container60 />
    </div>
  );
}

function Heading7() {
  return (
    <div className="h-[27px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[32px] left-0 not-italic text-[#f5b301] text-[25px] top-0 whitespace-nowrap">REDES SOCIALES</p>
    </div>
  );
}

function Container62() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-0 whitespace-nowrap">Instagram</p>
    </div>
  );
}

function Container63() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#616668] text-[12px] top-px whitespace-nowrap">@championsburgerremake</p>
    </div>
  );
}

function Container61() {
  return (
    <div className="h-[36px] relative shrink-0 w-[76.922px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container62 />
        <Container63 />
      </div>
    </div>
  );
}

function Link5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] content-stretch flex gap-[12px] h-[58px] items-center left-0 px-[13px] py-[11px] rounded-[14px] top-0 w-[378.672px]" data-name="Link">
      <div aria-hidden="true" className="absolute border border-[#1b1f21] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="relative shrink-0 size-[48px]" data-name="Instagram">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
          <div className="absolute inset-[12.5%]" data-name="Vector">
            <div className="absolute inset-[-4.17%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 39">
                <path d={svgPaths.p3f59f600} fill="var(--fill-0, #1A1818)" id="Vector" stroke="var(--stroke-0, #F59E0B)" strokeLinejoin="round" strokeWidth="3" />
              </svg>
            </div>
          </div>
          <div className="absolute inset-[33.33%]" data-name="Vector">
            <div className="absolute inset-[-9.38%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
                <path d={svgPaths.p26c2ca00} fill="var(--fill-0, #1A1818)" id="Vector" stroke="var(--stroke-0, #F59E0B)" strokeWidth="3" />
              </svg>
            </div>
          </div>
          <div className="absolute inset-[26.04%_26.04%_63.54%_63.54%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
              <path d={svgPaths.p3b29e480} fill="var(--fill-0, #F59E0B)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
      <Container61 />
    </div>
  );
}

function ListItem() {
  return (
    <div className="h-[58px] relative shrink-0 w-full" data-name="List Item">
      <Link5 />
    </div>
  );
}

function Container65() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-0 whitespace-nowrap">Facebook</p>
    </div>
  );
}

function Container66() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#616668] text-[12px] top-px whitespace-nowrap">/ChampionsBurgerRemake</p>
    </div>
  );
}

function Container64() {
  return (
    <div className="h-[36px] relative shrink-0 w-[71.203px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container65 />
        <Container66 />
      </div>
    </div>
  );
}

function Link6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] content-stretch flex gap-[12px] h-[58px] items-center left-0 px-[13px] py-[11px] rounded-[14px] top-0 w-[378.672px]" data-name="Link">
      <div aria-hidden="true" className="absolute border border-[#1b1f21] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="relative shrink-0 size-[48px]" data-name="Facebook">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
          <div className="absolute inset-[12.5%]" data-name="Vector">
            <div className="absolute inset-[-4.17%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 39">
                <path d={svgPaths.p2a9b7100} fill="var(--fill-0, #1A1818)" id="Vector" stroke="var(--stroke-0, #F59E0B)" strokeLinejoin="round" strokeWidth="3" />
              </svg>
            </div>
          </div>
          <div className="absolute bottom-[12.5%] left-[29.17%] right-[33.33%] top-1/4" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 30">
              <path d={svgPaths.p87b03c0} fill="var(--fill-0, #F59E0B)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
      <Container64 />
    </div>
  );
}

function ListItem1() {
  return (
    <div className="h-[58px] relative shrink-0 w-full" data-name="List Item">
      <Link6 />
    </div>
  );
}

function Container68() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#d4d5d6] text-[16px] top-0 whitespace-nowrap">TikTok</p>
    </div>
  );
}

function Container69() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#616668] text-[12px] top-px whitespace-nowrap">@championsburgerremake</p>
    </div>
  );
}

function Container67() {
  return (
    <div className="h-[36px] relative shrink-0 w-[76.922px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container68 />
        <Container69 />
      </div>
    </div>
  );
}

function Link7() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] content-stretch flex gap-[12px] h-[58px] items-center left-0 px-[13px] py-[11px] rounded-[14px] top-0 w-[378.672px]" data-name="Link">
      <div aria-hidden="true" className="absolute border border-[#1b1f21] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="relative shrink-0 size-[48px]" data-name="TikTok">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
          <div className="absolute inset-[12.5%]" data-name="Vector">
            <div className="absolute inset-[-4.17%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 39">
                <path d={svgPaths.p3f59f600} fill="var(--fill-0, #1A1818)" id="Vector" stroke="var(--stroke-0, #F59E0B)" strokeLinejoin="round" strokeWidth="3" />
              </svg>
            </div>
          </div>
          <div className="absolute inset-[29.17%_30.56%_18.75%_20.83%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.3333 25">
              <path d={svgPaths.p1fa5e400} fill="var(--fill-0, #F59E0B)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
      <Container67 />
    </div>
  );
}

function ListItem2() {
  return (
    <div className="h-[58px] relative shrink-0 w-full" data-name="List Item">
      <Link7 />
    </div>
  );
}

function ListItem3() {
  return <div className="h-[58px] relative shrink-0 w-full" data-name="List Item" />;
}

function List() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[338px] items-start relative shrink-0 w-full" data-name="List">
      <ListItem />
      <ListItem1 />
      <ListItem2 />
      <ListItem3 />
    </div>
  );
}

function Section2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[384px] items-start left-[451px] top-[56px] w-[378.672px]" data-name="Section">
      <Heading7 />
      <List />
    </div>
  );
}

function Heading8() {
  return (
    <div className="h-[27px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[32px] left-0 not-italic text-[#f5b301] text-[25px] top-0 whitespace-nowrap">AVISOS LEGALES</p>
    </div>
  );
}

function Icon29() {
  return (
    <div className="relative size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #616668)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Link8() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] border border-[#1b1f21] border-solid h-[38px] left-0 rounded-[10px] top-0 w-[378.656px]" data-name="Link">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[12px] not-italic text-[#b4b6b7] text-[16px] top-[8px] whitespace-nowrap">Aviso legal</p>
      <div className="absolute flex items-center justify-center left-[348.66px] size-[16px] top-[10px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <Icon29 />
        </div>
      </div>
    </div>
  );
}

function ListItem4() {
  return (
    <div className="h-[38px] relative shrink-0 w-full" data-name="List Item">
      <Link8 />
    </div>
  );
}

function Icon30() {
  return (
    <div className="relative size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #616668)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Link9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] border border-[#1b1f21] border-solid h-[38px] left-0 rounded-[10px] top-0 w-[378.656px]" data-name="Link">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[12px] not-italic text-[#b4b6b7] text-[16px] top-[8px] whitespace-nowrap">Política de privacidad</p>
      <div className="absolute flex items-center justify-center left-[348.66px] size-[16px] top-[10px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <Icon30 />
        </div>
      </div>
    </div>
  );
}

function ListItem5() {
  return (
    <div className="h-[38px] relative shrink-0 w-full" data-name="List Item">
      <Link9 />
    </div>
  );
}

function Icon31() {
  return (
    <div className="relative size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #616668)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Link10() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] border border-[#1b1f21] border-solid h-[38px] left-0 rounded-[10px] top-0 w-[378.656px]" data-name="Link">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[12px] not-italic text-[#b4b6b7] text-[16px] top-[8px] whitespace-nowrap">Política de cookies</p>
      <div className="absolute flex items-center justify-center left-[348.66px] size-[16px] top-[10px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <Icon31 />
        </div>
      </div>
    </div>
  );
}

function ListItem6() {
  return (
    <div className="h-[38px] relative shrink-0 w-full" data-name="List Item">
      <Link10 />
    </div>
  );
}

function Icon32() {
  return (
    <div className="relative size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #616668)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Link11() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] border border-[#1b1f21] border-solid h-[38px] left-0 rounded-[10px] top-0 w-[378.656px]" data-name="Link">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[12px] not-italic text-[#b4b6b7] text-[16px] top-[8px] whitespace-nowrap">Términos y condiciones</p>
      <div className="absolute flex items-center justify-center left-[348.66px] size-[16px] top-[10px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <Icon32 />
        </div>
      </div>
    </div>
  );
}

function ListItem7() {
  return (
    <div className="h-[38px] relative shrink-0 w-full" data-name="List Item">
      <Link11 />
    </div>
  );
}

function Icon33() {
  return (
    <div className="relative size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #616668)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Link12() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] border border-[#1b1f21] border-solid h-[38px] left-0 rounded-[10px] top-0 w-[378.656px]" data-name="Link">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[12px] not-italic text-[#b4b6b7] text-[16px] top-[8px] whitespace-nowrap">Información nutricional</p>
      <div className="absolute flex items-center justify-center left-[348.66px] size-[16px] top-[10px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <Icon33 />
        </div>
      </div>
    </div>
  );
}

function ListItem8() {
  return (
    <div className="h-[38px] relative shrink-0 w-full" data-name="List Item">
      <Link12 />
    </div>
  );
}

function Icon34() {
  return (
    <div className="relative size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #616668)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Link13() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.3)] border border-[#1b1f21] border-solid h-[38px] left-0 rounded-[10px] top-0 w-[378.656px]" data-name="Link">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[12px] not-italic text-[#b4b6b7] text-[16px] top-[8px] whitespace-nowrap">Reclamaciones</p>
      <div className="absolute flex items-center justify-center left-[348.66px] size-[16px] top-[10px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <Icon34 />
        </div>
      </div>
    </div>
  );
}

function ListItem9() {
  return (
    <div className="h-[38px] relative shrink-0 w-full" data-name="List Item">
      <Link13 />
    </div>
  );
}

function List1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[268px] items-start relative shrink-0 w-full" data-name="List">
      <ListItem4 />
      <ListItem5 />
      <ListItem6 />
      <ListItem7 />
      <ListItem8 />
      <ListItem9 />
    </div>
  );
}

function Section3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[384px] items-start left-[877.33px] top-[56px] w-[378.656px]" data-name="Section">
      <Heading8 />
      <List1 />
    </div>
  );
}

function Container59() {
  return (
    <div className="absolute h-[496px] left-[128px] top-0 w-[1280px]" data-name="Container">
      <Section1 />
      <Section2 />
      <Section3 />
    </div>
  );
}

function Text16() {
  return (
    <div className="h-[16px] relative shrink-0 w-[316.922px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#616668] text-[13px] top-px whitespace-nowrap">© 2026 Remake Champions Burger — Todos los derechos reservados.</p>
      </div>
    </div>
  );
}

function Text17() {
  return (
    <div className="h-[16px] relative shrink-0 w-[148.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#616668] text-[12px] top-px whitespace-nowrap">Hecho con fuego en Granada</p>
      </div>
    </div>
  );
}

function Container71() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[24px] py-[16px] relative size-full">
          <Text16 />
          <Text17 />
        </div>
      </div>
    </div>
  );
}

function Container70() {
  return (
    <div className="absolute content-stretch flex flex-col h-[49px] items-start left-0 pt-px px-[128px] top-[496px] w-[1536px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#212728] border-solid border-t inset-0 pointer-events-none" />
      <Container71 />
    </div>
  );
}

function Footer() {
  return (
    <div className="absolute bg-[#0b0e0f] border-[#1b1f21] border-solid border-t h-[546px] left-0 top-[2242px] w-[1534px]" data-name="Footer">
      <Container59 />
      <Container70 />
    </div>
  );
}

function App() {
  return (
    <div className="bg-[#09090b] h-[2788px] relative shrink-0 w-full" data-name="App">
      <Header />
      <Section />
      <MainContent />
      <Footer />
    </div>
  );
}

function Body() {
  return (
    <div className="content-stretch flex flex-col h-[2788px] items-start relative shrink-0 w-full" data-name="Body">
      <App />
    </div>
  );
}

export default function MejorarPaginaDeHamburguesas() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="Mejorar página de hamburguesas">
      <Body />
    </div>
  );
}