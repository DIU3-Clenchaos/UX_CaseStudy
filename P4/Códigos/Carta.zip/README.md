
  # Carta

  This is a code bundle for Carta. The original project is available at https://www.figma.com/design/umOBe1oAutbmwpfvyrIp1I/Carta.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  