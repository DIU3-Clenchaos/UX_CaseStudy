
  # Landing Page

  This is a code bundle for Landing Page. The original project is available at https://www.figma.com/design/qb3R4W4QMBYFErtPn7tJvK/Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  