import svgPaths from "./svg-l1d2qarchk";
import imgImageLogo from "./888653ba5fdb58cd59db834a97c5d661a63e415d.png";
import imgImageBurger from "./30c8dc484b74a2a47fa60f5a06530486e9682ec3.png";
import imgImage from "./e5038df173c3c73bae249cd8fd60ed2b7abfed81.png";
import imgImage1 from "./dfc418bc3ffb17e7aa87d42e888b0ec31d12976c.png";
import imgImage2 from "./967609dd24c3957c61397826b1692acdf1ef50b7.png";

function ImageLogo() {
  return (
    <div className="h-[64px] relative shrink-0 w-full" data-name="Image (logo)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageLogo} />
    </div>
  );
}

function Container() {
  return (
    <div className="h-[64px] relative shrink-0 w-[59px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <ImageLogo />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="flex-[1_0_0] h-[24px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#fef6e9] text-[16px] top-[-0.5px] tracking-[0.4px] whitespace-nowrap">Remake Champions Burguer</p>
      </div>
    </div>
  );
}

function Link() {
  return (
    <div className="h-[64px] relative shrink-0 w-[279.609px]" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container />
        <Text />
      </div>
    </div>
  );
}

function Text1() {
  return <div className="absolute bg-[#f5b301] h-[2px] left-0 top-[23px] w-0" data-name="Text" />;
}

function ListItem() {
  return (
    <div className="h-[24px] relative shrink-0 w-[33.773px]" data-name="List Item">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[14px] text-[rgba(255,255,255,0.7)] top-[2.5px] whitespace-nowrap">Carta</p>
        <Text1 />
      </div>
    </div>
  );
}

function Text2() {
  return <div className="absolute bg-[#f5b301] h-[2px] left-0 top-[23px] w-0" data-name="Text" />;
}

function ListItem1() {
  return (
    <div className="flex-[1_0_0] h-[24px] min-w-px relative" data-name="List Item">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[14px] text-[rgba(255,255,255,0.7)] top-[2.5px] whitespace-nowrap">Historia</p>
        <Text2 />
      </div>
    </div>
  );
}

function Text3() {
  return <div className="absolute bg-[#f5b301] h-[2px] left-0 top-[23px] w-0" data-name="Text" />;
}

function ListItem2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[46.453px]" data-name="List Item">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[14px] text-[rgba(255,255,255,0.7)] top-[2.5px] whitespace-nowrap">Locales</p>
        <Text3 />
      </div>
    </div>
  );
}

function List() {
  return (
    <div className="h-[24px] relative shrink-0 w-[193.031px]" data-name="List">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[32px] items-center relative size-full">
        <ListItem />
        <ListItem1 />
        <ListItem2 />
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#f5b301] h-[40px] relative rounded-[10px] shrink-0 w-[115.906px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[16px] py-[8px] relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[16px] text-black text-center whitespace-nowrap">Pedir ahora</p>
      </div>
    </div>
  );
}

function Navigation1() {
  return (
    <div className="h-[96px] relative shrink-0 w-full" data-name="Navigation">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[32px] py-[16px] relative size-full">
          <Link />
          <List />
          <Button />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="bg-[rgba(13,13,13,0.7)] content-stretch flex flex-col h-[97px] items-start pb-px relative shrink-0 w-full" data-name="Navigation">
      <div aria-hidden="true" className="absolute border-[rgba(255,255,255,0.05)] border-b border-solid inset-0 pointer-events-none" />
      <Navigation1 />
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[12px] size-[12px] top-[7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.p5a7a980} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="bg-[rgba(255,184,0,0.1)] h-[26px] relative rounded-[16777200px] shrink-0 w-[177.133px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[32px] not-italic text-[#f5b301] text-[12px] top-[4.5px] tracking-[1.2px] whitespace-nowrap">{` HECHAS A LA BRASA`}</p>
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[894px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <div className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[0] left-0 not-italic text-[#fef6e9] text-[60px] top-[0.5px] tracking-[-1.5px] whitespace-nowrap">
          <p className="leading-[63px] mb-0">Aqui, la competición,</p>
          <p className="leading-[63px] text-[#f5b301]">se cocina.</p>
        </div>
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[48px] relative shrink-0 w-[448px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#909395] text-[16px] top-[-0.5px] w-[448px]">Hamburguesas artesanas asadas sobre brasa de encina. Sin atajos, sin prisas — solo carne y fuego.</p>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[195.33px] size-[16px] top-[17px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1d405500} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#f5b301] h-[50px] left-0 rounded-[10px] top-[8px] w-[235.328px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[106.5px] not-italic text-[16px] text-black text-center top-[12.5px] whitespace-nowrap">Pedir mi hamburguesa</p>
      <Icon1 />
    </div>
  );
}

function Link1() {
  return (
    <div className="absolute border border-[rgba(255,255,255,0.2)] border-solid h-[50px] left-[251.33px] rounded-[10px] top-[8px] w-[114.305px]" data-name="Link">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[24px] not-italic text-[#fef6e9] text-[16px] top-[11.5px] whitespace-nowrap">Ver carta</p>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[58px] relative shrink-0 w-[894px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button1 />
        <Link1 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="absolute left-0 size-[14px] top-[5px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p6932200} fill="var(--fill-0, #F5B301)" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[24px] relative shrink-0 w-[158.93px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon2 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[18px] not-italic text-[16px] text-[rgba(255,255,255,0.5)] top-[-0.5px] whitespace-nowrap">4.9 · +2.300 reseñas</p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[40px] relative shrink-0 w-[894px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center pt-[16px] relative size-full">
        <Text5 />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[394px] items-start left-0 top-0 w-[894px]" data-name="Container">
      <Text4 />
      <Heading />
      <Paragraph />
      <Container3 />
      <Container4 />
    </div>
  );
}

function ImageBurger() {
  return (
    <div className="h-[550px] relative shrink-0 w-full" data-name="Image (burger)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageBurger} />
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0)] h-[552px] left-0 rounded-[16px] top-[442px] w-[894px]" data-name="Container">
      <div className="content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
        <ImageBurger />
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_30px_80px_-20px_rgba(255,184,0,0.35)]" />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute bg-[#1a1a1a] border border-[rgba(255,255,255,0.1)] border-solid h-[36px] left-[680.75px] rounded-[16777200px] top-[425.49px] w-[181px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[15.75px] not-italic text-[#fef6e9] text-[12px] top-[8.75px] whitespace-nowrap">🔥 Recién salida de la brasa</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute bg-[#f5b301] drop-shadow-[0px_20px_20px_rgba(0,0,0,0.3)] h-[48px] left-[32px] rounded-[14px] top-[962px] w-[212.055px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[16px] not-italic text-[16px] text-black top-[11.5px] whitespace-nowrap">La Chuleta Brava · 11,90€</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[994px] relative shrink-0 w-full" data-name="Container">
      <Container2 />
      <Container5 />
      <Container6 />
      <Container7 />
    </div>
  );
}

function Hero() {
  return (
    <div className="h-[1154px] relative shrink-0 w-full" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 990 1154\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -115.44 -115.44 0 693 230.8)\\'><stop stop-color=\\'rgba(255,184,0,0.15)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(128,92,0,0.075)\\' offset=\\'0.3\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0.6\\'/></radialGradient></defs></svg>')" }} data-name="Hero">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start pt-[80px] px-[48px] relative size-full">
          <Container1 />
        </div>
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[894px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[54px] left-[446.99px] not-italic text-[#fef6e9] text-[36px] text-center top-0 whitespace-nowrap">Lo que nos hace diferentes</p>
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[894px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[446.59px] not-italic text-[16px] text-[rgba(255,255,255,0.6)] text-center top-[-0.5px] whitespace-nowrap">Tres razones para que tu próximo bocado sea inolvidable.</p>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[90px] relative shrink-0 w-[894px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start relative size-full">
        <Heading1 />
        <Paragraph1 />
      </div>
    </div>
  );
}

function Image() {
  return (
    <div className="h-[67px] relative shrink-0 w-[48px]" data-name="Image">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage} />
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[28px] rounded-[16px] size-[48px] top-[28px]" data-name="Container">
      <Image />
    </div>
  );
}

function Heading2() {
  return (
    <div className="absolute h-[27px] left-[28px] top-[100px] w-[224px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#fef6e9] text-[18px] top-[0.5px] whitespace-nowrap">Accesibilidad Máxima</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="absolute h-[96px] left-[28px] top-[135px] w-[224px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-[-0.5px] w-[224px]">Puedes pedir cualquier hamburguesa en cualquier dispositivo, que nada te impida disfrutar de un buen bocado.</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute bg-[#141414] border border-[rgba(255,255,255,0.05)] border-solid h-[261px] left-0 rounded-[16px] top-0 w-[282px]" data-name="Container">
      <Container12 />
      <Heading2 />
      <Paragraph2 />
    </div>
  );
}

function Image1() {
  return (
    <div className="h-[67px] relative shrink-0 w-[48px]" data-name="Image">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage1} />
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute bg-[rgba(255,184,0,0.1)] content-stretch flex items-center justify-center left-[28px] rounded-[16px] size-[48px] top-[28px]" data-name="Container">
      <Image1 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="absolute h-[27px] left-[28px] top-[100px] w-[224px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#fef6e9] text-[18px] top-[0.5px] whitespace-nowrap">Producto de barrio</p>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="absolute h-[96px] left-[28px] top-[135px] w-[224px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-[-0.5px] w-[224px]">Carne de ganadero local, pan de horno de la esquina. Cocinamos como en casa, porque esto es casa.</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute bg-[#141414] border border-[rgba(255,255,255,0.05)] border-solid h-[261px] left-[306px] rounded-[16px] top-0 w-[282px]" data-name="Container">
      <Container14 />
      <Heading3 />
      <Paragraph3 />
    </div>
  );
}

function Image2() {
  return (
    <div className="h-[67px] relative shrink-0 w-[48px]" data-name="Image">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage2} />
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[28px] rounded-[16px] size-[48px] top-[28px]" data-name="Container">
      <Image2 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="absolute h-[27px] left-[28px] top-[100px] w-[224px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#fef6e9] text-[18px] top-[0.5px] whitespace-nowrap">En 30 minutos en tu mesa</p>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="absolute h-[96px] left-[28px] top-[135px] w-[224px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-[-0.5px] w-[224px]">Pides, encendemos la brasa y llega caliente. Como si la hubieras cocinado tú — pero mejor.</p>
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute bg-[#141414] border border-[rgba(255,255,255,0.05)] border-solid h-[261px] left-[612px] rounded-[16px] top-0 w-[282px]" data-name="Container">
      <Container16 />
      <Heading4 />
      <Paragraph4 />
    </div>
  );
}

function Container10() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[894px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container11 />
        <Container13 />
        <Container15 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="content-stretch flex flex-col gap-[56px] h-[407px] items-start relative shrink-0 w-full" data-name="Container">
      <Container9 />
      <Container10 />
    </div>
  );
}

function Features() {
  return (
    <div className="bg-[#0a0a0a] h-[569px] relative shrink-0 w-full" data-name="Features">
      <div aria-hidden="true" className="absolute border-[rgba(255,255,255,0.05)] border-b border-solid border-t inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start pb-px pt-[81px] px-[48px] relative size-full">
        <Container8 />
      </div>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[768px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Italic',sans-serif] font-normal italic leading-[0] left-[384px] text-[30px] text-[rgba(255,255,255,0.9)] text-center top-[-0.5px] w-[768px]">
          <span className="leading-[37.5px]">{`No servimos hamburguesas. Servimos la `}</span>
          <span className="leading-[37.5px] text-[#f5b301]">ambición de ser los mejores,</span>
          <span className="leading-[37.5px]">{` el fuego de la competición y el bocado épico que nos coronará `}</span>
          <span className="leading-[37.5px] text-[#f5b301]">campeones.</span>
        </p>
      </div>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[24px] relative shrink-0 w-[768px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[383.57px] not-italic text-[16px] text-[rgba(255,255,255,0.5)] text-center top-[-0.5px] whitespace-nowrap">— Jose y Yeray, fundadores</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] h-[160.5px] items-start relative shrink-0 w-full" data-name="Container">
      <Paragraph5 />
      <Paragraph6 />
    </div>
  );
}

function Quote() {
  return (
    <div className="h-[320.5px] relative shrink-0 w-full" data-name="Quote">
      <div className="content-stretch flex flex-col items-start pt-[80px] px-[111px] relative size-full">
        <Container17 />
      </div>
    </div>
  );
}

function Container19() {
  return <div className="absolute bg-[#f5b301] h-[352px] left-0 opacity-10 top-0 w-[894px]" data-name="Container" />;
}

function Heading5() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[615.273px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[72px] left-[308px] not-italic text-[48px] text-black text-center top-0 tracking-[-1.2px] whitespace-nowrap">¿Listo para encender la brasa?</p>
      </div>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[48px] relative shrink-0 w-[512px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[256px] not-italic text-[16px] text-[rgba(0,0,0,0.8)] text-center top-[-0.5px] w-[512px]">Tu hamburguesa favorita está a un clic. Hecha al momento, justo como te gusta.</p>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[123.91px] size-[16px] top-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1d405500} id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-black h-[56px] relative rounded-[10px] shrink-0 w-[171.906px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[74px] not-italic text-[#f5b301] text-[16px] text-center top-[15.5px] whitespace-nowrap">Pedir ahora</p>
        <Icon3 />
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[224px] items-center left-[64px] top-[64px] w-[766px]" data-name="Container">
      <Heading5 />
      <Paragraph7 />
      <Button2 />
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[352px] overflow-clip relative rounded-[24px] shrink-0 w-full" style={{ backgroundImage: "linear-gradient(171.845deg, rgb(255, 184, 0) 8.4861%, rgb(255, 138, 0) 91.514%)" }} data-name="Container">
      <Container19 />
      <Container20 />
    </div>
  );
}

function Cta() {
  return (
    <div className="h-[512px] relative shrink-0 w-full" data-name="CTA">
      <div className="content-stretch flex flex-col items-start pt-[80px] px-[48px] relative size-full">
        <Container18 />
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="h-[105px] relative shrink-0 w-full" data-name="Footer">
      <div aria-hidden="true" className="absolute border-[rgba(255,255,255,0.05)] border-solid border-t inset-0 pointer-events-none" />
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[495.7px] not-italic text-[16px] text-[rgba(255,255,255,0.4)] text-center top-[40.5px] whitespace-nowrap">© 2026 Remake Champions Burguer</p>
    </div>
  );
}

function App() {
  return (
    <div className="bg-[#0d0d0d] content-stretch flex flex-col h-[2757.5px] items-start relative shrink-0 w-full" data-name="App">
      <Navigation />
      <Hero />
      <Features />
      <Quote />
      <Cta />
      <Footer />
    </div>
  );
}

function Body() {
  return (
    <div className="content-stretch flex flex-col h-[732px] items-start relative shrink-0 w-[990px]" data-name="Body">
      <App />
    </div>
  );
}

export default function AddInteractiveHoverEffects() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="Add Interactive Hover Effects">
      <Body />
    </div>
  );
}