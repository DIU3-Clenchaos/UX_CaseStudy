import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Quote } from './components/Quote';
import { CTA } from './components/CTA';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="bg-[#0d0d0d] flex flex-col items-center justify-start min-h-screen w-full">
      <div className="w-full max-w-[990px] flex flex-col">
        <Navigation />
        <Hero />
        <Features />
        <Quote />
        <CTA />
        <Footer />
      </div>
    </div>
  );
}