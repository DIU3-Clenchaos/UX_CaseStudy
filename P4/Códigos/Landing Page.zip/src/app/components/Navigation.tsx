import imgImageLogo from "../../imports/AddInteractiveHoverEffects/888653ba5fdb58cd59db834a97c5d661a63e415d.png";

const FIGMA_MAKE_URL =
  "https://www.figma.com/make/umOBe1oAutbmwpfvyrIp1I/Carta?code-node-id=0-9&p=f&t=eW4M9VrePThuDfIt-0&fullscreen=1";
const COLAS_URL =
  "https://www.figma.com/make/eOqoBcdyeegwxTTnvB5Sg5/Colas?fullscreen=1&t=8A4EQYITI4F34HwG-1&code-node-id=0-9";
const RESERVAS_URL =
  "https://www.figma.com/make/dkRt8FTT9VZaSu6GxJGvSH/Reservas?code-node-id=0-9&p=f&t=ZIyEithylSH5a0jI-0&fullscreen=1";

function openUrl(url: string) {
  window.open(url, "_blank", "noopener,noreferrer");
}

function openFigmaMake() {
  openUrl(FIGMA_MAKE_URL);
}

function scrollToHistoria() {
  document
    .getElementById("historia")
    ?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export function Navigation() {
  return (
    <div
      className="bg-[rgba(13,13,13,0.7)] content-stretch flex flex-col h-[97px] items-start pb-px relative shrink-0 w-full"
      data-name="Navigation"
    >
      <div
        aria-hidden="true"
        className="absolute border-[rgba(255,255,255,0.05)] border-b border-solid inset-0 pointer-events-none"
      />
      <div className="h-[96px] relative shrink-0 w-full">
        <div className="flex flex-row items-center size-full">
          <div className="content-stretch flex items-center justify-between px-[32px] py-[16px] relative size-full">
            {/* Logo */}
            <div className="h-[64px] relative shrink-0 w-[279.609px]">
              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
                <div className="h-[64px] relative shrink-0 w-[59px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
                    <div className="h-[64px] relative shrink-0 w-full">
                      <img
                        alt=""
                        className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
                        src={imgImageLogo}
                      />
                    </div>
                  </div>
                </div>
                <div className="flex-[1_0_0] h-[24px] min-w-px relative">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#fef6e9] text-[16px] top-[-0.5px] tracking-[0.4px] whitespace-nowrap">
                      Remake Champions Burguer
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Menu */}
            <div className="h-[24px] relative shrink-0">
              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[32px] items-center relative size-full">
                <div
                  onClick={openFigmaMake}
                  className="h-[24px] relative shrink-0 cursor-pointer group"
                >
                  <p className="font-['Inter:Regular',sans-serif] font-normal leading-[21px] not-italic text-[14px] text-[rgba(255,255,255,0.7)] group-hover:text-[#f5b301] whitespace-nowrap transition-colors">
                    Carta
                  </p>
                  <div className="absolute bg-[#f5b301] h-[2px] left-0 -bottom-[2px] w-0 group-hover:w-full transition-all duration-300" />
                </div>
                <div
                  onClick={scrollToHistoria}
                  className="h-[24px] relative shrink-0 cursor-pointer group"
                >
                  <p className="font-['Inter:Regular',sans-serif] font-normal leading-[21px] not-italic text-[14px] text-[rgba(255,255,255,0.7)] group-hover:text-[#f5b301] whitespace-nowrap transition-colors">
                    Historia
                  </p>
                  <div className="absolute bg-[#f5b301] h-[2px] left-0 -bottom-[2px] w-0 group-hover:w-full transition-all duration-300" />
                </div>
                <div
                  onClick={() => openUrl(COLAS_URL)}
                  className="h-[24px] relative shrink-0 cursor-pointer group"
                >
                  <p className="font-['Inter:Regular',sans-serif] font-normal leading-[21px] not-italic text-[14px] text-[rgba(255,255,255,0.7)] group-hover:text-[#f5b301] whitespace-nowrap transition-colors">
                    Colas
                  </p>
                  <div className="absolute bg-[#f5b301] h-[2px] left-0 -bottom-[2px] w-0 group-hover:w-full transition-all duration-300" />
                </div>
                <div
                  onClick={() => openUrl(RESERVAS_URL)}
                  className="h-[24px] relative shrink-0 cursor-pointer group"
                >
                  <p className="font-['Inter:Regular',sans-serif] font-normal leading-[21px] not-italic text-[14px] text-[rgba(255,255,255,0.7)] group-hover:text-[#f5b301] whitespace-nowrap transition-colors">
                    Reservas
                  </p>
                  <div className="absolute bg-[#f5b301] h-[2px] left-0 -bottom-[2px] w-0 group-hover:w-full transition-all duration-300" />
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <div
              onClick={openFigmaMake}
              className="bg-[#f5b301] h-[40px] relative rounded-[10px] shrink-0 w-[115.906px] cursor-pointer hover:bg-[#ffb700] hover:scale-105 active:scale-95 transition-all duration-200"
            >
              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[16px] py-[8px] relative size-full">
                <p className="font-['Inter:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[16px] text-black text-center whitespace-nowrap">
                  Pedir ahora
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}