import svgPaths from "../../imports/AddInteractiveHoverEffects/svg-l1d2qarchk";
import imgImageBurger from "../../imports/AddInteractiveHoverEffects/30c8dc484b74a2a47fa60f5a06530486e9682ec3.png";

const FIGMA_MAKE_URL = "https://www.figma.com/make/umOBe1oAutbmwpfvyrIp1I/Hacer-p%C3%A1gina-funcional?p=f&t=GSaFQzvt0yUWfUMo-0";

function openFigmaMake() {
  window.open(FIGMA_MAKE_URL, "_blank", "noopener,noreferrer");
}

export function Hero() {
  return (
    <div className="h-[1154px] relative shrink-0 w-full" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 990 1154\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -115.44 -115.44 0 693 230.8)\\'><stop stop-color=\\'rgba(255,184,0,0.15)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(128,92,0,0.075)\\' offset=\\'0.3\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0.6\\'/></radialGradient></defs></svg>')" }} data-name="Hero">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start pt-[80px] px-[48px] relative size-full">
          <div className="h-[994px] relative shrink-0 w-full">
            {/* Text Content */}
            <div className="absolute content-stretch flex flex-col gap-[24px] h-[394px] items-start left-0 top-0 w-[894px]">
              {/* Badge */}
              <div className="bg-[rgba(255,184,0,0.1)] h-[26px] relative rounded-[16777200px] shrink-0 w-[177.133px]">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                  <div className="absolute left-[12px] size-[12px] top-[7px]">
                    <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
                      <g id="Icon">
                        <path d={svgPaths.p5a7a980} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" />
                      </g>
                    </svg>
                  </div>
                  <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[32px] not-italic text-[#f5b301] text-[12px] top-[4.5px] tracking-[1.2px] whitespace-nowrap">{` HECHAS A LA BRASA`}</p>
                </div>
              </div>

              {/* Heading */}
              <div className="flex-[1_0_0] min-h-px relative w-[894px]">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                  <div className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[0] left-0 not-italic text-[#fef6e9] text-[60px] top-[0.5px] tracking-[-1.5px] whitespace-nowrap">
                    <p className="leading-[63px] mb-0">Aqui, la competición,</p>
                    <p className="leading-[63px] text-[#f5b301]">se cocina.</p>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="h-[48px] relative shrink-0 w-[448px]">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                  <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#909395] text-[16px] top-[-0.5px] w-[448px]">Hamburguesas artesanas asadas sobre brasa de encina. Sin atajos, sin prisas — solo carne y fuego.</p>
                </div>
              </div>

              {/* Buttons */}
              <div className="h-[58px] relative shrink-0 w-[894px]">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                  <div onClick={openFigmaMake} className="absolute bg-[#f5b301] h-[50px] left-0 rounded-[10px] top-[8px] w-[235.328px] cursor-pointer hover:bg-[#ffb700] hover:scale-105 active:scale-95 transition-all duration-200 hover:shadow-[0px_10px_30px_rgba(255,184,0,0.4)]">
                    <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[106.5px] not-italic text-[16px] text-black text-center top-[12.5px] whitespace-nowrap">Pedir mi hamburguesa</p>
                    <div className="absolute left-[195.33px] size-[16px] top-[17px]">
                      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
                        <g id="Icon">
                          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                          <path d={svgPaths.p1d405500} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                        </g>
                      </svg>
                    </div>
                  </div>
                  <div onClick={openFigmaMake} className="absolute border border-[rgba(255,255,255,0.2)] border-solid h-[50px] left-[251.33px] rounded-[10px] top-[8px] w-[114.305px] cursor-pointer hover:border-[#f5b301] hover:bg-[rgba(245,179,1,0.1)] transition-all duration-200">
                    <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[24px] not-italic text-[#fef6e9] text-[16px] top-[11.5px] whitespace-nowrap">Ver carta</p>
                  </div>
                </div>
              </div>

              {/* Rating */}
              <div className="h-[40px] relative shrink-0 w-[894px]">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center pt-[16px] relative size-full">
                  <div className="h-[24px] relative shrink-0 w-[158.93px]">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                      <div className="absolute left-0 size-[14px] top-[5px]">
                        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                          <g id="Icon">
                            <path d={svgPaths.p6932200} fill="var(--fill-0, #F5B301)" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
                          </g>
                        </svg>
                      </div>
                      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[18px] not-italic text-[16px] text-[rgba(255,255,255,0.5)] top-[-0.5px] whitespace-nowrap">4.9 · +2.300 reseñas</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Burger Image */}
            <div className="absolute bg-[rgba(255,255,255,0)] h-[552px] left-0 rounded-[16px] top-[442px] w-[894px]">
              <div className="content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
                <div className="h-[550px] relative shrink-0 w-full">
                  <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageBurger} />
                </div>
              </div>
              <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_30px_80px_-20px_rgba(255,184,0,0.35)]" />
            </div>

            {/* Badge on image */}
            <div className="absolute bg-[#1a1a1a] border border-[rgba(255,255,255,0.1)] border-solid h-[36px] left-[680.75px] rounded-[16777200px] top-[425.49px] w-[181px]">
              <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[15.75px] not-italic text-[#fef6e9] text-[12px] top-[8.75px] whitespace-nowrap">🔥 Recién salida de la brasa</p>
            </div>

            {/* Price badge */}
            <div className="absolute bg-[#f5b301] drop-shadow-[0px_20px_20px_rgba(0,0,0,0.3)] h-[48px] left-[32px] rounded-[14px] top-[962px] w-[212.055px]">
              <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[16px] not-italic text-[16px] text-black top-[11.5px] whitespace-nowrap">La Chuleta Brava · 11,90€</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
