import svgPaths from "../../imports/AddInteractiveHoverEffects/svg-l1d2qarchk";

const FIGMA_MAKE_URL = "https://www.figma.com/make/umOBe1oAutbmwpfvyrIp1I/Hacer-p%C3%A1gina-funcional?p=f&t=GSaFQzvt0yUWfUMo-0";

function openFigmaMake() {
  window.open(FIGMA_MAKE_URL, "_blank", "noopener,noreferrer");
}

export function CTA() {
  return (
    <div className="h-[512px] relative shrink-0 w-full" data-name="CTA">
      <div className="content-stretch flex flex-col items-start pt-[80px] px-[48px] relative size-full">
        <div className="h-[352px] overflow-clip relative rounded-[24px] shrink-0 w-full" style={{ backgroundImage: "linear-gradient(171.845deg, rgb(255, 184, 0) 8.4861%, rgb(255, 138, 0) 91.514%)" }}>
          <div className="absolute bg-[#f5b301] h-[352px] left-0 opacity-10 top-0 w-[894px]" />
          <div className="absolute content-stretch flex flex-col gap-[24px] h-[224px] items-center left-[64px] top-[64px] w-[766px]">
            <div className="flex-[1_0_0] min-h-px relative w-[615.273px]">
              <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[72px] left-[308px] not-italic text-[48px] text-black text-center top-0 tracking-[-1.2px] whitespace-nowrap">¿Listo para encender la brasa?</p>
              </div>
            </div>
            <div className="h-[48px] relative shrink-0 w-[512px]">
              <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[256px] not-italic text-[16px] text-[rgba(0,0,0,0.8)] text-center top-[-0.5px] w-[512px]">Tu hamburguesa favorita está a un clic. Hecha al momento, justo como te gusta.</p>
              </div>
            </div>
            <div onClick={openFigmaMake} className="bg-black h-[56px] relative rounded-[10px] shrink-0 w-[171.906px] cursor-pointer hover:bg-[#1a1a1a] hover:scale-105 active:scale-95 transition-all duration-200 hover:shadow-[0px_10px_30px_rgba(0,0,0,0.5)]">
              <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[74px] not-italic text-[#f5b301] text-[16px] text-center top-[15.5px] whitespace-nowrap">Pedir ahora</p>
                <div className="absolute left-[123.91px] size-[16px] top-[20px]">
                  <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
                    <g id="Icon">
                      <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                      <path d={svgPaths.p1d405500} id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                    </g>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
