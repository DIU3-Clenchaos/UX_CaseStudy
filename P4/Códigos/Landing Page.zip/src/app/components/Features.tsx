import imgImage from "../../imports/AddInteractiveHoverEffects/e5038df173c3c73bae249cd8fd60ed2b7abfed81.png";
import imgImage1 from "../../imports/AddInteractiveHoverEffects/dfc418bc3ffb17e7aa87d42e888b0ec31d12976c.png";
import imgImage2 from "../../imports/AddInteractiveHoverEffects/967609dd24c3957c61397826b1692acdf1ef50b7.png";

export function Features() {
  return (
    <div className="bg-[#0a0a0a] h-[569px] relative shrink-0 w-full" data-name="Features">
      <div aria-hidden="true" className="absolute border-[rgba(255,255,255,0.05)] border-b border-solid border-t inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start pb-px pt-[81px] px-[48px] relative size-full">
        <div className="content-stretch flex flex-col gap-[56px] h-[407px] items-start relative shrink-0 w-full">
          {/* Header */}
          <div className="h-[90px] relative shrink-0 w-[894px]">
            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start relative size-full">
              <div className="flex-[1_0_0] min-h-px relative w-[894px]">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                  <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[54px] left-[446.99px] not-italic text-[#fef6e9] text-[36px] text-center top-0 whitespace-nowrap">Lo que nos hace diferentes</p>
                </div>
              </div>
              <div className="h-[24px] relative shrink-0 w-[894px]">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                  <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[446.59px] not-italic text-[16px] text-[rgba(255,255,255,0.6)] text-center top-[-0.5px] whitespace-nowrap">Tres razones para que tu próximo bocado sea inolvidable.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="flex-[1_0_0] min-h-px relative w-[894px]">
            <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
              {/* Card 1 */}
              <div className="absolute bg-[#141414] border border-[rgba(255,255,255,0.05)] border-solid h-[261px] left-0 rounded-[16px] top-0 w-[282px] hover:border-[rgba(255,255,255,0.15)] hover:bg-[#1a1a1a] transition-all duration-300 cursor-pointer group">
                <div className="absolute content-stretch flex items-center justify-center left-[28px] rounded-[16px] size-[48px] top-[28px]">
                  <div className="h-[67px] relative shrink-0 w-[48px]">
                    <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage} />
                  </div>
                </div>
                <div className="absolute h-[27px] left-[28px] top-[100px] w-[224px]">
                  <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#fef6e9] text-[18px] top-[0.5px] whitespace-nowrap">Accesibilidad Máxima</p>
                </div>
                <div className="absolute h-[96px] left-[28px] top-[135px] w-[224px]">
                  <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-[-0.5px] w-[224px]">Puedes pedir cualquier hamburguesa en cualquier dispositivo, que nada te impida disfrutar de un buen bocado.</p>
                </div>
              </div>

              {/* Card 2 */}
              <div className="absolute bg-[#141414] border border-[rgba(255,255,255,0.05)] border-solid h-[261px] left-[306px] rounded-[16px] top-0 w-[282px] hover:border-[rgba(245,179,1,0.3)] hover:bg-[#1a1a1a] transition-all duration-300 cursor-pointer group">
                <div className="absolute bg-[rgba(255,184,0,0.1)] content-stretch flex items-center justify-center left-[28px] rounded-[16px] size-[48px] top-[28px]">
                  <div className="h-[67px] relative shrink-0 w-[48px]">
                    <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage1} />
                  </div>
                </div>
                <div className="absolute h-[27px] left-[28px] top-[100px] w-[224px]">
                  <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#fef6e9] text-[18px] top-[0.5px] whitespace-nowrap">Producto de barrio</p>
                </div>
                <div className="absolute h-[96px] left-[28px] top-[135px] w-[224px]">
                  <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-[-0.5px] w-[224px]">Carne de ganadero local, pan de horno de la esquina. Cocinamos como en casa, porque esto es casa.</p>
                </div>
              </div>

              {/* Card 3 */}
              <div className="absolute bg-[#141414] border border-[rgba(255,255,255,0.05)] border-solid h-[261px] left-[612px] rounded-[16px] top-0 w-[282px] hover:border-[rgba(255,255,255,0.15)] hover:bg-[#1a1a1a] transition-all duration-300 cursor-pointer group">
                <div className="absolute content-stretch flex items-center justify-center left-[28px] rounded-[16px] size-[48px] top-[28px]">
                  <div className="h-[67px] relative shrink-0 w-[48px]">
                    <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage2} />
                  </div>
                </div>
                <div className="absolute h-[27px] left-[28px] top-[100px] w-[224px]">
                  <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#fef6e9] text-[18px] top-[0.5px] whitespace-nowrap">En 30 minutos en tu mesa</p>
                </div>
                <div className="absolute h-[96px] left-[28px] top-[135px] w-[224px]">
                  <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-[-0.5px] w-[224px]">Pides, encendemos la brasa y llega caliente. Como si la hubieras cocinado tú — pero mejor.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
