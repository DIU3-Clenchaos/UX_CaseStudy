export function Quote() {
  return (
    <div id="historia" className="h-[320.5px] relative shrink-0 w-full scroll-mt-[97px]" data-name="Quote">
      <div className="content-stretch flex flex-col items-start pt-[80px] px-[111px] relative size-full">
        <div className="content-stretch flex flex-col gap-[24px] h-[160.5px] items-start relative shrink-0 w-full">
          <div className="flex-[1_0_0] min-h-px relative w-[768px]">
            <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
              <p className="-translate-x-1/2 absolute font-['Inter:Italic',sans-serif] font-normal italic leading-[0] left-[384px] text-[30px] text-[rgba(255,255,255,0.9)] text-center top-[-0.5px] w-[768px]">
                <span className="leading-[37.5px]">{`No servimos hamburguesas. Servimos la `}</span>
                <span className="leading-[37.5px] text-[#f5b301]">ambición de ser los mejores,</span>
                <span className="leading-[37.5px]">{` el fuego de la competición y el bocado épico que nos coronará `}</span>
                <span className="leading-[37.5px] text-[#f5b301]">campeones.</span>
              </p>
            </div>
          </div>
          <div className="h-[24px] relative shrink-0 w-[768px]">
            <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
              <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[383.57px] not-italic text-[16px] text-[rgba(255,255,255,0.5)] text-center top-[-0.5px] whitespace-nowrap">— Jose y Yeray, fundadores</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
