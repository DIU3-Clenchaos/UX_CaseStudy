export function Footer() {
  return (
    <div className="h-[105px] relative shrink-0 w-full" data-name="Footer">
      <div aria-hidden="true" className="absolute border-[rgba(255,255,255,0.05)] border-solid border-t inset-0 pointer-events-none" />
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[495.7px] not-italic text-[16px] text-[rgba(255,255,255,0.4)] text-center top-[40.5px] whitespace-nowrap">© 2026 Remake Champions Burguer</p>
    </div>
  );
}
