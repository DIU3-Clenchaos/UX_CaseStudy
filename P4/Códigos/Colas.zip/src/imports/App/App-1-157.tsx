import svgPaths from "./svg-zfgviqbeiy";
import imgLogo from "./888653ba5fdb58cd59db834a97c5d661a63e415d.png";
import imgIconoUsuario from "./077754a9eee4bde057697980832f386eb4e819fb.png";

function Heading() {
  return (
    <div className="flex-[1_0_0] h-[36px] min-w-px relative" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[36px] left-0 not-italic text-[#f5b301] text-[24px] top-[-1px] whitespace-pre">{`Remake  Champions Burguer `}</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[48px] relative shrink-0 w-[447.453px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
        <div className="h-[82px] relative shrink-0 w-[75px]" data-name="Logo">
          <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgLogo} />
          </div>
        </div>
        <Heading />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#0b0e0f] content-stretch flex h-[142px] items-center justify-between pb-[17px] pt-[16px] px-[24px] relative shrink-0 w-[1551px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#282e30] border-b border-solid inset-0 pointer-events-none" />
      <Container />
      <div className="h-[64px] relative shrink-0 w-[61px]" data-name="Icono Usuario">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgIconoUsuario} />
        </div>
      </div>
    </div>
  );
}

function Container1() {
  return <div className="absolute h-[746px] left-0 top-0 w-[865px]" style={{ backgroundImage: "linear-gradient(rgba(255, 255, 255, 0.04) 0.13405%, rgba(0, 0, 0, 0) 0.13405%), linear-gradient(90deg, rgba(255, 255, 255, 0.04) 0.11561%, rgba(0, 0, 0, 0) 0.11561%)" }} data-name="Container" />;
}

function Icon() {
  return (
    <div className="absolute h-[746px] left-0 top-0 w-[865px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 865 746">
        <g clipPath="url(#clip0_1_184)" id="Icon">
          <path d={svgPaths.p9012f80} id="Vector" stroke="var(--stroke-0, #3A4143)" strokeWidth="6.4264" />
          <path d={svgPaths.pe808420} id="Vector_2" stroke="var(--stroke-0, #3A4143)" strokeWidth="6.4264" />
          <path d="M0 596.8L865 559.5" id="Vector_3" stroke="var(--stroke-0, #3A4143)" strokeWidth="4.8198" />
        </g>
        <defs>
          <clipPath id="clip0_1_184">
            <rect fill="white" height="746" width="865" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-0 not-italic text-[#f5b301] text-[13px] top-0 whitespace-nowrap">MAPA · 8 foodtrucks</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute bg-[rgba(27,31,33,0.8)] content-stretch flex flex-col h-[37.5px] items-start left-[16px] pb-px pt-[9px] px-[13px] rounded-[10px] top-[16px] w-[156.109px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Paragraph />
    </div>
  );
}

function Container4() {
  return (
    <div className="bg-[#f5b301] h-[27px] relative rounded-[8px] shrink-0 w-[95px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#f5b301] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[47.8px] not-italic text-[#1c1c1e] text-[11px] text-center top-[5.25px] whitespace-nowrap">Nolito’s</p>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #F5B301)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #F5B301)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch drop-shadow-[0px_0px_12px_#f5b301] flex flex-col gap-[3.75px] h-[63px] items-center relative shrink-0 w-full" data-name="Container">
      <Container4 />
      <Icon1 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute content-stretch flex flex-col h-[63px] items-start left-[142.8px] top-[161.05px] w-[95px]" data-name="Button">
      <Container3 />
    </div>
  );
}

function Container5() {
  return (
    <div className="bg-[#0b0e0f] h-[27px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[40.32px] not-italic text-[#e7e8e8] text-[11px] text-center top-[5.25px] whitespace-nowrap">Cheek’s</p>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #22C55E)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #22C55E)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.75px] h-[63px] items-center left-[435.75px] top-[101.36px] w-[80px]" data-name="Button">
      <Container5 />
      <Icon2 />
    </div>
  );
}

function Container6() {
  return (
    <div className="bg-[#0b0e0f] h-[27px] relative rounded-[8px] shrink-0 w-[89px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[45px] not-italic text-[#e7e8e8] text-[11px] text-center top-[4.45px] whitespace-nowrap">Vicbros Burguer</p>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #EF4444)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #EF4444)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.75px] h-[63px] items-center left-[565.5px] top-[347.55px] w-[80px]" data-name="Button">
      <Container6 />
      <Icon3 />
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-[#0b0e0f] h-[27px] relative rounded-[8px] shrink-0 w-[86px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[42.86px] not-italic text-[#e7e8e8] text-[11px] text-center top-[5.25px] whitespace-nowrap">Tokio</p>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #F5B301)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #F5B301)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.75px] h-[63px] items-center left-[259.75px] top-[422.14px] w-[86px]" data-name="Button">
      <Container7 />
      <Icon4 />
    </div>
  );
}

function Container8() {
  return (
    <div className="bg-[#0b0e0f] h-[27px] relative rounded-[8px] shrink-0 w-[91px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[46.39px] not-italic text-[#e7e8e8] text-[11px] text-center top-[5.25px] whitespace-nowrap">Gottan</p>
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #EF4444)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #EF4444)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.75px] h-[63px] items-center left-[646.5px] top-[175.97px] w-[91px]" data-name="Button">
      <Container8 />
      <Icon5 />
    </div>
  );
}

function Container9() {
  return (
    <div className="bg-[#0b0e0f] h-[27px] relative rounded-[8px] shrink-0 w-[100px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[50.73px] not-italic text-[#e7e8e8] text-[11px] text-center top-[5.25px] whitespace-nowrap">Street Food</p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #22C55E)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #22C55E)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.75px] h-[63px] items-center left-[105.69px] top-[459.44px] w-[100px]" data-name="Button">
      <Container9 />
      <Icon6 />
    </div>
  );
}

function Container10() {
  return (
    <div className="bg-[#0b0e0f] h-[27px] relative rounded-[8px] shrink-0 w-[88px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[43.93px] not-italic text-[#e7e8e8] text-[11px] text-center top-[5.25px] whitespace-nowrap">Jenkin’s</p>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #EF4444)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #EF4444)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.75px] h-[63px] items-center left-[475px] top-[519.13px] w-[88px]" data-name="Button">
      <Container10 />
      <Icon7 />
    </div>
  );
}

function Container11() {
  return (
    <div className="bg-[#0b0e0f] h-[27px] relative rounded-[8px] shrink-0 w-[74px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[36.87px] not-italic text-[#e7e8e8] text-[11px] text-center top-[5.25px] whitespace-nowrap">Godeo</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p3ae94df2} fill="var(--fill-0, #F5B301)" id="Vector" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p363c980} fill="var(--fill-0, #F5B301)" id="Vector_2" stroke="var(--stroke-0, #0B0E0F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.75px] h-[63px] items-center left-[352.25px] top-[272.94px] w-[74px]" data-name="Button">
      <Container11 />
      <Icon8 />
    </div>
  );
}

function Text() {
  return <div className="bg-[#22c55e] relative rounded-[33554400px] shrink-0 size-[10px]" data-name="Text" />;
}

function Text1() {
  return (
    <div className="flex-[1_0_0] h-[16.5px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#e7e8e8] text-[11px] top-0 whitespace-nowrap">Corta</p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[45.234px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Text />
        <Text1 />
      </div>
    </div>
  );
}

function Text2() {
  return <div className="bg-[#f5b301] relative rounded-[33554400px] shrink-0 size-[10px]" data-name="Text" />;
}

function Text3() {
  return (
    <div className="flex-[1_0_0] h-[16.5px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#e7e8e8] text-[11px] top-0 whitespace-nowrap">Media</p>
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="flex-[1_0_0] h-[16.5px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Text2 />
        <Text3 />
      </div>
    </div>
  );
}

function Text4() {
  return <div className="bg-[#ef4444] relative rounded-[33554400px] shrink-0 size-[10px]" data-name="Text" />;
}

function Text5() {
  return (
    <div className="flex-[1_0_0] h-[16.5px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#e7e8e8] text-[11px] top-0 whitespace-nowrap">Larga</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[45.203px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Text4 />
        <Text5 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute bg-[rgba(27,31,33,0.8)] content-stretch flex gap-[12px] h-[34.5px] items-start left-[16px] px-[13px] py-[9px] rounded-[10px] top-[695.5px] w-[188.266px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Container13 />
      <Container14 />
      <Container15 />
    </div>
  );
}

function Section() {
  return (
    <div className="absolute bg-[#282e30] border border-[#0b0e0f] border-solid h-[748px] left-[16px] overflow-clip rounded-[16px] top-[203px] w-[867px]" data-name="Section">
      <Container1 />
      <Icon />
      <Container2 />
      <Button />
      <Button1 />
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
      <Button6 />
      <Button7 />
      <Container12 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[18px] relative shrink-0 w-[298px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#f5b301] text-[12px] top-0 tracking-[1px] whitespace-nowrap">FOODTRUCK SELECCIONADO</p>
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[64px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 64 64">
        <g id="Icon">
          <path d={svgPaths.p20016380} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
          <path d={svgPaths.p2fa4b080} id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
          <path d="M5.6 58.1333L22.6667 41.3333" id="Vector_3" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
          <path d="M50.6667 13.3333L32 32" id="Vector_4" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[223.5px] relative rounded-[14px] shrink-0 w-[298px]" style={{ backgroundImage: "linear-gradient(143.13deg, rgb(58, 65, 67) 0%, rgb(55, 62, 64) 8.3333%, rgb(53, 59, 61) 16.667%, rgb(50, 56, 58) 25%, rgb(47, 53, 55) 33.333%, rgb(45, 50, 52) 41.667%, rgb(42, 48, 50) 50%, rgb(39, 45, 47) 58.333%, rgb(37, 42, 44) 66.667%, rgb(34, 39, 41) 75%, rgb(32, 36, 38) 83.333%, rgb(29, 34, 36) 91.667%, rgb(27, 31, 33) 100%)" }} data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[117px] py-px relative size-full">
        <Icon9 />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[33px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[33px] left-0 not-italic text-[22px] text-white top-0 whitespace-nowrap">Guifer</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[#9ca0a2] text-[13px] top-0 whitespace-nowrap">Hamburguesas · ★ 4.6</p>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[52.5px] relative shrink-0 w-[298px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Heading1 />
        <Paragraph2 />
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_1_166)" id="Icon">
          <path d={svgPaths.p39ee6532} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 4V8L10.6667 9.33333" id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_1_166">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[18px] relative shrink-0 w-[100.953px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#9ca0a2] text-[12px] top-0 whitespace-nowrap">COLA ESTIMADA</p>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="content-stretch flex gap-[8px] h-[18px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon10 />
      <Text6 />
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[35.828px]" data-name="Text">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[48px] left-0 not-italic text-[32px] text-white top-[-1px] whitespace-nowrap">12</p>
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute h-[21px] left-[43.83px] top-[19px] w-[23.688px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#9ca0a2] text-[14px] top-0 whitespace-nowrap">min</p>
    </div>
  );
}

function Text9() {
  return (
    <div className="absolute bg-[#f5b301] h-[20.5px] left-[215px] rounded-[33554400px] top-[21px] w-[49px]" data-name="Text">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[16.5px] left-[8px] not-italic text-[#1c1c1e] text-[11px] top-[2px] whitespace-nowrap">Media</p>
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
      <Text7 />
      <Text8 />
      <Text9 />
    </div>
  );
}

function Container18() {
  return (
    <div className="bg-[#0b0e0f] h-[108px] relative rounded-[14px] shrink-0 w-[298px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] items-start pb-px pt-[17px] px-[17px] relative size-full">
        <Container19 />
        <Container20 />
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-[#f5b301] h-[45px] relative rounded-[10px] shrink-0 w-[298px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[21px] left-[149.31px] not-italic text-[#1c1c1e] text-[14px] text-center top-[12px] whitespace-nowrap">Confirmar</p>
      </div>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-[#282e30] content-stretch flex flex-col gap-[16px] h-[748px] items-start left-[899px] p-[21px] rounded-[16px] top-[203px] w-[340px]" data-name="Sidebar">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Paragraph1 />
      <Container16 />
      <Container17 />
      <Container18 />
      <Button8 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="absolute h-[18px] left-[20px] top-[20px] w-[238px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#f5b301] text-[12px] top-0 tracking-[1px] whitespace-nowrap">FILTROS</p>
    </div>
  );
}

function TextInput() {
  return (
    <div className="absolute bg-[#0b0e0f] h-[41.5px] left-0 rounded-[10px] top-0 w-[238px]" data-name="Text Input">
      <div className="content-stretch flex items-center overflow-clip pl-[36px] pr-[12px] py-[10px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#666] text-[13px] whitespace-nowrap">Buscar foodtruck...</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Icon11() {
  return (
    <div className="absolute left-[12px] size-[16px] top-[12.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p107a080} id="Vector" stroke="var(--stroke-0, #9CA0A2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14 14L11.1333 11.1333" id="Vector_2" stroke="var(--stroke-0, #9CA0A2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute h-[41.5px] left-[20px] top-[58px] w-[238px]" data-name="Container">
      <TextInput />
      <Icon11 />
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#9ca0a2] text-[12px] top-0 whitespace-nowrap">TIPO DE COMIDA</p>
    </div>
  );
}

function Button9() {
  return (
    <div className="bg-[#f5b301] h-[37.5px] relative rounded-[10px] shrink-0 w-[238px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#f5b301] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-[13px] not-italic text-[#1c1c1e] text-[13px] top-[9px] whitespace-nowrap">Todas</p>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="bg-[#0b0e0f] h-[37.5px] relative rounded-[10px] shrink-0 w-[238px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[13px] not-italic text-[#e7e8e8] text-[13px] top-[9px] whitespace-nowrap">Hamburguesas</p>
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="bg-[#0b0e0f] h-[37.5px] relative rounded-[10px] shrink-0 w-[238px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[13px] not-italic text-[#e7e8e8] text-[13px] top-[9px] whitespace-nowrap">Vegetariana</p>
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-[#0b0e0f] h-[37.5px] relative rounded-[10px] shrink-0 w-[238px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#0b0e0f] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[13px] not-italic text-[#e7e8e8] text-[13px] top-[9px] whitespace-nowrap">Sin Gluten</p>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[265px] items-start relative shrink-0 w-full" data-name="Container">
      <Button9 />
      <Button10 />
      <Button11 />
      <Button12 />
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[291px] items-start left-[20px] top-[119.5px] w-[238px]" data-name="Container">
      <Paragraph4 />
      <Container23 />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[18px] relative shrink-0 w-[69.297px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#9ca0a2] text-[12px] top-0 whitespace-nowrap">COLA MÁX.</p>
      </div>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[18px] relative shrink-0 w-[40.625px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#f5b301] text-[12px] top-0 whitespace-nowrap">30 min</p>
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="content-stretch flex h-[18px] items-start justify-between relative shrink-0 w-full" data-name="Container">
      <Paragraph5 />
      <Paragraph6 />
    </div>
  );
}

function RangeSlider() {
  return <div className="h-[16px] relative shrink-0 w-full" data-name="Range Slider" />;
}

function Container24() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] h-[50px] items-start left-[20px] top-[430.5px] w-[238px]" data-name="Container">
      <Container25 />
      <RangeSlider />
    </div>
  );
}

function Button13() {
  return (
    <div className="absolute border border-[#0b0e0f] border-solid h-[41.5px] left-[20px] rounded-[10px] top-[684.5px] w-[238px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] left-[118.11px] not-italic text-[#e7e8e8] text-[13px] text-center top-[10px] whitespace-nowrap">Reiniciar filtros</p>
    </div>
  );
}

function Sidebar1() {
  return (
    <div className="absolute bg-[#282e30] border border-[#0b0e0f] border-solid h-[748px] left-[1255px] rounded-[16px] top-[203px] w-[280px]" data-name="Sidebar">
      <Paragraph3 />
      <Container21 />
      <Container22 />
      <Container24 />
      <Button13 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="flex-[780_0_0] min-h-px relative w-[1551px]" data-name="Main Content">
      <Section />
      <Sidebar />
      <Sidebar1 />
    </div>
  );
}

export default function App() {
  return (
    <div className="bg-[#0b0e0f] content-stretch flex flex-col items-start relative size-full" data-name="App">
      <Header />
      <MainContent />
    </div>
  );
}