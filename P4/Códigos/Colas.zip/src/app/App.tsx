import { Header } from './components/Header';
import { FiltersSidebar } from './components/FiltersSidebar';
import { MapView } from './components/MapView';
import { TruckDetails } from './components/TruckDetails';
import { useFoodTruckFilters } from './components/useFoodTruckFilters';

export default function App() {
  const filters = useFoodTruckFilters();

  return (
    <div className="bg-[#0b0e0f] flex flex-col items-start relative size-full">
      <Header />
      <div className="flex-[780_0_0] min-h-px relative w-full flex justify-center gap-4 px-4">
        <FiltersSidebar {...filters} onReset={filters.resetFilters} />
        <MapView
          trucks={filters.filteredTrucks}
          selectedTruck={filters.selectedTruck}
          onSelectTruck={filters.setSelectedTruck}
        />
        <TruckDetails truck={filters.selectedTruck} />
      </div>
    </div>
  );
}
