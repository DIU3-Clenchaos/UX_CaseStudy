import svgPaths from "../../imports/App/svg-zfgviqbeiy";
import { FoodTruck, getStatusText } from "./types";

interface Props {
  truck: FoodTruck;
}

export function TruckDetails({ truck }: Props) {
  return (
    <div className="bg-[#282e30] flex flex-col gap-[16px] h-[748px] mt-[61px] p-[21px] rounded-[16px] w-[340px] border border-[#0b0e0f]">
      <p className="font-['Inter:Bold',sans-serif] font-bold leading-[18px] text-[#f5b301] text-[12px] tracking-[1px]">FOODTRUCK SELECCIONADO</p>

      <div className="h-[223.5px] rounded-[14px] border border-[#0b0e0f] flex items-center justify-center" style={{ backgroundImage: "linear-gradient(143.13deg, rgb(58, 65, 67) 0%, rgb(27, 31, 33) 100%)" }}>
        <svg className="size-[64px]" fill="none" viewBox="0 0 64 64">
          <path d={svgPaths.p20016380} stroke="#F5B301" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
          <path d={svgPaths.p2fa4b080} stroke="#F5B301" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
          <path d="M5.6 58.1333L22.6667 41.3333" stroke="#F5B301" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
          <path d="M50.6667 13.3333L32 32" stroke="#F5B301" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5.33333" />
        </svg>
      </div>

      <div>
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[33px] text-white text-[22px]">{truck.name}</p>
        <p className="font-['Inter:Regular',sans-serif] leading-[19.5px] text-[#9ca0a2] text-[13px]">{truck.category} · ★ {truck.rating}</p>
      </div>

      <div className="bg-[#0b0e0f] rounded-[14px] p-[17px] border border-[#0b0e0f]">
        <div className="flex gap-[8px] items-center mb-2">
          <svg className="size-[16px]" fill="none" viewBox="0 0 16 16">
            <path d={svgPaths.p39ee6532} stroke="#F5B301" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d="M8 4V8L10.6667 9.33333" stroke="#F5B301" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
          <p className="font-['Inter:Bold',sans-serif] font-bold text-[#9ca0a2] text-[12px]">COLA ESTIMADA</p>
        </div>
        <div className="relative">
          <p className="font-['Inter:Bold',sans-serif] font-bold leading-[48px] text-white text-[32px]">{truck.waitTime}</p>
          <p className="absolute left-[44px] top-[19px] font-['Inter:Regular',sans-serif] text-[#9ca0a2] text-[14px]">min</p>
          <div className="absolute right-0 top-[21px] bg-[#f5b301] rounded-full px-2 py-0.5">
            <p className="font-['Inter:Bold',sans-serif] font-bold text-[#1c1c1e] text-[11px]">{getStatusText(truck.waitTime)}</p>
          </div>
        </div>
      </div>

      <button className="bg-[#f5b301] h-[45px] rounded-[10px] font-['Inter:Bold',sans-serif] font-bold text-[#1c1c1e] text-[14px] hover:bg-[#d69f01] transition-colors">
        Confirmar
      </button>
    </div>
  );
}
