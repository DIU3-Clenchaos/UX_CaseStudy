import { useState, useMemo } from 'react';
import { foodTrucks, FoodTruck } from './types';

export function useFoodTruckFilters() {
  const [selectedTruck, setSelectedTruck] = useState<FoodTruck>(foodTrucks[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [maxWaitTime, setMaxWaitTime] = useState(30);

  const filteredTrucks = useMemo(
    () =>
      foodTrucks.filter((truck) => {
        const matchesSearch = truck.name.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesCategory = selectedCategory === 'Todas' || truck.category === selectedCategory;
        const matchesWaitTime = truck.waitTime <= maxWaitTime;
        return matchesSearch && matchesCategory && matchesWaitTime;
      }),
    [searchQuery, selectedCategory, maxWaitTime]
  );

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('Todas');
    setMaxWaitTime(30);
  };

  return {
    selectedTruck,
    setSelectedTruck,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    maxWaitTime,
    setMaxWaitTime,
    filteredTrucks,
    resetFilters,
  };
}
