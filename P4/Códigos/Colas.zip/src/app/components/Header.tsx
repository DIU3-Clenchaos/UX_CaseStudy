import imgLogo from "../../imports/App/888653ba5fdb58cd59db834a97c5d661a63e415d.png";
import imgIconoUsuario from "../../imports/App/077754a9eee4bde057697980832f386eb4e819fb.png";

export function Header() {
  return (
    <div className="bg-[#0b0e0f] content-stretch flex h-[142px] items-center justify-between pb-[17px] pt-[16px] px-[24px] relative shrink-0 w-full" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#282e30] border-b border-solid inset-0 pointer-events-none" />
      <div className="h-[48px] relative shrink-0 w-[447.453px]">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
          <a
            href="https://www.figma.com/make/qb3R4W4QMBYFErtPn7tJvK/Landing-Page?code-node-id=0-9&p=f&t=QR1GaE4ohgzf0xLO-0&fullscreen=1"
            target="_blank"
            rel="noopener noreferrer"
            className="h-[82px] relative shrink-0 w-[75px] cursor-pointer hover:opacity-80 transition-opacity"
          >
            <img alt="Logo" className="absolute inset-0 max-w-none object-cover size-full" src={imgLogo} />
          </a>
          <div className="flex-[1_0_0] h-[36px] min-w-px relative">
            <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[36px] left-0 not-italic text-[#f5b301] text-[24px] top-[-1px] whitespace-pre">Remake Champions Burguer</p>
          </div>
        </div>
      </div>
      <div className="h-[64px] relative shrink-0 w-[61px]">
        <img alt="Usuario" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgIconoUsuario} />
      </div>
    </div>
  );
}
