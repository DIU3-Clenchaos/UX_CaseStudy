import svgPaths from "../../imports/App/svg-zfgviqbeiy";
import { categories } from "./types";

interface Props {
  searchQuery: string;
  setSearchQuery: (v: string) => void;
  selectedCategory: string;
  setSelectedCategory: (v: string) => void;
  maxWaitTime: number;
  setMaxWaitTime: (v: number) => void;
  onReset: () => void;
}

export function FiltersSidebar({ searchQuery, setSearchQuery, selectedCategory, setSelectedCategory, maxWaitTime, setMaxWaitTime, onReset }: Props) {
  return (
    <div className="bg-[#282e30] border border-[#0b0e0f] border-solid h-[748px] rounded-[16px] mt-[61px] w-[280px] p-5">
      <p className="font-['Inter:Bold',sans-serif] font-bold leading-[18px] text-[#f5b301] text-[12px] tracking-[1px] mb-5">FILTROS</p>

      <div className="relative mb-6">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar foodtruck..."
          className="bg-[#0b0e0f] h-[41.5px] w-full rounded-[10px] pl-[36px] pr-[12px] py-[10px] font-['Inter:Regular',sans-serif] text-[13px] text-white border border-[#0b0e0f] focus:outline-none focus:border-[#f5b301]"
        />
        <svg className="absolute left-[12px] top-[12.75px] size-[16px]" fill="none" viewBox="0 0 16 16">
          <path d={svgPaths.p107a080} stroke="#9CA0A2" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14 14L11.1333 11.1333" stroke="#9CA0A2" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </svg>
      </div>

      <div className="mb-6">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[18px] text-[#9ca0a2] text-[12px] mb-2">TIPO DE COMIDA</p>
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`w-full h-[37.5px] rounded-[10px] mb-2 text-left px-[13px] transition-colors ${
              selectedCategory === category
                ? 'bg-[#f5b301] text-[#1c1c1e] font-bold'
                : 'bg-[#0b0e0f] text-[#e7e8e8] font-medium border border-[#0b0e0f]'
            } font-['Inter'] text-[13px]`}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <p className="font-['Inter:Bold',sans-serif] font-bold leading-[18px] text-[#9ca0a2] text-[12px]">COLA MÁX.</p>
          <p className="font-['Inter:Bold',sans-serif] font-bold leading-[18px] text-[#f5b301] text-[12px]">{maxWaitTime} min</p>
        </div>
        <input
          type="range"
          min="5"
          max="30"
          value={maxWaitTime}
          onChange={(e) => setMaxWaitTime(Number(e.target.value))}
          className="w-full h-2 bg-[#0b0e0f] rounded-lg appearance-none cursor-pointer accent-[#f5b301]"
        />
      </div>

      <button
        onClick={onReset}
        className="w-full h-[41.5px] border border-[#0b0e0f] rounded-[10px] text-[#e7e8e8] font-['Inter:Bold',sans-serif] font-bold text-[13px] hover:border-[#f5b301] transition-colors"
      >
        Reiniciar filtros
      </button>
    </div>
  );
}
