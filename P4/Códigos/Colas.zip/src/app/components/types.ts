export interface FoodTruck {
  id: number;
  name: string;
  category: string;
  rating: number;
  waitTime: number;
  position: { left: string; top: string };
  status: 'short' | 'medium' | 'long';
}

export const foodTrucks: FoodTruck[] = [
  { id: 1, name: "Nolito's", category: 'Hamburguesas', rating: 4.6, waitTime: 12, position: { left: '142.8px', top: '161.05px' }, status: 'medium' },
  { id: 2, name: "Cheek's", category: 'Hamburguesas', rating: 4.8, waitTime: 8, position: { left: '435.75px', top: '101.36px' }, status: 'short' },
  { id: 3, name: "Vicbros Burguer", category: 'Hamburguesas', rating: 4.3, waitTime: 25, position: { left: '565.5px', top: '347.55px' }, status: 'long' },
  { id: 4, name: "Tokio", category: 'Vegetariana', rating: 4.7, waitTime: 15, position: { left: '259.75px', top: '422.14px' }, status: 'medium' },
  { id: 5, name: "Gottan", category: 'Sin Gluten', rating: 4.1, waitTime: 30, position: { left: '646.5px', top: '175.97px' }, status: 'long' },
  { id: 6, name: "Street Food", category: 'Todas', rating: 4.5, waitTime: 10, position: { left: '105.69px', top: '459.44px' }, status: 'short' },
  { id: 7, name: "Jenkin's", category: 'Hamburguesas', rating: 4.2, waitTime: 28, position: { left: '475px', top: '519.13px' }, status: 'long' },
  { id: 8, name: "Godeo", category: 'Vegetariana', rating: 4.9, waitTime: 14, position: { left: '352.25px', top: '272.94px' }, status: 'medium' },
];

export const categories = ['Todas', 'Hamburguesas', 'Vegetariana', 'Sin Gluten'];

export const getStatusColor = (status: string) => {
  if (status === 'short') return '#22C55E';
  if (status === 'medium') return '#F5B301';
  return '#EF4444';
};

export const getStatusText = (waitTime: number) => {
  if (waitTime <= 10) return 'Corta';
  if (waitTime <= 20) return 'Media';
  return 'Larga';
};
