import svgPaths from "../../imports/App/svg-zfgviqbeiy";
import { FoodTruck, getStatusColor } from "./types";

interface Props {
  trucks: FoodTruck[];
  selectedTruck: FoodTruck;
  onSelectTruck: (t: FoodTruck) => void;
}

export function MapView({ trucks, selectedTruck, onSelectTruck }: Props) {
  return (
    <div className="bg-[#282e30] border border-[#0b0e0f] border-solid h-[748px] mt-[61px] overflow-clip rounded-[16px] w-[867px] relative">
      <div className="absolute h-full w-full" style={{ backgroundImage: "linear-gradient(rgba(255, 255, 255, 0.04) 0.13405%, rgba(0, 0, 0, 0) 0.13405%), linear-gradient(90deg, rgba(255, 255, 255, 0.04) 0.11561%, rgba(0, 0, 0, 0) 0.11561%)" }} />
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 865 746">
        <g clipPath="url(#clip0_1_184)">
          <path d={svgPaths.p9012f80} stroke="#3A4143" strokeWidth="6.4264" />
          <path d={svgPaths.pe808420} stroke="#3A4143" strokeWidth="6.4264" />
          <path d="M0 596.8L865 559.5" stroke="#3A4143" strokeWidth="4.8198" />
        </g>
        <defs>
          <clipPath id="clip0_1_184">
            <rect fill="white" height="746" width="865" />
          </clipPath>
        </defs>
      </svg>

      <div className="absolute bg-[rgba(27,31,33,0.8)] flex h-[37.5px] left-[16px] rounded-[10px] top-[16px] border border-[#0b0e0f] px-[13px] py-[9px]">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[19.5px] text-[#f5b301] text-[13px]">MAPA · {trucks.length} foodtrucks</p>
      </div>

      {trucks.map((truck) => (
        <button
          key={truck.id}
          onClick={() => onSelectTruck(truck)}
          className={`absolute flex flex-col gap-[3.75px] items-center transition-transform hover:scale-110 ${
            selectedTruck.id === truck.id ? 'drop-shadow-[0px_0px_12px_#f5b301]' : ''
          }`}
          style={{ left: truck.position.left, top: truck.position.top }}
        >
          <div className={`${selectedTruck.id === truck.id ? 'bg-[#f5b301] text-[#1c1c1e] border-[#f5b301]' : 'bg-[#0b0e0f] text-[#e7e8e8] border-[#0b0e0f]'} h-[27px] px-3 rounded-[8px] border flex items-center justify-center`}>
            <p className="font-['Inter:Bold',sans-serif] font-bold text-[11px] whitespace-nowrap">{truck.name}</p>
          </div>
          <svg className="size-[32px]" fill="none" viewBox="0 0 32 32">
            <path d={svgPaths.p3ae94df2} fill={getStatusColor(truck.status)} stroke="#0B0E0F" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            <path d={svgPaths.p363c980} fill={getStatusColor(truck.status)} stroke="#0B0E0F" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </button>
      ))}

      <div className="absolute bg-[rgba(27,31,33,0.8)] flex gap-[12px] left-[16px] px-[13px] py-[9px] rounded-[10px] top-[695.5px] border border-[#0b0e0f]">
        <div className="flex gap-[6px] items-center">
          <div className="bg-[#22c55e] rounded-full size-[10px]" />
          <p className="font-['Inter:Regular',sans-serif] text-[#e7e8e8] text-[11px]">Corta</p>
        </div>
        <div className="flex gap-[6px] items-center">
          <div className="bg-[#f5b301] rounded-full size-[10px]" />
          <p className="font-['Inter:Regular',sans-serif] text-[#e7e8e8] text-[11px]">Media</p>
        </div>
        <div className="flex gap-[6px] items-center">
          <div className="bg-[#ef4444] rounded-full size-[10px]" />
          <p className="font-['Inter:Regular',sans-serif] text-[#e7e8e8] text-[11px]">Larga</p>
        </div>
      </div>
    </div>
  );
}
