
  # Colas

  This is a code bundle for Colas. The original project is available at https://www.figma.com/design/eOqoBcdyeegwxTTnvB5Sg5/Colas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  