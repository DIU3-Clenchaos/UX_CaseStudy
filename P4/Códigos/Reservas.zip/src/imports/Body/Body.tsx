import svgPaths from "./svg-0kig29jn64";
import imgImageLogo from "./888653ba5fdb58cd59db834a97c5d661a63e415d.png";
import imgImageCarrito from "./1df74ef80319357164713832750b9a766a816b46.png";
import imgImageUsuario from "./077754a9eee4bde057697980832f386eb4e819fb.png";

function ImageLogo() {
  return (
    <div className="h-[44px] relative shrink-0 w-[40px]" data-name="Image (Logo)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageLogo} />
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-[14px] shadow-[0px_10px_15px_0px_rgba(254,154,0,0.2),0px_4px_6px_0px_rgba(254,154,0,0.2)] shrink-0 size-[44px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[2px] relative size-full">
        <ImageLogo />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-[115.305px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[22px] min-w-px not-italic relative text-[#f5b301] text-[18px]">Remake</p>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[16px] relative shrink-0 w-[115.305px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#b4b6b7] text-[13px] whitespace-nowrap">Champions Burguer</p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="flex-[1_0_0] h-[38px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Text />
        <Text1 />
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[44px] relative shrink-0 w-[171.305px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container2 />
        <Container3 />
      </div>
    </div>
  );
}

function Container4() {
  return <div className="flex-[646.695_0_0] h-0 min-w-px relative" data-name="Container" />;
}

function ImageCarrito() {
  return (
    <div className="h-[26px] relative shrink-0 w-[20px]" data-name="Image (Carrito)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageCarrito} />
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#131718] relative rounded-[14px] shrink-0 size-[40px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[10px] relative size-full">
        <ImageCarrito />
      </div>
    </div>
  );
}

function ImageUsuario() {
  return (
    <div className="h-[28px] relative shrink-0 w-[26px]" data-name="Image (Usuario)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageUsuario} />
    </div>
  );
}

function Button1() {
  return (
    <div className="flex-[1_0_0] h-[40px] min-w-px relative rounded-[14px]" data-name="Button">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[7px] relative size-full">
          <ImageUsuario />
        </div>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[40px] relative shrink-0 w-[92px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Button />
        <Button1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[77px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] relative size-full">
          <Container1 />
          <Container4 />
          <Container5 />
        </div>
      </div>
    </div>
  );
}

function SeatMapHeader() {
  return (
    <div className="absolute bg-[rgba(9,9,11,0.9)] content-stretch flex flex-col h-[78px] items-start left-0 pb-px top-0 w-[990px]" data-name="SeatMapHeader">
      <div aria-hidden="true" className="absolute border-[#27272a] border-b border-solid inset-0 pointer-events-none" />
      <Container />
    </div>
  );
}

function Text2() {
  return (
    <div className="absolute h-[18px] left-[12px] top-[4px] w-[188.664px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#f5b301] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">RESERVA · TEMPORADA 2026</p>
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.2)] h-[26px] left-[24px] rounded-[16777200px] top-[110.5px] w-[212.664px]" data-name="Container">
      <Text2 />
    </div>
  );
}

function Heading() {
  return (
    <div className="absolute content-stretch flex h-[37px] items-start left-[24px] top-[148.5px] w-[942px]" data-name="Heading 1">
      <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[0] min-w-px not-italic relative text-[#f2e4e0] text-[28px]">
        <span className="leading-[34px]">{`Elige tu mesa en el `}</span>
        <span className="leading-[34px] text-[#f5b301]">plano interactivo</span>
        <span className="leading-[34px]">.</span>
      </p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="absolute h-[45px] left-[24px] top-[193.5px] w-[640px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.5px] left-0 not-italic text-[#909395] text-[15px] top-[-1px] w-[640px]">Explora el local, selecciona los asientos que más te gusten y filtra por zona, comensales o precio. Confirma tu reserva en un par de clics.</p>
    </div>
  );
}

function Container8() {
  return <div className="absolute h-[558px] left-0 opacity-18 top-0 w-[940px]" style={{ backgroundImage: "linear-gradient(rgba(245, 179, 1, 0.25) 0.17921%, rgba(0, 0, 0, 0) 0.17921%), linear-gradient(90deg, rgba(245, 179, 1, 0.25) 0.10638%, rgba(0, 0, 0, 0) 0.10638%)" }} data-name="Container" />;
}

function Container9() {
  return <div className="absolute border border-[#27272a] border-dashed h-[156px] left-[74.99px] rounded-[20px] top-[100.55px] w-[414px]" data-name="Container" />;
}

function Container10() {
  return <div className="absolute border border-[#27272a] border-dashed h-[156px] left-[507.59px] rounded-[20px] top-[100.55px] w-[376px]" data-name="Container" />;
}

function Container11() {
  return <div className="absolute border border-[#27272a] border-dashed h-[100px] left-[131.59px] rounded-[40px] top-[323.85px] w-[376px]" data-name="Container" />;
}

function Container12() {
  return <div className="absolute border border-[rgba(245,179,1,0.3)] border-dashed h-[145px] left-[563.8px] rounded-[20px] top-[334.84px] w-[320px]" data-name="Container" />;
}

function Container13() {
  return (
    <div className="absolute h-[17px] left-[93.86px] top-[108.55px] w-[58px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[0.14px] not-italic text-[#f5b301] text-[11px] top-px tracking-[1.5px] whitespace-nowrap">TERRAZA</p>
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute h-[17px] left-[526.42px] top-[108.55px] w-[60px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[-0.02px] not-italic text-[#f5b301] text-[11px] top-px tracking-[1.5px] whitespace-nowrap">INTERIOR</p>
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute h-[17px] left-[150.3px] top-[331.76px] w-[43px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[0.09px] not-italic text-[#f5b301] text-[11px] top-px tracking-[1.5px] whitespace-nowrap">BARRA</p>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute h-[17px] left-[582.74px] top-[342.91px] w-[21px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-[0.06px] not-italic text-[#f5b301] text-[11px] top-px tracking-[1.5px] whitespace-nowrap">VIP</p>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.7px] not-italic text-[#e6e6e6] text-[12px] text-center top-[0.25px] whitespace-nowrap">Mesa 1</p>
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.3px] not-italic text-[#e6e6e6] text-[10px] text-center top-[0.5px] whitespace-nowrap">2 pax · 18€</p>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-[#1b1f21] content-stretch flex flex-col h-[46px] items-start left-[114.4px] pt-[8px] px-[12px] rounded-[14px] top-[133.23px] w-[72px]" data-name="Button">
      <Container17 />
      <Container18 />
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.7px] not-italic text-[#0b0e0f] text-[12px] text-center top-[0.25px] whitespace-nowrap">Mesa 2</p>
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.8px] not-italic text-[#0b0e0f] text-[10px] text-center top-[0.5px] whitespace-nowrap">4 pax · 28€</p>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[#f5b301] content-stretch drop-shadow-[0px_0px_0px_rgba(245,179,1,0.6),0px_8px_9px_rgba(245,179,1,0.45)] flex flex-col h-[46px] items-start left-[246px] pt-[8px] px-[12px] rounded-[14px] top-[155.55px] w-[72px]" data-name="Button">
      <Container19 />
      <Container20 />
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.7px] not-italic text-[#ff6b6b] text-[12px] text-center top-[0.25px] whitespace-nowrap">Mesa 3</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.8px] not-italic text-[#ff6b6b] text-[10px] text-center top-[0.5px] whitespace-nowrap">4 pax · 28€</p>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-[#3a1e1e] content-stretch flex flex-col h-[46px] items-start left-[358.8px] pt-[8px] px-[12px] rounded-[14px] top-[133.23px] w-[72px]" data-name="Button">
      <Container21 />
      <Container22 />
    </div>
  );
}

function Container23() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.2px] not-italic text-[#e6e6e6] text-[12px] text-center top-[0.25px] whitespace-nowrap">Mesa 4</p>
    </div>
  );
}

function Container24() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.3px] not-italic text-[#e6e6e6] text-[10px] text-center top-[0.5px] whitespace-nowrap">2 pax · 16€</p>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-[#1b1f21] content-stretch flex flex-col h-[46px] items-start left-[528px] pt-[8px] px-[12px] rounded-[14px] top-[155.55px] w-[72px]" data-name="Button">
      <Container23 />
      <Container24 />
    </div>
  );
}

function Container25() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.7px] not-italic text-[#b48a2a] text-[12px] text-center top-[0.25px] whitespace-nowrap">Mesa 5</p>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.8px] not-italic text-[#b48a2a] text-[10px] text-center top-[0.5px] whitespace-nowrap">6 pax · 42€</p>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute bg-[#2a2418] content-stretch flex flex-col h-[46px] items-start left-[650.2px] pt-[8px] px-[12px] rounded-[14px] top-[177.88px] w-[72px]" data-name="Button">
      <Container25 />
      <Container26 />
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.7px] not-italic text-[#e6e6e6] text-[12px] text-center top-[0.25px] whitespace-nowrap">Mesa 6</p>
    </div>
  );
}

function Container28() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.8px] not-italic text-[#e6e6e6] text-[10px] text-center top-[0.5px] whitespace-nowrap">4 pax · 26€</p>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-[#1b1f21] content-stretch flex flex-col h-[46px] items-start left-[772.4px] pt-[8px] px-[12px] rounded-[14px] top-[144.4px] w-[72px]" data-name="Button">
      <Container27 />
      <Container28 />
    </div>
  );
}

function Container29() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.31px] not-italic text-[#e6e6e6] text-[12px] text-center top-[0.25px] whitespace-nowrap">Barra 1</p>
    </div>
  );
}

function Container30() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.3px] not-italic text-[#e6e6e6] text-[10px] text-center top-[0.5px] whitespace-nowrap">1 pax · 10€</p>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute bg-[#1b1f21] content-stretch flex flex-col h-[46px] items-start left-[170.8px] pt-[8px] px-[12px] rounded-[14px] top-[345.27px] w-[72px]" data-name="Button">
      <Container29 />
      <Container30 />
    </div>
  );
}

function Container31() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.31px] not-italic text-[#e6e6e6] text-[12px] text-center top-[0.25px] whitespace-nowrap">Barra 2</p>
    </div>
  );
}

function Container32() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.3px] not-italic text-[#e6e6e6] text-[10px] text-center top-[0.5px] whitespace-nowrap">1 pax · 10€</p>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute bg-[#1b1f21] content-stretch flex flex-col h-[46px] items-start left-[274.2px] pt-[8px] px-[12px] rounded-[14px] top-[356.44px] w-[72px]" data-name="Button">
      <Container31 />
      <Container32 />
    </div>
  );
}

function Container33() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.31px] not-italic text-[#ff6b6b] text-[12px] text-center top-[0.25px] whitespace-nowrap">Barra 3</p>
    </div>
  );
}

function Container34() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.3px] not-italic text-[#ff6b6b] text-[10px] text-center top-[0.5px] whitespace-nowrap">1 pax · 10€</p>
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute bg-[#3a1e1e] content-stretch flex flex-col h-[46px] items-start left-[377.59px] pt-[8px] px-[12px] rounded-[14px] top-[345.27px] w-[72px]" data-name="Button">
      <Container33 />
      <Container34 />
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.4px] not-italic text-[#e6e6e6] text-[12px] text-center top-[0.25px] whitespace-nowrap">VIP 1</p>
    </div>
  );
}

function Container36() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[24.3px] not-italic text-[#e6e6e6] text-[10px] text-center top-[0.5px] whitespace-nowrap">6 pax · 60€</p>
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute bg-[#1b1f21] content-stretch flex flex-col h-[46px] items-start left-[622px] pt-[8px] px-[12px] rounded-[14px] top-[401.08px] w-[72px]" data-name="Button">
      <Container35 />
      <Container36 />
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[15px] relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.9px] not-italic text-[#e6e6e6] text-[12px] text-center top-[0.25px] whitespace-nowrap">VIP 2</p>
    </div>
  );
}

function Container38() {
  return (
    <div className="h-[15px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[23.8px] not-italic text-[#e6e6e6] text-[10px] text-center top-[0.5px] whitespace-nowrap">8 pax · 80€</p>
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute bg-[#1b1f21] content-stretch flex flex-col h-[46px] items-start left-[772.4px] pt-[8px] px-[12px] rounded-[14px] top-[389.91px] w-[72px]" data-name="Button">
      <Container37 />
      <Container38 />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p1539e500} id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p37b99980} id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="flex-[1_0_0] h-[18px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#f5b301] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">PLANO · LOCAL CENTRO</p>
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="absolute bg-[rgba(9,9,11,0.8)] content-stretch flex gap-[8px] h-[32px] items-center left-[16px] px-[13px] py-[7px] rounded-[16777200px] top-[16px] w-[205.18px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[16777200px]" />
      <Icon />
      <Text3 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button13() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[8px] relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button14() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[8px] relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_308)" id="Icon">
          <path d="M1.16667 7H2.91667" id="Vector" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M11.0833 7H12.8333" id="Vector_2" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 1.16667V2.91667" id="Vector_3" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 11.0833V12.8333" id="Vector_4" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p33715380} id="Vector_5" stroke="var(--stroke-0, #E6E6E6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_1_308">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button15() {
  return (
    <div className="flex-[1_0_0] min-h-px relative rounded-[8px] w-[32px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[9px] relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div className="absolute bg-[rgba(9,9,11,0.8)] content-stretch flex flex-col gap-[4px] h-[114px] items-start left-[882px] p-[5px] rounded-[12px] top-[16px] w-[42px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <Button13 />
      <Button14 />
      <Button15 />
    </div>
  );
}

function Text5() {
  return (
    <div className="bg-[#1b1f21] relative rounded-[16777200px] shrink-0 size-[8px]" data-name="Text">
      <div aria-hidden="true" className="absolute border border-[#3a3f42] border-solid inset-0 pointer-events-none rounded-[16777200px]" />
    </div>
  );
}

function Text6() {
  return (
    <div className="flex-[1_0_0] h-[18px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#b4b6b7] text-[12px] top-[0.5px] whitespace-nowrap">Libre</p>
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[18px] relative shrink-0 w-[41.211px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Text5 />
        <Text6 />
      </div>
    </div>
  );
}

function Text8() {
  return <div className="bg-[#f5b301] relative rounded-[16777200px] shrink-0 size-[8px]" data-name="Text" />;
}

function Text9() {
  return (
    <div className="flex-[1_0_0] h-[18px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#b4b6b7] text-[12px] top-[0.5px] whitespace-nowrap">Selección</p>
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[18px] relative shrink-0 w-[64.594px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Text8 />
        <Text9 />
      </div>
    </div>
  );
}

function Text11() {
  return <div className="bg-[#b48a2a] relative rounded-[16777200px] shrink-0 size-[8px]" data-name="Text" />;
}

function Text12() {
  return (
    <div className="flex-[1_0_0] h-[18px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#b4b6b7] text-[12px] top-[0.5px] whitespace-nowrap">Reservada</p>
      </div>
    </div>
  );
}

function Text10() {
  return (
    <div className="flex-[1_0_0] h-[18px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Text11 />
        <Text12 />
      </div>
    </div>
  );
}

function Text14() {
  return <div className="bg-[#ff6b6b] relative rounded-[16777200px] shrink-0 size-[8px]" data-name="Text" />;
}

function Text15() {
  return (
    <div className="flex-[1_0_0] h-[18px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#b4b6b7] text-[12px] top-[0.5px] whitespace-nowrap">Ocupada</p>
      </div>
    </div>
  );
}

function Text13() {
  return (
    <div className="h-[18px] relative shrink-0 w-[62.125px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Text14 />
        <Text15 />
      </div>
    </div>
  );
}

function Container41() {
  return (
    <div className="absolute bg-[rgba(9,9,11,0.8)] content-stretch flex gap-[12px] h-[32px] items-center left-[16px] px-[13px] py-[7px] rounded-[16777200px] top-[510px] w-[299.852px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[16777200px]" />
      <Text4 />
      <Text7 />
      <Text10 />
      <Text13 />
    </div>
  );
}

function InteractiveMap() {
  return (
    <div className="absolute border border-[#27272a] border-solid h-[560px] left-0 overflow-clip rounded-[20px] top-0 w-[942px]" style={{ backgroundImage: "linear-gradient(149.269deg, rgb(15, 19, 20) 0%, rgb(14, 17, 18) 16.667%, rgb(12, 16, 17) 33.333%, rgb(11, 14, 15) 50%, rgb(11, 13, 14) 75%, rgb(10, 13, 14) 100%)" }} data-name="InteractiveMap">
      <Container8 />
      <Container9 />
      <Container10 />
      <Container11 />
      <Container12 />
      <Container13 />
      <Container14 />
      <Container15 />
      <Container16 />
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
      <Button6 />
      <Button7 />
      <Button8 />
      <Button9 />
      <Button10 />
      <Button11 />
      <Button12 />
      <Container39 />
      <Container40 />
      <Container41 />
    </div>
  );
}

function Container44() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#f5b301] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">TU SELECCIÓN</p>
    </div>
  );
}

function Container45() {
  return (
    <div className="h-[27px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[27px] left-0 not-italic text-[#f2e4e0] text-[18px] top-[0.5px] whitespace-nowrap">Asientos elegidos</p>
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[49px] relative shrink-0 w-[142.023px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Container44 />
        <Container45 />
      </div>
    </div>
  );
}

function Button16() {
  return (
    <div className="h-[18px] relative shrink-0 w-[41.008px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-[21.5px] not-italic text-[#b4b6b7] text-[12px] text-center top-[0.5px] whitespace-nowrap">Limpiar</p>
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div className="h-[82px] relative shrink-0 w-[940px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#27272a] border-b border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-[17px] pt-[16px] px-[20px] relative size-full">
        <Container43 />
        <Button16 />
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div className="bg-[#1b1f21] relative rounded-[10px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] not-italic relative shrink-0 text-[#f5b301] text-[13px] whitespace-nowrap">T2</p>
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="h-[22.5px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.5px] left-0 not-italic text-[#f2e4e0] text-[15px] top-[-1px] whitespace-nowrap">Mesa 2</p>
    </div>
  );
}

function Container51() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#909395] text-[12px] top-[0.5px] whitespace-nowrap">Terraza · 4 pax</p>
    </div>
  );
}

function Container49() {
  return (
    <div className="flex-[756.617_0_0] h-[40.5px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container50 />
        <Container51 />
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div className="h-[22.5px] relative shrink-0 w-[25.383px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.5px] left-0 not-italic text-[#f5b301] text-[15px] top-[-1px] whitespace-nowrap">28€</p>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-3/4 left-[12.5%] right-[12.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-0.67px_-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 1.33333">
            <path d="M0.666667 0.666667H12.6667" id="Vector" stroke="var(--stroke-0, #909395)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[8.33%] left-[20.83%] right-[20.83%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-6.25%_-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.6667 12">
            <path d={svgPaths.p2bb3ce80} id="Vector" stroke="var(--stroke-0, #909395)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-3/4 left-[33.33%] right-[33.33%] top-[8.33%]" data-name="Vector">
        <div className="absolute inset-[-25%_-12.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.66667 4">
            <path d={svgPaths.pd604100} id="Vector" stroke="var(--stroke-0, #909395)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[45.83%_58.33%_29.17%_41.67%]" data-name="Vector">
        <div className="absolute inset-[-16.67%_-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.33333 5.33333">
            <path d="M0.666667 0.666667V4.66667" id="Vector" stroke="var(--stroke-0, #909395)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[45.83%_41.67%_29.17%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-16.67%_-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.33333 5.33333">
            <path d="M0.666667 0.666667V4.66667" id="Vector" stroke="var(--stroke-0, #909395)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function ButtonQuitar() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Button - Quitar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] px-[4px] relative size-full">
        <Icon4 />
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="bg-[#0b0e0f] h-[66.5px] relative rounded-[14px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[13px] relative size-full">
          <Container48 />
          <Container49 />
          <Container52 />
          <ButtonQuitar />
        </div>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="flex-[280_0_0] min-h-px relative w-[940px]" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[16px] px-[16px] relative size-full">
          <Container47 />
        </div>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-0 size-[14px] top-[2.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p317fdd80} id="Vector" stroke="var(--stroke-0, #B4B6B7)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p31c78b80} id="Vector_2" stroke="var(--stroke-0, #B4B6B7)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p3625bb80} id="Vector_3" stroke="var(--stroke-0, #B4B6B7)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p2ca18b80} id="Vector_4" stroke="var(--stroke-0, #B4B6B7)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text16() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[89.93px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon5 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-[20px] not-italic text-[#b4b6b7] text-[13px] top-px whitespace-nowrap">{` Comensales`}</p>
      </div>
    </div>
  );
}

function Text17() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[7.336px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[#b4b6b7] text-[13px] top-px whitespace-nowrap">4</p>
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div className="content-stretch flex h-[19.5px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Text16 />
      <Text17 />
    </div>
  );
}

function Text18() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[29.383px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[#909395] text-[13px] top-px whitespace-nowrap">Total</p>
      </div>
    </div>
  );
}

function Text19() {
  return (
    <div className="h-[33px] relative shrink-0 w-[37.234px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[33px] left-0 not-italic text-[#f5b301] text-[22px] top-[0.5px] whitespace-nowrap">28€</p>
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div className="content-stretch flex h-[33px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Text18 />
      <Text19 />
    </div>
  );
}

function Button17() {
  return (
    <div className="bg-[#f5b301] drop-shadow-[0px_10px_7.5px_rgba(254,154,0,0.25)] h-[46.5px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[22.5px] left-[454.82px] not-italic text-[#0b0e0f] text-[15px] text-center top-[11px] whitespace-nowrap">Reservar ahora</p>
    </div>
  );
}

function Container53() {
  return (
    <div className="bg-[#0b0e0f] h-[156px] relative shrink-0 w-[940px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#27272a] border-solid border-t inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start pt-[17px] px-[16px] relative size-full">
        <Container54 />
        <Container55 />
        <Button17 />
      </div>
    </div>
  );
}

function SelectedSeats() {
  return (
    <div className="absolute bg-[#0d1112] h-[520px] left-0 rounded-[20px] top-[580px] w-[942px]" data-name="SelectedSeats">
      <div className="content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
        <Container42 />
        <Container46 />
        <Container53 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[20px]" />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M14 2.66667H9.33333" id="Vector" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M6.66667 2.66667H2" id="Vector_2" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14 8H8" id="Vector_3" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5.33333 8H2" id="Vector_4" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14 13.3333H10.6667" id="Vector_5" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 13.3333H2" id="Vector_6" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M9.33333 1.33333V4" id="Vector_7" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5.33333 6.66667V9.33333" id="Vector_8" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M10.6667 12V14.6667" id="Vector_9" stroke="var(--stroke-0, #F5B301)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container58() {
  return (
    <div className="bg-[#1b1f21] relative rounded-[10px] shrink-0 size-[36px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[10px] relative size-full">
        <Icon6 />
      </div>
    </div>
  );
}

function Container60() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#f5b301] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">FILTROS</p>
    </div>
  );
}

function Container61() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#f2e4e0] text-[16px] top-[-0.5px] whitespace-nowrap">Asientos</p>
    </div>
  );
}

function Container59() {
  return (
    <div className="flex-[1_0_0] h-[42px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container60 />
        <Container61 />
      </div>
    </div>
  );
}

function Container57() {
  return (
    <div className="h-[42px] relative shrink-0 w-[105.969px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container58 />
        <Container59 />
      </div>
    </div>
  );
}

function Button18() {
  return (
    <div className="h-[18px] relative shrink-0 w-[31.359px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-[16.5px] not-italic text-[#b4b6b7] text-[12px] text-center top-[0.5px] whitespace-nowrap">Reset</p>
      </div>
    </div>
  );
}

function Container56() {
  return (
    <div className="h-[75px] relative shrink-0 w-[940px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#27272a] border-b border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-[17px] pt-[16px] px-[20px] relative size-full">
        <Container57 />
        <Button18 />
      </div>
    </div>
  );
}

function Container63() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#909395] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">ZONA</p>
    </div>
  );
}

function Button19() {
  return (
    <div className="absolute bg-[#f5b301] border border-[#f5b301] border-solid h-[33.5px] left-0 rounded-[16777200px] top-0 w-[69.984px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[34.5px] not-italic text-[#0b0e0f] text-[13px] text-center top-[7px] whitespace-nowrap">Terraza</p>
    </div>
  );
}

function Button20() {
  return (
    <div className="absolute bg-[#f5b301] border border-[#f5b301] border-solid h-[33.5px] left-[77.98px] rounded-[16777200px] top-0 w-[70.898px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[34.5px] not-italic text-[#0b0e0f] text-[13px] text-center top-[7px] whitespace-nowrap">Interior</p>
    </div>
  );
}

function Button21() {
  return (
    <div className="absolute bg-[#f5b301] border border-[#f5b301] border-solid h-[33.5px] left-[156.88px] rounded-[16777200px] top-0 w-[58.281px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[28px] not-italic text-[#0b0e0f] text-[13px] text-center top-[7px] whitespace-nowrap">Barra</p>
    </div>
  );
}

function Button22() {
  return (
    <div className="absolute bg-[#f5b301] border border-[#f5b301] border-solid h-[33.5px] left-[223.16px] rounded-[16777200px] top-0 w-[46.18px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[22.5px] not-italic text-[#0b0e0f] text-[13px] text-center top-[7px] whitespace-nowrap">VIP</p>
    </div>
  );
}

function Container64() {
  return (
    <div className="h-[33.5px] relative shrink-0 w-full" data-name="Container">
      <Button19 />
      <Button20 />
      <Button21 />
      <Button22 />
    </div>
  );
}

function Section() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[63.5px] items-start relative shrink-0 w-full" data-name="Section">
      <Container63 />
      <Container64 />
    </div>
  );
}

function Container66() {
  return (
    <div className="h-[18px] relative shrink-0 w-[121.25px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#909395] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">COMENSALES MÍN.</p>
      </div>
    </div>
  );
}

function Container67() {
  return (
    <div className="h-[21px] relative shrink-0 w-[7.898px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#f5b301] text-[14px] top-0 whitespace-nowrap">1</p>
      </div>
    </div>
  );
}

function Container65() {
  return (
    <div className="absolute content-stretch flex h-[21px] items-center justify-between left-0 top-0 w-[885px]" data-name="Container">
      <Container66 />
      <Container67 />
    </div>
  );
}

function RangeSlider() {
  return <div className="absolute h-[16px] left-0 top-[34px] w-[885px]" data-name="Range Slider" />;
}

function Text20() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[6.211px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#909395] text-[11px] top-[0.5px] whitespace-nowrap">1</p>
      </div>
    </div>
  );
}

function Text21() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[6.211px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#909395] text-[11px] top-[0.5px] whitespace-nowrap">8</p>
      </div>
    </div>
  );
}

function Container68() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start justify-between left-0 top-[61px] w-[885px]" data-name="Container">
      <Text20 />
      <Text21 />
    </div>
  );
}

function Section1() {
  return (
    <div className="h-[77.5px] relative shrink-0 w-full" data-name="Section">
      <Container65 />
      <RangeSlider />
      <Container68 />
    </div>
  );
}

function Container70() {
  return (
    <div className="h-[18px] relative shrink-0 w-[85.961px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#909395] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">PRECIO MÁX.</p>
      </div>
    </div>
  );
}

function Container71() {
  return (
    <div className="h-[21px] relative shrink-0 w-[31.594px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#f5b301] text-[14px] top-0 whitespace-nowrap">100€</p>
      </div>
    </div>
  );
}

function Container69() {
  return (
    <div className="absolute content-stretch flex h-[21px] items-center justify-between left-0 top-0 w-[885px]" data-name="Container">
      <Container70 />
      <Container71 />
    </div>
  );
}

function RangeSlider1() {
  return <div className="absolute h-[16px] left-0 top-[34px] w-[885px]" data-name="Range Slider" />;
}

function Text22() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[18.617px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#909395] text-[11px] top-[0.5px] whitespace-nowrap">10€</p>
      </div>
    </div>
  );
}

function Text23() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[24.82px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#909395] text-[11px] top-[0.5px] whitespace-nowrap">100€</p>
      </div>
    </div>
  );
}

function Container72() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start justify-between left-0 top-[61px] w-[885px]" data-name="Container">
      <Text22 />
      <Text23 />
    </div>
  );
}

function Section2() {
  return (
    <div className="h-[77.5px] relative shrink-0 w-full" data-name="Section">
      <Container69 />
      <RangeSlider1 />
      <Container72 />
    </div>
  );
}

function Container74() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[21px] left-0 not-italic text-[#f2e4e0] text-[14px] top-0 whitespace-nowrap">Sólo disponibles</p>
    </div>
  );
}

function Container75() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#909395] text-[12px] top-[0.5px] whitespace-nowrap">Oculta mesas ocupadas o reservadas</p>
    </div>
  );
}

function Container73() {
  return (
    <div className="absolute content-stretch flex flex-col h-[39px] items-start left-0 top-0 w-[200.828px]" data-name="Container">
      <Container74 />
      <Container75 />
    </div>
  );
}

function Text24() {
  return <div className="bg-white h-[20px] relative rounded-[16777200px] shrink-0 w-full" data-name="Text" />;
}

function Switch() {
  return (
    <div className="absolute bg-[#27272a] content-stretch flex flex-col h-[24px] items-start left-[841px] pl-[2px] pr-[22px] pt-[2px] rounded-[16777200px] top-[7.5px] w-[44px]" data-name="Switch">
      <Text24 />
    </div>
  );
}

function Section3() {
  return (
    <div className="h-[39px] relative shrink-0 w-full" data-name="Section">
      <Container73 />
      <Switch />
    </div>
  );
}

function Container76() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#909395] text-[12px] top-[0.5px] tracking-[1.2px] whitespace-nowrap">HORARIO</p>
    </div>
  );
}

function Button23() {
  return (
    <div className="absolute border border-[#27272a] border-solid h-[37.5px] left-0 rounded-[10px] top-0 w-[289.664px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[144.06px] not-italic text-[#b4b6b7] text-[13px] text-center top-[9px] whitespace-nowrap">13:00</p>
    </div>
  );
}

function Button24() {
  return (
    <div className="absolute border border-[#27272a] border-solid h-[37.5px] left-[297.66px] rounded-[10px] top-0 w-[289.664px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[143.56px] not-italic text-[#b4b6b7] text-[13px] text-center top-[9px] whitespace-nowrap">14:00</p>
    </div>
  );
}

function Button25() {
  return (
    <div className="absolute border border-[#27272a] border-solid h-[37.5px] left-[595.33px] rounded-[10px] top-0 w-[289.664px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[144.06px] not-italic text-[#b4b6b7] text-[13px] text-center top-[9px] whitespace-nowrap">15:00</p>
    </div>
  );
}

function Button26() {
  return (
    <div className="absolute border border-[#27272a] border-solid h-[37.5px] left-0 rounded-[10px] top-[45.5px] w-[289.664px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[144.06px] not-italic text-[#b4b6b7] text-[13px] text-center top-[9px] whitespace-nowrap">20:00</p>
    </div>
  );
}

function Button27() {
  return (
    <div className="absolute bg-[#1b1f21] border border-[#f5b301] border-solid h-[37.5px] left-[297.66px] rounded-[10px] top-[45.5px] w-[289.664px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[144.06px] not-italic text-[#f5b301] text-[13px] text-center top-[9px] whitespace-nowrap">21:00</p>
    </div>
  );
}

function Button28() {
  return (
    <div className="absolute border border-[#27272a] border-solid h-[37.5px] left-[595.33px] rounded-[10px] top-[45.5px] w-[289.664px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[19.5px] left-[144.06px] not-italic text-[#b4b6b7] text-[13px] text-center top-[9px] whitespace-nowrap">22:00</p>
    </div>
  );
}

function Container77() {
  return (
    <div className="h-[83px] relative shrink-0 w-full" data-name="Container">
      <Button23 />
      <Button24 />
      <Button25 />
      <Button26 />
      <Button27 />
      <Button28 />
    </div>
  );
}

function Section4() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[113px] items-start relative shrink-0 w-full" data-name="Section">
      <Container76 />
      <Container77 />
    </div>
  );
}

function Container62() {
  return (
    <div className="flex-[403_0_0] min-h-px relative w-[940px]" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[24px] items-start pl-[20px] pr-[35px] pt-[20px] relative size-full">
          <Section />
          <Section1 />
          <Section2 />
          <Section3 />
          <Section4 />
        </div>
      </div>
    </div>
  );
}

function Button29() {
  return (
    <div className="bg-[#131718] h-[47px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[21px] left-[454.14px] not-italic text-[#f5b301] text-[14px] text-center top-[13px] whitespace-nowrap">Aplicar filtros</p>
    </div>
  );
}

function Container78() {
  return (
    <div className="bg-[#0b0e0f] h-[80px] relative shrink-0 w-[940px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#27272a] border-solid border-t inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[17px] px-[16px] relative size-full">
        <Button29 />
      </div>
    </div>
  );
}

function SeatFilters() {
  return (
    <div className="absolute bg-[#0d1112] h-[560px] left-0 rounded-[20px] top-[1120px] w-[942px]" data-name="SeatFilters">
      <div className="content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
        <Container56 />
        <Container62 />
        <Container78 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[20px]" />
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute h-[1680px] left-[24px] top-[262.5px] w-[942px]" data-name="Container">
      <InteractiveMap />
      <SelectedSeats />
      <SeatFilters />
    </div>
  );
}

function App() {
  return (
    <div className="bg-[#0b0e0f] h-[1966.5px] relative shrink-0 w-full" data-name="App">
      <SeatMapHeader />
      <Container6 />
      <Heading />
      <Paragraph />
      <Container7 />
    </div>
  );
}

export default function Body() {
  return (
    <div className="content-stretch flex flex-col items-start relative size-full" data-name="Body">
      <App />
    </div>
  );
}