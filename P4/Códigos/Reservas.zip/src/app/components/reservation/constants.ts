import type { Table, Zone } from "./types";

export const INITIAL_TABLES: Table[] = [
  { id: "m1", label: "Mesa 1", shortLabel: "T1", zone: "Terraza", pax: 2, price: 18, status: "free", x: 114.4, y: 133.23 },
  { id: "m2", label: "Mesa 2", shortLabel: "T2", zone: "Terraza", pax: 4, price: 28, status: "free", x: 246, y: 155.55 },
  { id: "m3", label: "Mesa 3", shortLabel: "T3", zone: "Terraza", pax: 4, price: 28, status: "occupied", x: 358.8, y: 133.23 },
  { id: "m4", label: "Mesa 4", shortLabel: "I1", zone: "Interior", pax: 2, price: 16, status: "free", x: 528, y: 155.55 },
  { id: "m5", label: "Mesa 5", shortLabel: "I2", zone: "Interior", pax: 6, price: 42, status: "reserved", x: 650.2, y: 177.88 },
  { id: "m6", label: "Mesa 6", shortLabel: "I3", zone: "Interior", pax: 4, price: 26, status: "free", x: 772.4, y: 144.4 },
  { id: "b1", label: "Barra 1", shortLabel: "B1", zone: "Barra", pax: 1, price: 10, status: "free", x: 170.8, y: 345.27 },
  { id: "b2", label: "Barra 2", shortLabel: "B2", zone: "Barra", pax: 1, price: 10, status: "free", x: 274.2, y: 356.44 },
  { id: "b3", label: "Barra 3", shortLabel: "B3", zone: "Barra", pax: 1, price: 10, status: "occupied", x: 377.59, y: 345.27 },
  { id: "v1", label: "VIP 1", shortLabel: "V1", zone: "VIP", pax: 6, price: 60, status: "free", x: 622, y: 401.08 },
  { id: "v2", label: "VIP 2", shortLabel: "V2", zone: "VIP", pax: 8, price: 80, status: "free", x: 772.4, y: 389.91 },
];

export const ALL_ZONES: Zone[] = ["Terraza", "Interior", "Barra", "VIP"];
export const TIME_SLOTS = ["13:00", "14:00", "15:00", "20:00", "21:00", "22:00"];
export const DEFAULT_FILTERS = {
  zones: [...ALL_ZONES],
  minPax: 1,
  maxPrice: 100,
  onlyAvailable: false,
};
