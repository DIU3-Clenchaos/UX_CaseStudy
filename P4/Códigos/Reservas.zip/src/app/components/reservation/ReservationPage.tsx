import { useReservation } from "./useReservation";
import { PageShell } from "./PageShell";
import { HeroSection, MapSection, SelectionSection, FiltersSection } from "./sections";

export function ReservationPage() {
  const r = useReservation();
  return (
    <PageShell cartCount={r.selected.length}>
      <HeroSection />
      <MapSection r={r} />
      <SelectionSection r={r} />
      <FiltersSection r={r} />
    </PageShell>
  );
}
