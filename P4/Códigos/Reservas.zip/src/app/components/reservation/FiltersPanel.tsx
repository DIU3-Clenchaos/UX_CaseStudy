import type { Filters, Zone } from "./types";
import { ALL_ZONES, TIME_SLOTS } from "./constants";
import { SectionCard } from "./SectionCard";
import { PillToggle } from "./PillToggle";
import { RangeField } from "./RangeField";
import { ToggleSwitch } from "./ToggleSwitch";
import { TimeSlotGrid } from "./TimeSlotGrid";

interface Props {
  filters: Filters;
  time: string;
  visibleCount: number;
  onToggleZone: (z: Zone) => void;
  onMinPax: (n: number) => void;
  onMaxPrice: (n: number) => void;
  onOnlyAvailable: (v: boolean) => void;
  onTime: (v: string) => void;
  onReset: () => void;
  onApply: () => void;
}

function FilterIcon() {
  return (
    <div className="bg-[#1b1f21] size-9 rounded-[10px] flex items-center justify-center">
      <svg className="size-4" fill="none" viewBox="0 0 16 16">
        <path
          d="M14 2.66667H9.33333M6.66667 2.66667H2M14 8H8M5.33333 8H2M14 13.3333H10.6667M8 13.3333H2M9.33333 1.33333V4M5.33333 6.66667V9.33333M10.6667 12V14.6667"
          stroke="#F5B301"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="1.33"
        />
      </svg>
    </div>
  );
}

export function FiltersPanel({
  filters, time, visibleCount,
  onToggleZone, onMinPax, onMaxPrice, onOnlyAvailable, onTime, onReset, onApply,
}: Props) {
  return (
    <SectionCard
      eyebrow="FILTROS"
      title="Asientos"
      leading={<FilterIcon />}
      action={
        <button onClick={onReset} className="text-[12px] text-[#b4b6b7] hover:text-[#f2e4e0]">Reset</button>
      }
      footer={
        <div className="bg-[#0b0e0f] border-t border-[#27272a] p-4 mt-5">
          <button
            onClick={onApply}
            className="w-full bg-[#131718] border border-[#27272a] hover:bg-[#1b1f21] text-[#f5b301] text-[14px] h-[47px] rounded-[14px] transition-colors"
          >
            Aplicar filtros ({visibleCount} mesas)
          </button>
        </div>
      }
    >
      <div className="px-5 pt-5 pb-1 flex flex-col gap-6">
        <div>
          <p className="text-[12px] tracking-[1.2px] text-[#909395] mb-3">ZONA</p>
          <div className="flex flex-wrap gap-2">
            {ALL_ZONES.map((z) => (
              <PillToggle key={z} label={z} active={filters.zones.includes(z)} onClick={() => onToggleZone(z)} />
            ))}
          </div>
        </div>

        <RangeField label="COMENSALES MÍN." value={filters.minPax} min={1} max={8} onChange={onMinPax} />
        <RangeField label="PRECIO MÁX." value={filters.maxPrice} min={10} max={100} step={5} suffix="€" onChange={onMaxPrice} />

        <ToggleSwitch
          title="Sólo disponibles"
          description="Oculta mesas ocupadas o reservadas"
          value={filters.onlyAvailable}
          onChange={onOnlyAvailable}
        />

        <TimeSlotGrid slots={TIME_SLOTS} value={time} onChange={onTime} />
      </div>
    </SectionCard>
  );
}
