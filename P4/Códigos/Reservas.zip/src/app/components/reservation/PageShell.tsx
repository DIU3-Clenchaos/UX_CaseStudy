import type { ReactNode } from "react";
import { Toaster } from "sonner";
import { Header } from "./Header";

interface Props {
  cartCount: number;
  children: ReactNode;
}

export function PageShell({ cartCount, children }: Props) {
  return (
    <div className="min-h-screen w-full bg-[#0b0e0f]">
      <Toaster theme="dark" position="top-center" richColors />
      <Header cartCount={cartCount} />
      <div className="max-w-[990px] mx-auto px-6 pt-8 pb-16">{children}</div>
    </div>
  );
}
