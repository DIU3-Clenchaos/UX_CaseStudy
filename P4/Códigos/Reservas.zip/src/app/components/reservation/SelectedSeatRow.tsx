import { X } from "lucide-react";
import type { Table } from "./types";

export function SelectedSeatRow({ table, onRemove }: { table: Table; onRemove: (t: Table) => void }) {
  return (
    <div className="bg-[#0b0e0f] border border-[#27272a] rounded-[14px] p-3 flex items-center gap-3">
      <div className="bg-[#1b1f21] size-10 rounded-[10px] flex items-center justify-center text-[13px] text-[#f5b301]">
        {table.shortLabel}
      </div>
      <div className="flex-1">
        <p className="text-[15px] leading-[22.5px] text-[#f2e4e0]">{table.label}</p>
        <p className="text-[12px] text-[#909395]">{table.zone} · {table.pax} pax</p>
      </div>
      <p className="text-[15px] text-[#f5b301]">{table.price}€</p>
      <button onClick={() => onRemove(table)} className="size-6 flex items-center justify-center text-[#909395] hover:text-[#ff6b6b]">
        <X className="size-4" />
      </button>
    </div>
  );
}
