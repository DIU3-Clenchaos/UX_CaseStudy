interface Props {
  slots: string[];
  value: string;
  onChange: (v: string) => void;
}

export function TimeSlotGrid({ slots, value, onChange }: Props) {
  return (
    <div>
      <p className="text-[12px] tracking-[1.2px] text-[#909395] mb-3">HORARIO</p>
      <div className="grid grid-cols-3 gap-2">
        {slots.map((slot) => {
          const active = slot === value;
          return (
            <button
              key={slot}
              onClick={() => onChange(slot)}
              className="h-[37.5px] rounded-[10px] border text-[13px] transition-colors"
              style={{
                backgroundColor: active ? "#1b1f21" : "transparent",
                borderColor: active ? "#f5b301" : "#27272a",
                color: active ? "#f5b301" : "#b4b6b7",
              }}
            >
              {slot}
            </button>
          );
        })}
      </div>
    </div>
  );
}
