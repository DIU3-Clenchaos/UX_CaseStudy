import { Users } from "lucide-react";
import type { Table } from "./types";
import { SectionCard } from "./SectionCard";
import { SelectedSeatRow } from "./SelectedSeatRow";

interface Props {
  selectedTables: Table[];
  totalPax: number;
  totalPrice: number;
  onRemove: (t: Table) => void;
  onClear: () => void;
  onReserve: () => void;
}

export function SelectedSeatsPanel({ selectedTables, totalPax, totalPrice, onRemove, onClear, onReserve }: Props) {
  return (
    <SectionCard
      eyebrow="TU SELECCIÓN"
      title="Asientos elegidos"
      action={
        <button onClick={onClear} className="text-[12px] text-[#b4b6b7] hover:text-[#f2e4e0]">
          Limpiar
        </button>
      }
      footer={
        <div className="bg-[#0b0e0f] border-t border-[#27272a] p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="size-3.5 text-[#b4b6b7]" />
              <span className="text-[13px] text-[#b4b6b7]">Comensales</span>
            </div>
            <span className="text-[13px] text-[#b4b6b7]">{totalPax}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[13px] text-[#909395]">Total</span>
            <span className="text-[22px] text-[#f5b301]">{totalPrice}€</span>
          </div>
          <button
            onClick={onReserve}
            className="bg-[#f5b301] hover:bg-[#ffc222] transition-colors text-[#0b0e0f] text-[15px] rounded-[14px] h-[46.5px] shadow-[0px_10px_7.5px_rgba(254,154,0,0.25)]"
          >
            Reservar ahora
          </button>
        </div>
      }
    >
      <div className="p-4 flex flex-col gap-2 min-h-[80px]">
        {selectedTables.length === 0 ? (
          <p className="text-[13px] text-[#909395] py-6 text-center">No has seleccionado ninguna mesa todavía.</p>
        ) : (
          selectedTables.map((t) => <SelectedSeatRow key={t.id} table={t} onRemove={onRemove} />)
        )}
      </div>
    </SectionCard>
  );
}
