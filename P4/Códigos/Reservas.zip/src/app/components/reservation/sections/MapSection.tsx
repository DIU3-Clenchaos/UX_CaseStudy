import type { useReservation } from "../useReservation";
import { InteractiveMap } from "../InteractiveMap";

type R = ReturnType<typeof useReservation>;

export function MapSection({ r }: { r: R }) {
  return (
    <InteractiveMap
      tables={r.tables}
      selected={r.selected}
      matchesFilter={r.matchesFilter}
      onToggle={r.toggleSelect}
    />
  );
}
