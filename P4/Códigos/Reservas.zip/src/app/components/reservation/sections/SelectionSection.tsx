import type { useReservation } from "../useReservation";
import { SelectedSeatsPanel } from "../SelectedSeatsPanel";

type R = ReturnType<typeof useReservation>;

export function SelectionSection({ r }: { r: R }) {
  return (
    <SelectedSeatsPanel
      selectedTables={r.selectedTables}
      totalPax={r.totalPax}
      totalPrice={r.totalPrice}
      onRemove={r.toggleSelect}
      onClear={r.clearSelection}
      onReserve={r.reserve}
    />
  );
}
