import type { useReservation } from "../useReservation";
import { FiltersPanel } from "../FiltersPanel";

type R = ReturnType<typeof useReservation>;

export function FiltersSection({ r }: { r: R }) {
  return (
    <FiltersPanel
      filters={r.filters}
      time={r.time}
      visibleCount={r.visibleTables.length}
      onToggleZone={r.toggleZone}
      onMinPax={r.setMinPax}
      onMaxPrice={r.setMaxPrice}
      onOnlyAvailable={r.setOnlyAvailable}
      onTime={r.setTime}
      onReset={r.resetFilters}
      onApply={r.applyFilters}
    />
  );
}
