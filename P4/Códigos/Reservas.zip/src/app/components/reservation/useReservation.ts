import { useMemo, useState } from "react";
import { toast } from "sonner";
import { DEFAULT_FILTERS, INITIAL_TABLES } from "./constants";
import type { Filters, Table, Zone } from "./types";

export function useReservation() {
  const [tables, setTables] = useState<Table[]>(INITIAL_TABLES);
  const [selected, setSelected] = useState<string[]>([]);
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [time, setTime] = useState("21:00");

  const matchesFilter = (t: Table) => {
    if (!filters.zones.includes(t.zone)) return false;
    if (t.pax < filters.minPax) return false;
    if (t.price > filters.maxPrice) return false;
    if (filters.onlyAvailable && t.status !== "free") return false;
    return true;
  };

  const visibleTables = useMemo(() => tables.filter(matchesFilter), [tables, filters]);
  const selectedTables = useMemo(() => tables.filter((t) => selected.includes(t.id)), [tables, selected]);
  const totalPax = selectedTables.reduce((s, t) => s + t.pax, 0);
  const totalPrice = selectedTables.reduce((s, t) => s + t.price, 0);

  const toggleSelect = (t: Table) => {
    if (t.status === "occupied") return toast.error(`${t.label} está ocupada`);
    if (t.status === "reserved") return toast.error(`${t.label} ya está reservada`);
    setSelected((prev) => (prev.includes(t.id) ? prev.filter((id) => id !== t.id) : [...prev, t.id]));
  };

  const toggleZone = (z: Zone) =>
    setFilters((f) => ({ ...f, zones: f.zones.includes(z) ? f.zones.filter((x) => x !== z) : [...f.zones, z] }));

  const setMinPax = (n: number) => setFilters((f) => ({ ...f, minPax: n }));
  const setMaxPrice = (n: number) => setFilters((f) => ({ ...f, maxPrice: n }));
  const setOnlyAvailable = (v: boolean) => setFilters((f) => ({ ...f, onlyAvailable: v }));
  const resetFilters = () => setFilters(DEFAULT_FILTERS);
  const clearSelection = () => setSelected([]);

  const reserve = () => {
    if (selected.length === 0) return toast.error("Selecciona al menos una mesa");
    setTables((prev) => prev.map((t) => (selected.includes(t.id) ? { ...t, status: "reserved" } : t)));
    toast.success(`Reserva confirmada · ${time} · ${totalPrice}€`);
    setSelected([]);
  };

  const applyFilters = () => toast.success(`Filtros aplicados · ${visibleTables.length} mesas`);

  return {
    tables, selected, selectedTables, visibleTables, filters, time, totalPax, totalPrice,
    matchesFilter, toggleSelect, toggleZone, setMinPax, setMaxPrice, setOnlyAvailable,
    resetFilters, clearSelection, reserve, applyFilters, setTime,
  };
}
