interface Props {
  title: string;
  description: string;
  value: boolean;
  onChange: (v: boolean) => void;
}

export function ToggleSwitch({ title, description, value, onChange }: Props) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <p className="text-[14px] text-[#f2e4e0]">{title}</p>
        <p className="text-[12px] text-[#909395]">{description}</p>
      </div>
      <button
        onClick={() => onChange(!value)}
        className="w-11 h-6 rounded-full p-0.5 transition-colors"
        style={{ backgroundColor: value ? "#f5b301" : "#27272a" }}
      >
        <span
          className="block size-5 rounded-full bg-white transition-transform"
          style={{ transform: value ? "translateX(20px)" : "translateX(0)" }}
        />
      </button>
    </div>
  );
}
