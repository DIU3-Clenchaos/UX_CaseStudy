import type { ReactNode } from "react";

interface Props {
  eyebrow: string;
  title: ReactNode;
  action?: ReactNode;
  leading?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
}

export function SectionCard({ eyebrow, title, action, leading, children, footer }: Props) {
  return (
    <div className="mt-6 bg-[#0d1112] border border-[#27272a] rounded-[20px] overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#27272a]">
        <div className="flex items-center gap-2">
          {leading}
          <div>
            <p className="text-[12px] tracking-[1.2px] text-[#f5b301]">{eyebrow}</p>
            <p className="text-[18px] leading-[27px] text-[#f2e4e0]">{title}</p>
          </div>
        </div>
        {action}
      </div>
      {children}
      {footer}
    </div>
  );
}
