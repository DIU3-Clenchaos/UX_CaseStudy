function LegendDot({ color, border, label }: { color: string; border?: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="size-2 rounded-full" style={{ backgroundColor: color, border: border ? `1px solid ${border}` : undefined }} />
      <span className="text-[12px] text-[#b4b6b7]">{label}</span>
    </div>
  );
}

export function MapLegend() {
  return (
    <div className="absolute left-4 bottom-4 z-10 bg-[rgba(9,9,11,0.8)] border border-[#27272a] rounded-full h-8 px-3 flex items-center gap-3">
      <LegendDot color="#1b1f21" border="#3a3f42" label="Libre" />
      <LegendDot color="#f5b301" label="Selección" />
      <LegendDot color="#b48a2a" label="Reservada" />
      <LegendDot color="#ff6b6b" label="Ocupada" />
    </div>
  );
}
