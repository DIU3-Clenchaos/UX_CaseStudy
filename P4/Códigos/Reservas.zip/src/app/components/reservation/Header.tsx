import { ShoppingCart, Sparkles, User } from "lucide-react";

export function Header({ cartCount }: { cartCount: number }) {
  return (
    <div className="sticky top-0 z-50 bg-[rgba(9,9,11,0.9)] backdrop-blur border-b border-[#27272a]">
      <div className="flex items-center gap-4 px-6 h-[77px]">
        <div className="flex items-center gap-3">
          <a
            href="https://www.figma.com/make/qb3R4W4QMBYFErtPn7tJvK/Landing-Page?code-node-id=0-9&p=f&t=QR1GaE4ohgzf0xLO-0&fullscreen=1"
            target="_blank"
            rel="noopener noreferrer"
            className="size-11 rounded-[14px] bg-[#f5b301]/10 flex items-center justify-center shadow-[0px_10px_15px_rgba(254,154,0,0.2)] hover:bg-[#f5b301]/20 transition-colors"
          >
            <Sparkles className="size-5 text-[#f5b301]" />
          </a>
          <div className="flex flex-col">
            <p className="text-[18px] leading-[22px] text-[#f5b301]">Remake</p>
            <p className="text-[13px] leading-[16px] text-[#b4b6b7]">Champions Burguer</p>
          </div>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-3">
          <button className="bg-[#131718] size-10 rounded-[14px] flex items-center justify-center hover:bg-[#1b1f21] transition-colors relative">
            <ShoppingCart className="size-5 text-[#e6e6e6]" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#f5b301] text-[#0b0e0f] text-[10px] rounded-full size-5 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
          <button className="size-10 rounded-[14px] flex items-center justify-center hover:bg-[#131718] transition-colors">
            <User className="size-5 text-[#e6e6e6]" />
          </button>
        </div>
      </div>
    </div>
  );
}
