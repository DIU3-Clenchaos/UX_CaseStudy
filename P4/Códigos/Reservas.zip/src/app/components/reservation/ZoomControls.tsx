import { Maximize2, Minus, Plus } from "lucide-react";

interface Props {
  onZoomIn: () => void;
  onZoomOut: () => void;
  onReset: () => void;
}

export function ZoomControls({ onZoomIn, onZoomOut, onReset }: Props) {
  return (
    <div className="absolute top-4 right-4 z-10 bg-[rgba(9,9,11,0.8)] border border-[#27272a] rounded-xl p-1 flex flex-col gap-1">
      <button onClick={onZoomIn} className="size-8 rounded-lg hover:bg-[#1b1f21] flex items-center justify-center">
        <Plus className="size-4 text-[#e6e6e6]" />
      </button>
      <button onClick={onZoomOut} className="size-8 rounded-lg hover:bg-[#1b1f21] flex items-center justify-center">
        <Minus className="size-4 text-[#e6e6e6]" />
      </button>
      <button onClick={onReset} className="size-8 rounded-lg hover:bg-[#1b1f21] flex items-center justify-center">
        <Maximize2 className="size-3.5 text-[#e6e6e6]" />
      </button>
    </div>
  );
}
