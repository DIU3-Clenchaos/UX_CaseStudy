export type Zone = "Terraza" | "Interior" | "Barra" | "VIP";
export type Status = "free" | "reserved" | "occupied";

export interface Table {
  id: string;
  label: string;
  shortLabel: string;
  zone: Zone;
  pax: number;
  price: number;
  status: Status;
  x: number;
  y: number;
}

export interface Filters {
  zones: Zone[];
  minPax: number;
  maxPrice: number;
  onlyAvailable: boolean;
}
