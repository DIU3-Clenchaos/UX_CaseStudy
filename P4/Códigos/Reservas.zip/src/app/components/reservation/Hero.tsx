export function Hero() {
  return (
    <>
      <div className="bg-black/20 rounded-full inline-block px-3 py-1 mb-4">
        <p className="text-[12px] tracking-[1.2px] text-[#f5b301]">RESERVA · TEMPORADA 2026</p>
      </div>
      <h1 className="text-[28px] leading-[34px] text-[#f2e4e0]">
        Elige tu mesa en el <span className="text-[#f5b301]">plano interactivo</span>.
      </h1>
      <p className="text-[15px] leading-[22.5px] text-[#909395] mt-2 max-w-[640px]">
        Explora el local, selecciona los asientos que más te gusten y filtra por zona, comensales o precio. Confirma tu reserva en un par de clics.
      </p>
    </>
  );
}
