interface Props {
  label: string;
  active: boolean;
  onClick: () => void;
}

export function PillToggle({ label, active, onClick }: Props) {
  return (
    <button
      onClick={onClick}
      className="px-4 h-[33.5px] rounded-full border text-[13px] transition-colors"
      style={{
        backgroundColor: active ? "#f5b301" : "transparent",
        borderColor: active ? "#f5b301" : "#27272a",
        color: active ? "#0b0e0f" : "#b4b6b7",
      }}
    >
      {label}
    </button>
  );
}
