import type { Table } from "./types";

function colorFor(t: Table, selected: boolean) {
  if (selected) return { bg: "#f5b301", text: "#0b0e0f", shadow: "0px 8px 9px rgba(245,179,1,0.45)" };
  if (t.status === "occupied") return { bg: "#3a1e1e", text: "#ff6b6b", shadow: "none" };
  if (t.status === "reserved") return { bg: "#2a2418", text: "#b48a2a", shadow: "none" };
  return { bg: "#1b1f21", text: "#e6e6e6", shadow: "none" };
}

interface Props {
  table: Table;
  selected: boolean;
  visible: boolean;
  onClick: (t: Table) => void;
}

export function TableButton({ table, selected, visible, onClick }: Props) {
  const c = colorFor(table, selected);
  return (
    <button
      onClick={() => onClick(table)}
      disabled={table.status === "occupied"}
      className="absolute flex flex-col items-start pt-2 px-3 rounded-[14px] transition-all hover:scale-105 disabled:cursor-not-allowed"
      style={{
        left: table.x,
        top: table.y,
        width: 72,
        height: 46,
        backgroundColor: c.bg,
        boxShadow: c.shadow,
        opacity: visible ? 1 : 0.2,
        pointerEvents: visible ? "auto" : "none",
      }}
    >
      <span className="w-full text-center text-[12px] leading-[15px]" style={{ color: c.text }}>{table.label}</span>
      <span className="w-full text-center text-[10px] leading-[15px] opacity-80" style={{ color: c.text }}>
        {table.pax} pax · {table.price}€
      </span>
    </button>
  );
}
