interface Props {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  suffix?: string;
  onChange: (v: number) => void;
}

export function RangeField({ label, value, min, max, step = 1, suffix = "", onChange }: Props) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <p className="text-[12px] tracking-[1.2px] text-[#909395]">{label}</p>
        <p className="text-[14px] text-[#f5b301]">{value}{suffix}</p>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-[#f5b301]"
      />
      <div className="flex justify-between mt-1">
        <span className="text-[11px] text-[#909395]">{min}{suffix}</span>
        <span className="text-[11px] text-[#909395]">{max}{suffix}</span>
      </div>
    </div>
  );
}
