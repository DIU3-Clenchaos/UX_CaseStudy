import { useState } from "react";
import { Map } from "lucide-react";
import type { Table } from "./types";
import { TableButton } from "./TableButton";
import { MapLegend } from "./MapLegend";
import { ZoomControls } from "./ZoomControls";

const ZONE_AREAS = [
  { left: 74.99, top: 100.55, width: 414, height: 156, radius: 20, color: "#27272a" },
  { left: 507.59, top: 100.55, width: 376, height: 156, radius: 20, color: "#27272a" },
  { left: 131.59, top: 323.85, width: 376, height: 100, radius: 40, color: "#27272a" },
  { left: 563.8, top: 334.84, width: 320, height: 145, radius: 20, color: "rgba(245,179,1,0.3)" },
];

const ZONE_LABELS = [
  { text: "TERRAZA", left: 93.86, top: 108.55 },
  { text: "INTERIOR", left: 526.42, top: 108.55 },
  { text: "BARRA", left: 150.3, top: 331.76 },
  { text: "VIP", left: 582.74, top: 342.91 },
];

interface Props {
  tables: Table[];
  selected: string[];
  matchesFilter: (t: Table) => boolean;
  onToggle: (t: Table) => void;
}

export function InteractiveMap({ tables, selected, matchesFilter, onToggle }: Props) {
  const [zoom, setZoom] = useState(1);

  return (
    <div
      className="relative mt-8 border border-[#27272a] rounded-[20px] overflow-hidden h-[560px]"
      style={{ backgroundImage: "linear-gradient(149.269deg, #0f1314 0%, #0a0d0e 100%)" }}
    >
      <div
        className="absolute inset-0 opacity-[0.18] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(245,179,1,0.25) 1px, transparent 1px), linear-gradient(90deg, rgba(245,179,1,0.25) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      <div className="absolute left-4 top-4 z-10 bg-[rgba(9,9,11,0.8)] border border-[#27272a] rounded-full h-8 px-3 flex items-center gap-2">
        <Map className="size-3.5 text-[#f5b301]" />
        <p className="text-[12px] tracking-[1.2px] text-[#f5b301]">PLANO · LOCAL CENTRO</p>
      </div>

      <ZoomControls
        onZoomIn={() => setZoom((z) => Math.min(1.4, z + 0.1))}
        onZoomOut={() => setZoom((z) => Math.max(0.6, z - 0.1))}
        onReset={() => setZoom(1)}
      />

      <div className="absolute inset-0" style={{ transform: `scale(${zoom})`, transformOrigin: "center center", transition: "transform 0.2s" }}>
        {ZONE_AREAS.map((a, i) => (
          <div
            key={i}
            className="absolute border border-dashed"
            style={{ left: a.left, top: a.top, width: a.width, height: a.height, borderRadius: a.radius, borderColor: a.color }}
          />
        ))}
        {ZONE_LABELS.map((l) => (
          <p key={l.text} className="absolute text-[11px] tracking-[1.5px] text-[#f5b301]" style={{ left: l.left, top: l.top }}>
            {l.text}
          </p>
        ))}
        {tables.map((t) => (
          <TableButton
            key={t.id}
            table={t}
            selected={selected.includes(t.id)}
            visible={matchesFilter(t)}
            onClick={onToggle}
          />
        ))}
      </div>

      <MapLegend />
    </div>
  );
}
