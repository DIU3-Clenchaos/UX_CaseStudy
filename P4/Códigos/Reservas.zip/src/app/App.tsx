import { ReservationPage } from "./components/reservation/ReservationPage";

export default function App() {
  return <ReservationPage />;
}
