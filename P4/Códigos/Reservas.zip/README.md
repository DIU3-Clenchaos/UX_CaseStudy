
  # Reservas

  This is a code bundle for Reservas. The original project is available at https://www.figma.com/design/dkRt8FTT9VZaSu6GxJGvSH/Reservas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  